import os ,public ,json ,sys #line:9
from flask import request ,redirect ,g #line:11
from BTPanel import session ,cache #line:12
from datetime import datetime #line:13
class dict_obj :#line:15
    def __contains__ (OOOO00OO0000OOOO0 ,OO00O000000O000OO ):#line:16
        return getattr (OOOO00OO0000OOOO0 ,OO00O000000O000OO ,None )#line:17
    def __setitem__ (OO0O00O0O00O00O0O ,OOO00OOO00000OO00 ,OO00O0OO00OO00O0O ):setattr (OO0O00O0O00O00O0O ,OOO00OOO00000OO00 ,OO00O0OO00OO00O0O )#line:18
    def __getitem__ (O0OO000O00OO00000 ,OOOOO0000O0OOO0O0 ):return getattr (O0OO000O00OO00000 ,OOOOO0000O0OOO0O0 ,None )#line:19
    def __delitem__ (O0O00OOOOO0OO000O ,OO0000000OOO0O0OO ):delattr (O0O00OOOOO0OO000O ,OO0000000OOO0O0OO )#line:20
    def __delattr__ (O000000OO0O000O00 ,OO0OOOOO0OO0O0O00 ):delattr (O000000OO0O000O00 ,OO0OOOOO0OO0O0O00 )#line:21
    def get_items (OO0O00O0OO0OO0O00 ):return OO0O00O0OO0OO0O00 #line:22
class panelSetup :#line:25
    def init (O0OOOOO000O0O0O00 ):#line:26
        OOO000O0OOO0O0OO0 =request .headers .get ('User-Agent')#line:27
        if OOO000O0OOO0O0OO0 :#line:28
            OOO000O0OOO0O0OO0 =OOO000O0OOO0O0OO0 .lower ();#line:29
            if OOO000O0OOO0O0OO0 .find ('spider')!=-1 or OOO000O0OOO0O0OO0 .find ('bot')!=-1 :return redirect ('https://www.baidu.com');#line:30
        g .version ='1.1.1'#line:32
        g .title =public .GetConfigValue ('title')#line:33
        g .uri =request .path #line:34
        g .setup_path =public .GetConfigValue ('setup_path')#line:35
        session ['version']=g .version ;#line:37
        session ['title']=g .title #line:38
        return None #line:39
class panelAdmin (panelSetup ):#line:42
    setupPath =os .getenv ("BT_SETUP")#line:43
    def local (O0O00O0OOOO0O000O ):#line:46
        OOO0O000O0O00000O =panelSetup ().init ()#line:47
        if OOO0O000O0O00000O :return OOO0O000O0O00000O #line:48
        OOO0O000O0O00000O =O0O00O0OOOO0O000O .checkLimitIp ()#line:49
        if OOO0O000O0O00000O :return OOO0O000O0O00000O #line:50
        OOO0O000O0O00000O =O0O00O0OOOO0O000O .setSession ();#line:51
        if OOO0O000O0O00000O :return OOO0O000O0O00000O #line:52
        OOO0O000O0O00000O =O0O00O0OOOO0O000O .checkClose ();#line:53
        if OOO0O000O0O00000O :return OOO0O000O0O00000O #line:54
        OOO0O000O0O00000O =O0O00O0OOOO0O000O .checkWebType ();#line:55
        if OOO0O000O0O00000O :return OOO0O000O0O00000O #line:56
        OOO0O000O0O00000O =O0O00O0OOOO0O000O .checkDomain ();#line:57
        if OOO0O000O0O00000O :return OOO0O000O0O00000O #line:58
        OOO0O000O0O00000O =O0O00O0OOOO0O000O .checkConfig ();#line:59
        O0O00O0OOOO0O000O .GetOS ();#line:61
    def checkAddressWhite (O0OOO00O00O0O0OO0 ):#line:65
        OO0OOO0O00OO0OOO0 =O0OOO00O00O0O0OO0 .GetToken ();#line:66
        if not OO0OOO0O00OO0OOO0 :return redirect ('/login');#line:67
        if not request .remote_addr in OO0OOO0O00OO0OOO0 ['address']:return redirect ('/login');#line:68
    def checkLimitIp (O000OOOO0O0OOOOO0 ):#line:72
        print ('')#line:73
        if os .path .exists ('data/limitip.conf'):#line:74
            O00000OOOOO0OO0OO =public .ReadFile ('data/limitip.conf')#line:75
            if O00000OOOOO0OO0OO :#line:76
                O00000OOOOO0OO0OO =O00000OOOOO0OO0OO .strip ();#line:77
                if not request .remote_addr in O00000OOOOO0OO0OO .split (','):return redirect ('/login')#line:78
        O0OOO00000O000O00 ='client_ua'#line:79
        O000OOOO0O0O0OOOO =public .md5 (request .headers .get ('User-Agent'))#line:80
        if O0OOO00000O000O00 in session :#line:81
            if session [O0OOO00000O000O00 ]!=O000OOOO0O0O0OOOO :#line:82
                session ['login']=False #line:83
                del (session [O0OOO00000O000O00 ])#line:84
                cache .set ('dologin',True )#line:85
                return redirect ('/login');#line:86
        else :#line:87
            session [O0OOO00000O000O00 ]=O000OOOO0O0O0OOOO #line:88
    def setSession (OO00000OOOO00OOOO ):#line:91
        session ['menus']=sorted (json .loads (public .ReadFile ('config/menu.json')),key =lambda O0OO00O00O0O00OOO :O0OO00O00O0O00OOO ['sort'])#line:92
        session ['yaer']=datetime .now ().year #line:93
        session ['download_url']='http://download.bt.cn';#line:94
        if not 'brand'in session :#line:95
            session ['brand']=public .GetConfigValue ('brand');#line:96
            session ['product']=public .GetConfigValue ('product');#line:97
            session ['rootPath']='/www'#line:98
            session ['download_url']='http://download.bt.cn';#line:99
            session ['setupPath']=public .GetConfigValue ('setup_path');#line:100
            session ['logsPath']=public .GetConfigValue ('setup_path')+'/wwwlogs';#line:101
            session ['yaer']=datetime .now ().year #line:102
            print (session )#line:103
        if not 'menu'in session :#line:104
            session ['menu']=public .GetLan ('menu');#line:105
        if not 'lan'in session :#line:106
            session ['lan']=public .GetLanguage ();#line:107
        if not 'home'in session :#line:108
            session ['home']='http://www.bt.cn';#line:109
    def checkWebType (O00000000O0OO0O00 ):#line:113
        session ['webserver']='iis';#line:115
        if public .get_server_status ('nginx')>=0 :#line:116
            session ['webserver']='nginx'#line:117
        elif public .get_server_status ('apache')>=0 :#line:118
            session ['webserver']='apache';#line:119
        if os .path .exists (O00000000O0OO0O00 .setupPath +'/'+session ['webserver']+'/version.pl'):#line:121
            session ['webversion']=public .ReadFile (O00000000O0OO0O00 .setupPath +'/'+session ['webserver']+'/version.pl').strip ()#line:122
        OO000O0000O0O0O0O =O00000000O0OO0O00 .setupPath +'/data/phpmyadminDirName.pl'#line:123
        if os .path .exists (OO000O0000O0O0O0O ):#line:124
            session ['phpmyadminDir']=public .ReadFile (OO000O0000O0O0O0O ).strip ()#line:125
    def checkClose (O0OO000OOOO000OO0 ):#line:128
        if os .path .exists ('data/close.pl'):#line:129
            return redirect ('/close');#line:130
    def checkDomain (O0OO000O00OO0O000 ):#line:133
        try :#line:134
            if not session ['login']:return redirect ('/login')#line:135
            O000O0O00OO0O00O0 =public .GetHost ()#line:136
            OOOO000OOO0000O0O =public .ReadFile ('data/domain.conf')#line:137
            if OOOO000OOO0000O0O :#line:138
                if (O000O0O00OO0O00O0 .strip ()!=OOOO000OOO0000O0O .strip ()):return redirect ('/login')#line:139
        except :#line:140
            return redirect ('/login')#line:141
    def checkConfig (O000OO0OO000000O0 ):#line:144
        if not 'config'in session :#line:145
            session ['config']=public .M ('config').where ("id=?",('1',)).field ('webserver,sites_path,backup_path,status,mysql_root').find ();#line:146
            O0O0OO00OO0OOO0OO ='data/sa.pl'#line:147
            if os .path .exists (O0O0OO00OO0OOO0OO ):#line:148
                session ['config']['mssql_sa']=public .readFile (O0O0OO00OO0OOO0OO )#line:149
            print (session ['config'])#line:150
            if not 'email'in session ['config']:#line:151
                session ['config']['email']=public .M ('users').where ("id=?",('1',)).getField ('email');#line:152
            if not 'address'in session :#line:153
                session ['address']=public .GetLocalIp ()#line:154
    def checkSafe (OO0O00OO0O0OO0OOO ):#line:156
        O0OOOO0O000O0O000 =['/','/site','/ftp','/database','/plugin','/soft','/public'];#line:157
        if not os .path .exists (os .getenv ("BT_SETUP")+'/data/userInfo.json'):#line:158
            if 'vip'in session :del (session .vip );#line:159
        if not request .path in O0OOOO0O000O0O000 :return True #line:160
        if 'vip'in session :return True #line:161
        import panelAuth #line:163
        OO0000O0000O000OO =panelAuth .panelAuth ().get_order_status (None );#line:164
        try :#line:165
            if OO0000O0000O000OO ['status']==True :#line:166
                session .vip =OO0000O0000O000OO #line:167
                return True #line:168
            return redirect ('/vpro');#line:169
        except :pass #line:170
        return False #line:171
    def GetOS (O00000O00O0O000O0 ):#line:174
        if not 'server_os'in session :#line:175
            OO000O0OOO000O0O0 ={}#line:176
            OO000O0OOO000O0O0 ['x']='Windows';#line:177
            OO000O0OOO000O0O0 ['osname']=''#line:178
            session ['server_os']=OO000O0OOO000O0O0 #line:180
