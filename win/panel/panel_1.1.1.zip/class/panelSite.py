#coding: utf-8
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2017 宝塔软件(http:#bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: 黄文良 <287962566@qq.com>
#-------------------------------------------------------------------

#------------------------------
# 网站管理类
#------------------------------
import io,re,public,os,sys,shutil,json,time,xmltodict
import xml.etree.ElementTree as ET
from xml.dom import minidom
from BTPanel import session 
from common import dict_obj
from flask import request

import xml.etree.ElementTree as ET
class panelSite:
    siteName = None #网站名称
    sitePath = None #根目录
    sitePort = None #端口
    phpVersion = None #PHP版本
    setupPath = None #安装路径
    isWriteLogs = None #是否写日志
    serverType = None #web服务器类型

    def __init__(self):
        self._iis_root = os.getenv("SYSTEMDRIVE") + '\\Windows\\System32\\inetsrv'
        self._appcmd = self._iis_root + '\\appcmd.exe'
        self.setupPath = public.GetConfigValue('setup_path')
        self.serverType = public.get_webserver()
        

    #添加网站
    def AddSite(self,get):
        import json,files
        siteMenu = json.loads(get.webname)
        self.siteName     = self.ToPunycode(siteMenu['domain'].split(':')[0]);
        self.sitePath     = self.ToPunycodePath(self.GetPath(get.path.replace(' ','')));
        self.sitePort     = get.port.replace(' ','');
        
        if self.sitePort == "": get.port = "80";
        if not public.checkPort(self.sitePort): return public.returnMsg(False,'SITE_ADD_ERR_PORT');
        
        if hasattr(get,'version'):
            self.phpVersion   = get.version.replace(' ','');
        else:
            self.phpVersion   = '00';
                
        domain = None
        if not files.files().CheckDir(self.sitePath): return public.returnMsg(False,'PATH_ERROR');
        if len(self.phpVersion) < 2: return public.returnMsg(False,'SITE_ADD_ERR_PHPEMPTY');
        reg = "^([\w\-\*]{1,100}\.){1,4}([\w\-]{1,24}|[\w\-]{1,24}\.[\w\-]{1,24})$";
        if not re.match(reg, self.siteName): return public.returnMsg(False,'SITE_ADD_ERR_DOMAIN');
        if self.siteName.find('*') != -1: return public.returnMsg(False,'SITE_ADD_ERR_DOMAIN_TOW');
        
        if not domain: domain = self.siteName;

        #是否重复
        sql = public.M('sites');
        if sql.where("name=?",(self.siteName,)).count(): return public.returnMsg(False,'SITE_ADD_ERR_EXISTS');
        opid = public.M('domain').where("name=?",(self.siteName,)).getField('pid');
        
        if opid:
            if public.M('sites').where('id=?',(opid,)).count():
                return public.returnMsg(False,'SITE_ADD_ERR_DOMAIN_EXISTS');
            public.M('domain').where('pid=?',(opid,)).delete();

        #创建根目录
        if not os.path.exists(self.sitePath): 
            os.makedirs(self.sitePath)
        if not os.path.exists(self.sitePath + '/.htaccess'):  public.writeFile(self.sitePath + '/.htaccess', ' ');

        #检查处理结果
        siteObj = { 'siteName' : self.siteName ,'siteDomain': self.siteName ,'sitePort':self.sitePort,'sitePath':self.sitePath ,'phpVersion':self.phpVersion }
        result = self.iisAdd(siteObj)
        if not result: return public.returnMsg(False,'SITE_ADD_ERR_WRITE');

        #创建basedir
        self.DelUserInI(self.sitePath);
        userIni = self.sitePath+'/.user.ini';
        if not os.path.exists(userIni):
            public.writeFile(userIni, 'open_basedir='+self.sitePath+'/;C:/Windows/Temp/;' + self.setupPath + '/temp/session/');

        #创建默认文档
        index = self.sitePath + '/index.html'
        if not os.path.exists(index):
            defaultHtml = public.readFile('data/defaultDoc.html')
            public.writeFile(index,defaultHtml)
        
        #创建自定义404页
        doc404 = self.sitePath + '/404.html'
        if not os.path.exists(doc404):
            html404 = public.readFile('data/404.html')
            public.writeFile(doc404, html404);
      
        ps = get.ps
        #添加放行端口
        if self.sitePort != '80':
            import firewalls
            get.port = self.sitePort
            get.ps = self.siteName;
            firewalls.firewalls().AddAcceptPort(get);
        
        #写入数据库
        get.pid = sql.table('sites').add('name,path,status,ps,type_id,addtime',(self.siteName,self.sitePath,'1',ps,get.type_id,public.getDate()))

        #添加更多域名
        for domain in siteMenu['domainlist']:
            get.domain = domain
            get.webname = self.siteName
            get.id = str(get.pid)
            self.AddDomain(get)
        
        sql.table('domain').add('pid,name,port,addtime',(get.pid,self.siteName,self.sitePort,public.getDate()))
        
        data = {}
        data['siteStatus'] = True
            
        #添加FTP
        data['ftpStatus'] = False
        if get.ftp == 'true':
            import ftp
            get.ps = self.siteName
            result = ftp.ftp().AddUser(get)
            if result['status']: 
                data['ftpStatus'] = True
                data['ftpUser'] = get.ftp_username
                data['ftpPass'] = get.ftp_password
        
        #添加数据库
        data['databaseStatus'] = False
        if get.sql == 'true' or get.sql == 'MySQL':
            import database
            if len(get.datauser) > 16: get.datauser = get.datauser[:16]
            get.name = get.datauser
            get.db_user = get.datauser
            get.password = get.datapassword
            get.address = '127.0.0.1'
            get.ps = self.siteName
            result = database.database().AddDatabase(get)
            if result['status']: 
                data['databaseStatus'] = True
                data['databaseUser'] = get.datauser
                data['databasePass'] = get.datapassword
        public.serviceReload()
        public.WriteLog('TYPE_SITE','SITE_ADD_SUCCESS',(self.siteName,))
        return data

    #删除网站
    def DeleteSite(self,get):
        id = get.id;
        siteName = get.webname;
        get.siteName = siteName
        
        #删除配置文件
        confPath = self.setupPath+'/panel/vhost/nginx/'+siteName+'.conf'
        if os.path.exists(confPath): os.remove(confPath)
        
        confPath = self.setupPath+'/panel/vhost/apache/' + siteName + '.conf';
        if os.path.exists(confPath): os.remove(confPath)
                
        public.ExecShell(self._appcmd + ' delete site "' + siteName + '"')
        public.ExecShell(self._appcmd + ' delete apppool "' + siteName + '"')

        #删除伪静态文件
        filename = confPath+'/rewrite/'+siteName+'.conf'
        if os.path.exists(filename): 
            os.remove(filename)

        #删除根目录
        if hasattr(get,'path'):
            import files
            get.path = public.M('sites').where("id=?",(id,)).getField('path');
            files.files().DeleteDir(get)
        
        #重载配置
        #public.serviceReload();

        #从数据库删除
        public.M('sites').where("id=?",(id,)).delete();
        public.M('binding').where("pid=?",(id,)).delete();
        public.M('domain').where("pid=?",(id,)).delete();
        public.WriteLog('TYPE_SITE', "SITE_DEL_SUCCESS",(siteName,));
        
        #是否删除关联数据库
        if hasattr(get,'database'):
            find = public.M('databases').where("pid=?",(id,)).field('id,name').find()
            if find:
                import database
                get.name = find['name']
                get.id = find['id']
                database.database().DeleteDatabase(get)
        
        #是否删除关联FTP
        if hasattr(get,'ftp'):
            find = public.M('ftps').where("pid=?",(id,)).field('id,name').find()
            if find:
                import ftp
                get.username = find['name']
                get.id = find['id']
                ftp.ftp().DeleteUser(get)
            
        return public.returnMsg(True,'SITE_DEL_SUCCESS')

      #添加子目录绑定
    def AddDirBinding(self,get):
        import shutil
        id = get.id
        tmp = get.domain.split(':')
        domain = tmp[0];
        port = '80'
        if len(tmp) > 1: port = tmp[1];
        if not hasattr(get,'dirName'): public.returnMsg(False, 'DIR_EMPTY');
        dirName = get.dirName; 
        
        reg = "^([\w\-\*]{1,100}\.){1,4}(\w{1,10}|\w{1,10}\.\w{1,10})$";
        if not re.match(reg, domain): return public.returnMsg(False,'SITE_ADD_ERR_DOMAIN');
        
        siteInfo = public.M('sites').where("id=?",(id,)).field('id,path,name').find();
        webdir = siteInfo['path'] + '/' + dirName;
        sql = public.M('binding');
        if sql.where("domain=?",(domain,)).count() > 0: return public.returnMsg(False, 'SITE_ADD_ERR_DOMAIN_EXISTS');
        if public.M('domain').where("name=?",(domain,)).count() > 0: return public.returnMsg(False, 'SITE_ADD_ERR_DOMAIN_EXISTS');
        
        get.siteName = siteInfo['name']
        phpVersion  = self.GetSitePHPVersion(get)
        if not phpVersion: return public.returnMsg(False, '主站PHP版本获取失败.');
        
        siteObj = { 'siteName' : domain + '_subdir','siteDomain': domain ,'sitePort':port,'sitePath':webdir ,'phpVersion': phpVersion['phpversion'] }
        if self.serverType == 'iis':
            result = self.iisAdd(siteObj)
        else:
            reuslt = False #apache / nginx
            #检查配置是否有误
            isError = public.checkWebConfig()
            if isError != True:
                shutil.copyfile('/tmp/backup.conf',filename)
                return public.returnMsg(False,'ERROR: <br><a style="color:red;">'+isError.replace("\n",'<br>')+'</a>');
        if not result:  return public.returnMsg(False, '子目录创建失败.');

        #创建默认文档
        index = webdir + '/index.html'
        if not os.path.exists(index):
            defaultHtml = public.readFile('data/defaultDoc.html')
            public.writeFile(index,defaultHtml)

        public.M('binding').add('pid,domain,port,path,addtime',(id,domain,port,dirName,public.getDate()));
        public.serviceReload();
        public.WriteLog('TYPE_SITE', 'SITE_BINDING_ADD_SUCCESS',(siteInfo['name'],dirName,domain));
        return public.returnMsg(True, 'ADD_SUCCESS');

    #删除子目录绑定
    def DelDirBinding(self,get):
        id = get.id
        binding = public.M('binding').where("id=?",(id,)).field('id,pid,domain,path').find();
        siteFind = public.M('sites').where("id=?",(binding['pid'],)).field('id,name,path').find()
        
        if self.serverType == 'iis':
            import shutil
            webpath = siteFind['path'] + '/' + binding['path']
            path1 = webpath + '/web.config'
            path2 = webpath + '/web_config'
            if os.path.exists(path1):os.remove(path1)
            if os.path.exists(path2): shutil.rmtree(webpath + '/web_config')
            webname = binding['domain'] + '_subdir'
                            
            public.ExecShell(self._appcmd + ' delete site "' + webname + '"')
            public.ExecShell(self._appcmd + ' delete apppool "' + webname + '"')

        else:
            #nginx
            filename = self.setupPath + '/panel/vhost/nginx/' + siteFind['name'] + '.conf';
            conf = public.readFile(filename);
            if conf:
                rep = "\s*.+BINDING-" + binding['domain'] + "-START(.|\n)+BINDING-" + binding['domain'] + "-END";
                conf = re.sub(rep, '', conf);
                public.writeFile(filename,conf)
        
            #apache
            filename = self.setupPath + '/panel/vhost/apache/' + siteFind['name'] + '.conf';
            conf = public.readFile(filename);
            if conf:
                rep = "\s*.+BINDING-" + binding['domain'] + "-START(.|\n)+BINDING-" + binding['domain'] + "-END";
                conf = re.sub(rep, '', conf);
                public.writeFile(filename,conf)
        
            filename = self.setupPath + '/panel/vhost/rewrite/' + siteFind['name'] + '_' + binding['path'] + '.conf';
            if os.path.exists(filename): os.remove(filename)

        public.M('binding').where("id=?",(id,)).delete();
        public.serviceReload();
        public.WriteLog('TYPE_SITE', 'SITE_BINDING_DEL_SUCCESS',(siteFind['name'],binding['path']));
        return public.returnMsg(True,'DEL_SUCCESS')

    #取子目录Rewrite
    def GetDirRewrite(self,get):
        id = get.id;
        find = public.M('binding').where("id=?",(id,)).field('id,pid,domain,path').find();
        site = public.M('sites').where("id=?",(find['pid'],)).field('id,name,path').find();
        
        data = {}
        data['status'] = False;

        if(self.serverType == 'iis'):
            new_get = dict_obj();
            new_get.siteName  = find['domain'] + '_subdir'
            print(new_get.siteName)
            data =  self.GetSiteRewrite(new_get)
        else:
            if(self.serverType == 'apache'):
                filename = site['path']+'/'+find['path']+'/.htaccess';
            else:
                filename = self.setupPath + '/panel/vhost/rewrite/'+site['name']+'_'+find['path']+'.conf';
        
            if hasattr(get,'add'):
                public.writeFile(filename,'')
                if public.get_webserver() == 'nginx':
                    file = self.setupPath + '/panel/vhost/nginx/'+site['name']+'.conf';
                    conf = public.readFile(file);
                    domain = find['domain'];
                    rep = "\n#BINDING-"+domain+"-START(.|\n)+BINDING-"+domain+"-END";
                    tmp = re.search(rep, conf).group();
                    dirConf = tmp.replace('rewrite/'+site['name']+'.conf;', 'rewrite/'+site['name']+'_'+find['path']+'.conf;');
                    conf = conf.replace(tmp, dirConf);
                    public.writeFile(file,conf)

            if os.path.exists(filename):
                data['status'] = True;
                data['data'] = public.readFile(filename);
                data['filename'] = filename;
          
        data['rlist'] = []
        for ds in os.listdir('rewrite/' + public.get_webserver()):
            if ds == 'list.txt': continue;
            data['rlist'].append(ds[0:len(ds)-5]);
        
        return data

    #iis添加网站
    def iisAdd(self,siteObj):
        if self.CreatePool(siteObj['siteName']): 
            get = dict_obj();
            get.filename = siteObj['sitePath']
            get.user = siteObj['siteName']
            get.access = 2032127
            import files
            rRet = files.files().SetFileAccess(get)
            if rRet['status']:                
                list = self.get_iis_sites()
                if not siteObj['siteName'] in list.keys():
                    path = siteObj['sitePath'].replace('/','\\')
      
                    public.ExecShell(self._appcmd + ' add site /name:"' + siteObj['siteName'] + '" /bindings:"http/*:' + siteObj['sitePort'] +':' + siteObj['siteDomain'] + '" /physicalPath:"' + path + '"')  
                    public.ExecShell(self._appcmd + ' set app "' + siteObj['siteName'] + '/" /applicationPool:"' + siteObj['siteName'] + '"') 

                    self.init_iisSite_config(siteObj['sitePath'] + '/web.config')
                    get = dict_obj();
                    get.siteName = siteObj['siteName']
                    get.version = siteObj['phpVersion']
                    self.SetPHPVersion(get)
                 
                    return True
        return False

    #创建应用程序池
    def CreatePool(self,name,version = '2.0',pipemodel= 'Integrated'):
        list = self.GetPoolList();
        if not name in list.keys():
            rRet = public.ExecShell(self._appcmd + ' add apppool /name:'+ name +' /managedRuntimeVersion:v' + version + ' /managedPipelineMode:' + pipemodel)            
            list = self.GetPoolList();
            if name in list.keys():
                return True
            return False
        return True
    
    #获取应用程序池列表
    def GetPoolList(self):
        rRet = public.ExecShell(self._appcmd + ' list apppool')
        tmps = re.findall('APPPOOL\s+\"(.+)\".+:v([\d\.]+).+MgdMode:(\w+).+state:(\w+)',rRet[0])
        data = {}
        for item in tmps:
            if len(item) >= 4:
                pool = { 'name': item[0],'version':item[1],'type':item[2],'status':item[3] }
                data[item[0]] = pool;
        return data

    def AddDomain(self,get):
        if len(get.domain) < 3: return public.returnMsg(False,'SITE_ADD_DOMAIN_ERR_EMPTY');
        domains = get.domain.split(',')
        for domain in domains:
            if domain == "": continue;
            domain = domain.split(':')
            get.zh_domain = domain[0]
            get.domain = self.ToPunycode(domain[0])
            get.port = '80'
            
            reg = "^([\w\-\*]{1,100}\.){1,4}([\w\-]{1,24}|[\w\-]{1,24}\.[\w\-]{1,24})$";
            if not re.match(reg, get.domain): return public.returnMsg(False,'SITE_ADD_DOMAIN_ERR_FORMAT');
            
            if len(domain) == 2: get.port = domain[1];
            if get.port == "": get.port = "80";

            if not public.checkPort(get.port): return public.returnMsg(False,'SITE_ADD_DOMAIN_ERR_POER');
            #检查域名是否存在
            sql = public.M('domain');
            opid = sql.where("name=? AND (port=? OR pid=?)",(get.domain,get.port,get.id)).getField('pid');
            if opid:
                if public.M('sites').where('id=?',(opid,)).count():
                    return public.returnMsg(False,'SITE_ADD_DOMAIN_ERR_EXISTS');
                sql.where('pid=?',(opid,)).delete();

            self.iisDomain(get)
            #添加放行端口
            if get.port != '80':
                import firewalls
                get.ps = get.domain;

            public.WriteLog('TYPE_SITE', 'DOMAIN_ADD_SUCCESS',(get.webname,get.domain));
            sql.table('domain').add('pid,name,port,addtime',(get.id,get.domain,get.port,public.getDate()));

        return public.returnMsg(True,'SITE_ADD_DOMAIN');

    #iis添加域名
    def iisDomain(self,get):
        shell = " set site " + get.webname + " /+bindings.[protocol='http',bindingInformation='*:" + get.port + ":" + get.zh_domain + "']"
        rRet = public.ExecShell(self._appcmd + shell)
        return True

    #删除域名
    def DelDomain(self,get):
        sql = public.M('domain');
        id=get['id'];
        port = get.port;
        find = sql.where("pid=? AND name=?",(get.id,get.domain)).field('id,name').find();
        domain_count = sql.table('domain').where("pid=?",(id,)).count();
        if domain_count == 1: return public.returnMsg(False,'SITE_DEL_DOMAIN_ERR_ONLY');
        
        shell = " set site " + get.webname + " /-bindings.[protocol='http',bindingInformation='*:" + get.port + ":" + get.domain + "']"
        rRet = public.ExecShell(self._appcmd + shell)
        if find : sql.table('domain').where("id=?",(find['id'],)).delete();
        public.WriteLog('TYPE_SITE', 'DOMAIN_DEL_SUCCESS',(get.webname,get.domain));
        return public.returnMsg(True,'DEL_SUCCESS');

    #启动站点
    def SiteStart(self,get):
        id = get.id
        Path = self.setupPath + '/stop';
        sitePath = public.M('sites').where("id=?",(id,)).getField('path');
        
        #nginx
        file = self.setupPath + '/panel/vhost/nginx/'+get.name+'.conf';
        conf = public.readFile(file);
        if conf:
            conf = conf.replace(Path, sitePath);
            public.writeFile(file,conf)
        #apaceh
        file = self.setupPath + '/panel/vhost/apache/'+get.name+'.conf';
        conf = public.readFile(file);
        if conf:
            conf = conf.replace(Path, sitePath);
            public.writeFile(file,conf)
        
        #iis
        rRet = public.ExecShell(self._appcmd + ' start site "' + get.name + '"')

        public.M('sites').where("id=?",(id,)).setField('status','1');
        public.serviceReload();
        public.WriteLog('TYPE_SITE','SITE_START_SUCCESS',(get.name,))
        return public.returnMsg(True,'SITE_START_SUCCESS')

    #停止站点
    def SiteStop(self,get):
        path = self.setupPath + '/stop';
        id = get.id
        if not os.path.exists(path):
            os.makedirs(path)
            public.downloadFile('http://download.bt.cn/stop.html',path + '/index.html');
        
        binding = public.M('binding').where('pid=?',(id,)).field('id,pid,domain,path,port,addtime').select();
        for b in binding:
            bpath = path + '/' + b['path'];
            if not os.path.exists(bpath): 
                os.makedirs(bpath)
                public.writeFile(bpath + '/index.html',public.readFile(path + '/index.html'))
        
        sitePath = public.M('sites').where("id=?",(id,)).getField('path');
        
        #nginx
        file = self.setupPath + '/panel/vhost/nginx/'+get.name+'.conf';
        conf = public.readFile(file);
        if conf:
            conf = conf.replace(sitePath,path);
            public.writeFile(file,conf)
        
        #apache
        file = self.setupPath + '/panel/vhost/apache/'+get.name+'.conf';
        conf = public.readFile(file);
        if conf:
            conf = conf.replace(sitePath,path);
            public.writeFile(file,conf)

        #iis
        rRet = public.ExecShell(self._appcmd + ' stop site "' + get.name + '"')

        public.M('sites').where("id=?",(id,)).setField('status','0');
        public.serviceReload();
        public.WriteLog('TYPE_SITE','SITE_STOP_SUCCESS',(get.name,))
        return public.returnMsg(True,'SITE_STOP_SUCCESS')
    
    #获取站点目录
    def get_site_path(self,siteName):
        path = None
        rRet = public.ExecShell(self._appcmd + ' list vdir /app.name:"' + siteName + '/" /text:physicalPath')
        if rRet[0]:
            path = rRet[0].strip()
        return path
    
    #修改物理路径
    def SetPath(self,get):
        id = get.id
        Path = self.GetPath(get.path);
        if Path == "" or id == '0': return public.returnMsg(False,  "DIR_EMPTY");

        import files
        f = files.files()
        if not f.CheckDir(Path): return public.returnMsg(False,  "PATH_ERROR");

        SiteFind = public.M("sites").where("id=?",(id,)).field('path,name').find();
        if SiteFind["path"] == Path: return public.returnMsg(False,  "SITE_PATH_ERR_RE");
        Name = SiteFind['name'];

        if not os.path.exists(Path): os.makedirs(Path)        
        get.filename = Path
        get.user = 'www'
        get.access = 2032127
        rRet = f.SetFileAccess(get)

        webserver = public.get_webserver()  
        if webserver == 'iis':
            get.user = Name
            rRet = f.SetFileAccess(get)
            public.ExecShell(self._appcmd + ' set app "' + Name + '/" -[path=\'/\'].physicalPath:' + Path.replace('/','\\'))
            self.init_iisSite_config(Path + '/web.config')

        public.serviceReload();
        public.M("sites").where("id=?",(id,)).setField('path',Path);
        public.WriteLog('TYPE_SITE', 'SITE_PATH_SUCCESS',(Name,));
        return public.returnMsg(True,  "SET_SUCCESS");

    #从IIS获取站点
    def get_iis_sites(self):
        rRet = public.ExecShell(self._appcmd + ' list sites')
        temp = re.findall("SITE\s+\"(.+)\"\s+\((.*)\)",rRet[0])
        list = {}
        for item in temp:
            site = {}
            site['name'] = item[0]
            attrs = re.findall("(\w+:\w+)(,|$)|(bindings:https?/\*:\d+:.+),",item[1])
            for attr in attrs:
               vstr = attr[0] + attr[2]
               arr_groups = re.search("(.+?):(.*)",vstr).groups()
               if len(arr_groups) == 2:
                    if arr_groups[0] == 'bindings':
                        site[arr_groups[0]] = []
                        domains = arr_groups[1].split(',')
                        for ditem in domains:
                            d_list = re.search("(\w+)/.:(\d+):(.*)",ditem)
                            if d_list:
                                list_group = d_list.groups()
                                site[arr_groups[0]].append({ 'port':list_group[1],'domain':list_group[2],'protocol':list_group[0] }) 
                    else:
                        site[arr_groups[0]] =  arr_groups[1]            
            list[item[0]] = site
        return list

    #清除多余user.ini
    def DelUserInI(self,path,up = 0):
        for p1 in os.listdir(path):
            try:
                npath = path + '/' + p1;
                if os.path.isdir(npath):
                    if up < 100: self.DelUserInI(npath, up + 1);
                else:
                    continue;
                useriniPath = npath + '/.user.ini';
                if not os.path.exists(useriniPath): continue;
                os.remove(useriniPath)
            except: continue;
        return True;
    
    #设置目录防御
    def SetDirUserINI(self,get):
        path = get.path
        filename = path + '/.user.ini';
        self.DelUserInI(path);
        if os.path.exists(filename):           
            os.remove(filename)
            return public.returnMsg(True, 'SITE_BASEDIR_CLOSE_SUCCESS');
        public.writeFile(filename, 'open_basedir=' + path +'/;C:/Windows/Temp/;' + self.setupPath + '/temp/session/');
        return public.returnMsg(True,'SITE_BASEDIR_OPEN_SUCCESS');

    #域名编码转换
    def ToPunycode(self,domain):
        import re;
        if sys.version_info[0] == 2: domain = domain.encode('utf8');
        tmp = domain.split('.');
        newdomain = '';
        for dkey in tmp:
                #匹配非ascii字符
                match = re.search(u"[\x80-\xff]+",dkey);
                if not match:
                    newdomain += dkey + '.';
                else:
                    newdomain += 'xn--' + dkey.decode('utf-8').encode('punycode') + '.'
        return newdomain[0:-1];
    
    #中文路径处理
    def ToPunycodePath(self,path):
        if sys.version_info[0] == 2: path = path.encode('utf-8');
        if os.path.exists(path): return path;
        import re;
        match = re.search(u"[\x80-\xff]+",path);
        if not match: return path;
        npath = '';
        for ph in path.split('/'):
            npath += '/' + self.ToPunycode(ph);
        return npath.replace('//','/')

    #获取当前可用php版本
    def GetPHPVersion(self,get):
        phpVersions = ('00','52','53','54','55','56','70','71','72','73','74')
        data = []
        for val in phpVersions:
            tmp = {}
            checkPath = self.setupPath+'/php/'+val+'/php.exe';
            tmp['version'] = val;
            tmp['name'] = 'PHP-'+val;
            if val == '00':
                if val == '00': tmp['name'] = '纯静态';
                data.append(tmp)
            else:
                if os.path.exists(checkPath):
                    data.append(tmp)
        return data
    
    #是否开启目录防御
    def GetDirUserINI(self,get):       
        path = get.path;
        data = {}
        id = get.id;
        get.name = public.M('sites').where("id=?",(id,)).getField('name');           
        data['logs'] = self.GetLogsStatus(get);
        data['userini'] = False;
        if os.path.exists(path+'/.user.ini'):
            data['userini'] = True;
        if os.path.exists(path):                        
            data['runPath'] = self.GetSiteRunPath(get);
            data['pass'] = self.GetHasPwd(get);          
        return data;
    
    #取目录加密状态
    def GetHasPwd(self,get):
        if not hasattr(get,'siteName'):
            get.siteName = public.M('sites').where('id=?',(get.id,)).getField('name');
        return False;

    #取日志状态
    def GetLogsStatus(self,get):
        webserver = public.get_webserver()  
        if webserver == 'iis':
            data = self.get_site_info(get.name)
            return data['logs']
        else:
            filename = self.setupPath + '/panel/vhost/'+public.get_webserver()+'/' + get.name + '.conf';
            conf = public.readFile(filename);
            if conf.find('#ErrorLog') != -1: return False;
            if conf.find("access_log  off") != -1: return False;
            return True;


    #取当站点前运行目录
    def GetSiteRunPath(self,get):
        SiteFind = public.M("sites").where("id=?",(get.id,)).field('path,name').find();
        info = self.get_site_info(SiteFind['name'])
        data = {}
        if info['path']:            
            if SiteFind['path'] == info['path']: 
                data['runPath'] = '/';
            else:
                data['runPath'] = info['path'].replace(SiteFind['path'],'');
        
            dirnames = []
            dirnames.append('/');
            for filename in os.listdir(SiteFind['path']):
                try:
                    filePath = SiteFind['path'] + '/' + filename
                    if os.path.islink(filePath): continue
                    if os.path.isdir(filePath):
                        dirnames.append('/' + filename)
                except:
                    pass        
            data['dirs'] = dirnames;
        return data;

    #设置当前站点运行目录
    def SetSiteRunPath(self,get):
        SiteFind = public.M("sites").where("id=?",(get.id,)).field('path,name').find();
        webserver = public.get_webserver()  
        if webserver == 'iis':
            data = self.get_site_info(SiteFind['name'])
            new_path = self.GetPath(SiteFind['path'] + get.runPath)
            public.ExecShell(self._appcmd + ' set app "' + SiteFind['name'] + '/" -[path=\'/\'].physicalPath:' + new_path.replace('/','\\'))
            shutil.move(data['path'] + '/web.config', new_path + '/web.config')
            shutil.move(data['path'] + '/web_config', new_path + '/web_config')
        else:
        #处理Nginx
            filename = self.setupPath + '/panel/vhost/nginx/' + SiteFind['name'] + '.conf'
            if os.path.exists(filename):
                conf = public.readFile(filename)
                rep = '\s*root\s*(.+);'
                path = re.search(rep,conf).groups()[0];
                conf = conf.replace(path,SiteFind['path'] + get.runPath);
                public.writeFile(filename,conf);
            
            #处理Apache
            filename = self.setupPath + '/panel/vhost/apache/' + SiteFind['name'] + '.conf'
            if os.path.exists(filename):
                conf = public.readFile(filename)
                rep = '\s*DocumentRoot\s*"(.+)"\s*\n'
                path = re.search(rep,conf).groups()[0];
                conf = conf.replace(path,SiteFind['path'] + get.runPath);
                public.writeFile(filename,conf);
        
        public.serviceReload();
        return public.returnMsg(True,'SET_SUCCESS');

    #路径处理
    def GetPath(self,path):
        if path[-1] == '/':
            return path[0:-1];
        return path;

    #取指定站点的PHP版本
    def GetSitePHPVersion(self,get):
       #try:
        Name = get.siteName
        webserver = public.get_webserver()  
        if webserver == 'iis':
            sitePath = self.get_site_path(Name)          
            phpConf = public.readFile(sitePath + '/web_config/php.config')
            tmp = re.search('php\\\(\d{2})\\\php-cgi',phpConf).groups()

            data = {}
            data['phpversion'] = tmp[0];
            return data;
       #except :
       #    return public.returnMsg(False,'SITE_PHPVERSION_ERR_A22');

       
    #设置指定站点的PHP版本
    def SetPHPVersion(self,get):
        siteName = get.siteName
        version = get.version
        
        #nginx
        file = self.setupPath + '/panel/vhost/nginx/'+siteName+'.conf';
        conf = public.readFile(file);
        if conf:
            rep = "enable-php-([0-9]{2,3})\.conf";
            tmp = re.search(rep,conf).group()
            conf = conf.replace(tmp,'enable-php-'+version+'.conf');
            public.writeFile(file,conf)
        
        #apache
        file = self.setupPath + '/panel/vhost/apache/'+siteName+'.conf';
        conf = public.readFile(file);
        if conf:
            rep = "php-cgi-([0-9]{2,3})\.sock";
            tmp = re.search(rep,conf).group()
            conf = conf.replace(tmp,'php-cgi-'+version+'.sock');
            public.writeFile(file,conf)
        
        #iis
        sitePath = self.get_site_path(siteName)
        if sitePath:            
            print(self.setupPath,version)
            phpPath = (self.setupPath + '/php/'+version+'/php-cgi.exe').replace('/','\\')
            phpVersions = ['52','53','54','55','56','70','71','72','73','74','75']
            
            hlist = []
            for v in phpVersions:
                hlist.append({'@name':'php_' + v })

            php_config = {"handlers": { "remove":hlist,"add": {"@name": "php_" + version, "@path": "*.php", "@verb": "*", "@modules": "FastCgiModule", "@scriptProcessor": phpPath, "@resourceType": "Unspecified", "@requireAccess": "Script"} }}
            public.writeFile(sitePath + '/web_config/php.config', self.format_xml(self.dumps_json(php_config)))

        public.serviceReload();
        public.WriteLog("TYPE_SITE", "SITE_PHPVERSION_SUCCESS",(siteName,version));
        return public.returnMsg(True,'SITE_PHPVERSION_SUCCESS',(siteName,version));



    #设置默认文档
    def SetIndex(self,get):
        id = get.id;
        if get.Index.find('.') == -1: return public.returnMsg(False,  'SITE_INDEX_ERR_FORMAT')
        
        Index = get.Index.replace(' ', '')
        Index = get.Index.replace(',,', ',')
        
        if len(Index) < 3: return public.returnMsg(False,  'SITE_INDEX_ERR_EMPTY')
        
        
        Name = public.M('sites').where("id=?",(id,)).getField('name');
        #准备指令
        Index_L = Index.replace(",", " ");
        
        #nginx
        file = self.setupPath + '/panel/vhost/nginx/' + Name + '.conf';
        conf = public.readFile(file);
        if conf:
            rep = "\s+index\s+.+;";
            conf = re.sub(rep,"\n\tindex " + Index_L + ";",conf);
            public.writeFile(file,conf);
        
        #apache
        file = self.setupPath + '/panel/vhost/apache/' + Name + '.conf';
        conf = public.readFile(file);
        if conf:
            rep = "DirectoryIndex\s+.+\n";
            conf = re.sub(rep,'DirectoryIndex ' + Index_L + "\n",conf);
            public.writeFile(file,conf);

        #iis
        list = Index.split(',')
        for x in list:
            pass

        
        public.serviceReload();
        public.WriteLog('TYPE_SITE', 'SITE_INDEX_SUCCESS',(Name,Index_L));
        return public.returnMsg(True,  'SET_SUCCESS')

    #读取网站配置
    def get_site_config(self,get):
        Name = get.siteName
        webserver = public.get_webserver()        
        get = dict_obj();
        if webserver == 'iis':
            sitePath = self.get_site_path(Name)
            get.path = sitePath + '/web.config'

        import files
        result = files.files().GetFileBody(get)
        return result

    #保存网站配置
    def set_site_config(self,get):
        Name = get.siteName
        webserver = public.get_webserver()        
        if webserver == 'iis':
            sitePath = self.get_site_path(Name)
            get.path = sitePath + '/web.config'

        import files
        result = files.files().SaveFileBody(get)
        return result

    #取默认文档
    def GetIndex(self,get):
        id = get.id;
        Name = public.M('sites').where("id=?",(id,)).getField('name');
        webserver = public.get_webserver()

        if webserver == 'iis':
            list = ['index.aspx','index.asp','index.php','default.html','default.htm','index.htm','index.html','default.aspx']
            sitePath = self.get_site_path(Name)
            confPath = sitePath + '/web_config/default.config'
            if os.path.exists(confPath):
                conf = public.readFile(confPath)
                tmps = re.findall('<add\s+value=\"(.+)\"\s?/>',conf)
                list = []
                for item in tmps:
                    list.append(item)
            return ','.join(list)
        else:
            file = self.setupPath + '/panel/vhost/'+public.get_webserver()+'/' + Name + '.conf';
            conf = public.readFile(file)
            if webserver == 'nginx':
                rep = "\s+index\s+(.+);";
            else:
                rep = "DirectoryIndex\s+(.+)\n";
            
            tmp = re.search(rep,conf).groups()
            return tmp[0].replace(' ',',')


    #取子目录绑定
    def GetDirBinding(self,get):
        path = public.M('sites').where('id=?',(get.id,)).getField('path')
        if not os.path.exists(path): 
            import files
            if not files.files().CheckDir(path):
                data = {}
                data['dirs'] = []
                data['binding'] = []
                return data;
            os.makedirs(get.path)
            siteName = public.M('sites').where('id=?',(get.id,)).getField('name')
            public.WriteLog('网站管理','站点['+siteName+'],根目录['+path+']不存在,已重新创建!');
        dirnames = []
        for filename in os.listdir(path):
            try:
                filePath = path + '/' + filename
                if os.path.islink(filePath): continue
                if os.path.isdir(filePath):
                    dirnames.append(filename)
            except:
                pass
        
        data = {}
        data['dirs'] = dirnames
        data['binding'] = public.M('binding').where('pid=?',(get.id,)).field('id,pid,domain,path,port,addtime').select()
        return data


    #取伪静态规则应用列表
    def GetRewriteList(self,get):     
        rewriteList = {}
        if public.get_webserver() == 'apache': 
            get.id = public.M('sites').where("name=?",(get.siteName,)).getField('id');
            runPath = self.GetSiteRunPath(get);
            rewriteList['sitePath'] = public.M('sites').where("name=?",(get.siteName,)).getField('path') + runPath['runPath'];
            
        rewriteList['rewrite'] = []
        rewriteList['rewrite'].append('0.'+public.getMsg('SITE_REWRITE_NOW'))
        for ds in os.listdir('rewrite/' + public.get_webserver()):
            if ds == 'list.txt': continue;
            rewriteList['rewrite'].append(ds[0:len(ds)-5]);
        rewriteList['rewrite'] = sorted(rewriteList['rewrite']);
        return rewriteList
    
    #保存伪静态模板
    def SetRewriteTel(self,get):
        get.name = get.name.encode('utf-8');
        filename = 'rewrite/' + public.get_webserver() + '/' + get.name + '.conf';
        public.writeFile(filename,get.data);
        return public.returnMsg(True, 'SITE_REWRITE_SAVE');
    
    #获取伪静态内容
    def GetSiteRewrite(self,get):
        Name =  get.siteName;
        webserver = public.get_webserver()  

        result = {}
        result['status'] = False
        result['data'] = ''

        if webserver == 'iis':
            sitePath = self.get_site_path(Name)
            rewConf = public.readFile(sitePath + '/web_config/rewrite.config')
            old_data = xmltodict.parse(rewConf)
           
            data = {}    
            rules = []
            if old_data['rules']:
                if 'rule' in old_data['rules']:  
                    list = old_data['rules']['rule']
                    if type(list) == type([1,]):                        
                        for rule in old_data['rules']['rule']:
                            if rule['@name'].find('_rewrite') >= 0:
                               rules.append(rule)
                    else:
                        rules.append(list)

            result['status'] = True
            if len(rules):
                data['rules'] = {};
                data['rules']['rule'] = rules
                result['data'] =  self.format_xml(self.dumps_json(data))
        return result

    #保存伪静态
    def SetSiteRewrite(self,get):
        Name =  get.siteName;
        webserver = public.get_webserver()  
        if webserver == 'iis':
            data = None
            #try:      
            sitePath = self.get_site_path(Name)
            #组装新的伪静态规则
            new_list = []
            tmps = re.findall('<rule[\s+>][\w\W]+?/rule>',get.data)
            for nVal in tmps:
                item = xmltodict.parse(nVal)
                if item['rule']:
                    if '@name' in item['rule']:
                        item['rule']['@name'] = item['rule']['@name'].replace('_rewrite','') + '_rewrite'
                    else:
                        item['rule']['@name'] = public.GetRandomString(6) + '_rewrite'
                    new_list.append(item['rule'])
                
            #清理旧的伪静态规则
            rewConf = public.readFile(sitePath + '/web_config/rewrite.config')
            old_data = xmltodict.parse(rewConf)
            if old_data['rules']:
                if not 'rule' in old_data['rules']:
                    old_data['rules']['rule'] = []
                else:
                    if type(old_data['rules']['rule']) == type([1,]):
                        for x in range(len(old_data['rules']['rule'])-1,-1,-1):
                            rule = old_data['rules']['rule'][x]
                            if rule['@name'].find('_rewrite') >= 0:
                                old_data['rules']['rule'].pop(x)
                    else:
                        if old_data['rules']['rule']['@name'].find('_rewrite') >= 0:
                            old_data['rules']['rule'] = []
                
            for new_rule in new_list:
                old_data['rules']['rule'].append(new_rule)
                                
            public.writeFile(sitePath + '/web_config/rewrite.config', self.format_xml(self.dumps_json(old_data)))
            return public.returnMsg(True, 'SITE_REWRITE_SAVE');
            #except :
            #    return public.returnMsg(False, 'iis伪静态格式不正确,不是有效的xml格式');



    #读取xml文件
    def read_xml(self,confPath):
        if os.path.exists(confPath):            
            try:
                tree = ET.parse(confPath)
                return tree
            except :  
                print('error')
                public.writeFile(confPath + '.bt',public.readFile(confPath))            
        return False      
     
    #从文件读取xml转为json对象
    def loads_json(self,xml_path):
        data = {}
        try:
            xml_str = public.readFile(xml_path)
            data = xmltodict.parse(xml_str)
        except :  pass
        return data

    #json对象转为xml文件
    def dumps_json(self,jsonstr):
        xmlstr = xmltodict.unparse(jsonstr)
        return xmlstr

    #格式化xml
    def format_xml(self,xmlStr):
        b = minidom.parseString(xmlStr)
        c = b.toprettyxml(indent = "\t")
        return c
    
    #初始化web.config
    def init_iisSite_config(self,confPath):
        #合并主配置文件
        default_config = {"configuration": {"system.webServer": {"rewrite": {"rules": {"@configSource": "web_config\\rewrite.config"}}, "defaultDocument": {"@configSource": "web_config\\default.config"}, "httpErrors": {"@configSource": "web_config\\httpErrors.config"}, "handlers": {"@configSource": "web_config\\php.config"}}}}
        data = self.loads_json(confPath)                
        for k1 in default_config:
            if not k1 in data: data[k1] = default_config[k1]                
            for k2 in default_config[k1]:
                if not k2 in data[k1]: data[k1][k2] = default_config[k1][k2]
                for k3 in default_config[k1][k2]:
                    data[k1][k2][k3] = default_config[k1][k2][k3]
                    for k4 in default_config[k1][k2][k3]:
                        data[k1][k2][k3][k4] = default_config[k1][k2][k3][k4]
        
        #创建单个配置文件
        webPath = confPath.replace('web.config','web_config')
        if not os.path.exists(webPath):  os.makedirs(webPath)
        list = [
                { "path":confPath ,"data":data},
                { "path":webPath + '/rewrite.config',"data": {"rules": {"clear": {}}}},
                { "path":webPath + '/default.config' ,"data": {"defaultDocument": {"files": {"clear": {}, "add": [{"@value": "index.php"}, {"@value": "index.aspx"}, {"@value": "index.asp"}, {"@value": "default.html"}, {"@value": "Default.htm"}, {"@value": "Default.asp"}, {"@value": "index.htm"}, {"@value": "index.html"}, {"@value": "iisstart.htm"}, {"@value": "default.aspx"}]}}}},
                { "path":webPath + '/httpErrors.config' ,"data":  {"httpErrors": {"@errorMode": "DetailedLocalOnly"}}},
                { "path":webPath + '/php.config' ,"data": {"handlers": {}} }        
            ]
        for x in list:
            public.writeFile(x['path'], self.format_xml(self.dumps_json(x['data'])))

        return True

    #获取网站详情
    def get_site_info(self,siteName):
        #try:
        data = {}
        serverType = public.get_webserver();      
        if serverType == 'iis':            
            rRet = public.ExecShell(self._appcmd + ' list site "' + siteName + '" /config')
            if not rRet[0]: return False

            data['name'] = siteName          
            data['id'] = re.search('id=\"(\d+)\"',rRet[0]).groups()[0]                       
            try:
                    data['pool'] = re.search('applicationPool=\"(.+)\"',rRet[0]).groups()[0]
            except :
                    data['pool'] = 'DefaultAppPool'

            data['path'] = re.search('physicalPath=\"(.+)\"',rRet[0]).groups()[0].replace('\\','/')

            lRet = public.ExecShell(self._appcmd + ' list config "' + siteName + '/" /section:httpLogging /config:*')
            data['logs'] = True
            if lRet[0].find('dontLog="true"') >=0 : data['logs'] = False                    

            data['start'] = True
            if rRet[0].find('serverAutoStart="false"') >=0 : data['start'] = False    
                        
            limit = {}
            connectionTimeout = 0
            tmp1 = re.search('connectionTimeout=\"([\d:]+)\"?',rRet[0])
            if tmp1:
                timeout = tmp1.groups()[0]
                ts = time.strptime(timeout,"%H:%M:%S")
                connectionTimeout = ts.tm_hour * 3600 + ts.tm_min * 60 + ts.tm_sec
                
            maxConnections = 0
            tmp2 = re.search('maxConnections=\"(\d+)\"',rRet[0])
            if tmp2:
                    maxConnections = int(tmp2.groups()[0])
               
            maxBandwidth = 0
            tmp3 = re.search('maxBandwidth=\"(\d+)\"',rRet[0])
            if tmp3:
                    maxBandwidth = int(tmp3.groups()[0])

            if maxConnections == 4294967295: maxConnections = 0
            if maxBandwidth == 4294967295: maxBandwidth = 0              

            limit['perserver'] = maxConnections;
            limit['timeout'] = connectionTimeout
            limit['limit_rate'] = maxBandwidth / 1024
            data['limit'] = limit
            tmps = re.findall('<binding\s+.+/>',rRet[0])
            data['domains'] = []
            for binds in tmps:
                try:
                    binding = {}
                    b_tmps = re.search('protocol=\"(\w+)\".+:(\d+):(.*)\"',binds).groups()
                    binding['protocol'] = b_tmps[0]
                    binding['port'] = b_tmps[1]
                    binding['domain'] = b_tmps[2]
                    data['domains'].append(binding)   
                except :
                    pass   
        else:
            pass
        return data
        #except :
        #    False

    #日志开关
    def logsOpen(self,get):
        get.name = public.M('sites').where("id=?",(get.id,)).getField('name');
        serverType = public.get_webserver();      
        if serverType == 'iis':
            data = self.get_site_info(get.name)
            dontLog = 'False'
            if data['logs']:  dontLog = 'True'                
            public.ExecShell(self._appcmd + ' set config "' + get.name + '" -section:system.webServer/httpLogging /dontLog:"' + dontLog + '" /commit:apphost')
            
        public.serviceReload();
        return public.returnMsg(True, 'SUCCESS');

    #取网站日志
    def GetSiteLogs(self,get):
        serverType = public.get_webserver();      
        if serverType == 'iis':
            data = self.get_site_info(get.siteName)
            tm = time.localtime()
            name = 'u_ex'+ str(tm.tm_year)[-2:] + str(tm.tm_mon) +str(tm.tm_mday)
            logPath = self.setupPath + '/wwwlogs/W3SVC' + data['id'] + '/' + name + '.log';
            print(logPath)
            if os.path.exists(logPath): 
                return public.returnMsg(True,public.GetNumLines(logPath,1000));           
        return public.returnMsg(False,'日志为空'); 
    
    #取反向代理
    def GetProxy(self,get):
        return public.returnMsg(False,'IIS暂不支持反向代理.'); 
    
    #取流量限制值
    def GetLimitNet(self,get):
        id = get.id
        
        #取回配置文件
        siteName = public.M('sites').where("id=?",(id,)).getField('name');
        data = {}
        serverType = public.get_webserver();      
        if serverType == 'iis':           
            try:
                info = self.get_site_info(siteName)
                data = info['limit']
            except:
                data['perserver'] = 0
                data['perip'] = 0
                data['limit_rate'] = 0        
        return data;
    
    
    #设置流量限制
    def SetLimitNet(self,get):
        if(public.get_webserver() != 'iis'): return public.returnMsg(False, 'SITE_NETLIMIT_ERR');
        
        id = get.id;
        siteName = public.M('sites').where("id=?",(id,)).getField('name');
        if siteName:           
            m, s = divmod(int(get.timeout), 60)
            h, m = divmod(m, 60)
            ts = "%02d:%02d:%02d" % (h, m, s)
            public.ExecShell(self._appcmd + ' set config -section:system.applicationHost/sites "/[name=\''+ siteName +'\'].limits.maxConnections:'+ get.perserver +'" /commit:apphost')
            public.ExecShell(self._appcmd + ' set config -section:system.applicationHost/sites "/[name=\''+ siteName +'\'].limits.maxBandwidth:'+ str((int(get.limit_rate) * 1024)) +'" /commit:apphost')
            public.ExecShell(self._appcmd + ' set config -section:system.applicationHost/sites "/[name=\''+ siteName +'\'].limits.connectionTimeout:'+ ts +'" /commit:apphost')

            print('set config -section:system.applicationHost/sites "/[name=\''+ siteName +'\'].limits.maxConnections:'+ get.perserver +'" /commit:apphost')
            public.serviceReload();
            public.WriteLog('TYPE_SITE','SITE_NETLIMIT_OPEN_SUCCESS',(siteName,))
            return public.returnMsg(True, 'SET_SUCCESS');
        return public.returnMsg(False, '设置失败，站点不存在！');
    
    #关闭流量限制
    def CloseLimitNet(self,get):
        id = get.id
        #取回配置文件
        siteName = public.M('sites').where("id=?",(id,)).getField('name');
        if siteName:           
            public.ExecShell(self._appcmd + ' set config -section:system.applicationHost/sites "/[name=\''+ siteName +'\'].limits.maxBandwidth:4294967295" /commit:apphost')
            public.ExecShell(self._appcmd + ' set config -section:system.applicationHost/sites "/[name=\''+ siteName +'\'].limits.maxConnections:4294967295" /commit:apphost')
            public.ExecShell(self._appcmd + ' set config -section:system.applicationHost/sites "/[name=\''+ siteName +'\'].limits.connectionTimeout:00:02:00" /commit:apphost')

        public.serviceReload();
        public.WriteLog('TYPE_SITE','SITE_NETLIMIT_CLOSE_SUCCESS',(siteName,))
        return public.returnMsg(True, 'SITE_NETLIMIT_CLOSE_SUCCESS');   

    #取SSL状态
    def GetSSL(self,get):
        siteName = get.siteName
        serverType = public.get_webserver(); 
        data = {}
        data['status'] = False
        data['httpTohttps'] = False
        data['type'] = -1
        certPath = self.setupPath + '/panel/vhost/cert/'+ siteName
        if serverType == 'iis':  
            data['data'] = []            
            info = self.get_site_info(siteName)
            for domain in info['domains']:
                if domain['protocol'] == 'https':
                    data['status'] = True;
                    break;
            
            #获取iis证书列表
            serverType = public.get_webserver(); 
            if serverType == 'iis':   
                tmp_path = self.setupPath + '/temp/ssl'
                if not os.path.exists(tmp_path): os.makedirs(tmp_path)

                if data['status'] == True:
                    sys_versions = public.get_sys_version()
                    bind_exec = 'netsh http show sslcert hostnameport=' + siteName + ':443'                          
                    if int(sys_versions[0]) == 6 and int(sys_versions[1]) == 1:
                        bind_exec = 'netsh http show sslcert ipport=0.0.0.0:443'                
                    rRet = public.ExecShell(bind_exec)     
                    hashStr = re.search(':\s+(\w{40})',rRet[0]).groups()[0].upper()
                import panelSSL
                ss = panelSSL.panelSSL();
                for name in os.listdir(tmp_path):                
                    if name[-4:].strip() == '.pfx':
                        cert = { 'name' : name, 'password' :'', 'setup':False }
                        if os.path.exists(tmp_path + '/' + name[:-4]): cert['password'] = public.readFile(tmp_path + '/' + name[:-4])                    
                       
                        get.certPath = tmp_path + '/' + name
                        get.password = cert['password']                      
                        hashData = ss.GetCertName(get)                          
                        if hashData and data['status']:
                            if hashStr == hashData['hash']: cert['setup'] = True
                        data['data'].append(cert)

        id = public.M('sites').where("name=?",(siteName,)).getField('id');
        data['domain'] = public.M('domain').where("pid=?",(id,)).field('name').select();
        if data['status']: 
            data['type'] = 0           
            if os.path.exists(certPath + '/partnerOrderId'): data['type'] = 2
        data['httpTohttps'] = self.IsToHttps(siteName);
        return data

    #获取站点所有域名
    def GetSiteDomains(self,get):
        data = {}
        domains = public.M('domain').where('pid=?',(get.id,)).field('name,id').select()
        binding = public.M('binding').where('pid=?',(get.id,)).field('domain,id').select()
        if type(binding) == str: return binding
        for b in binding:
            tmp = {}
            tmp['name'] = b['domain']
            tmp['id'] = b['id']
            domains.append(tmp)
        data['domains'] = domains
        data['email'] = public.M('users').getField('email')
        if data['email'] == '287962566@qq.com': data['email'] = ''
        return data


     #添加SSL配置
    def SetSSLConf(self,get):         
        siteName = get.siteName         
        path = self.setupPath + '/panel/vhost/cert/'+ siteName;
        serverType = public.get_webserver(); 
        if serverType == 'iis':   
            password = ''
            if os.path.exists(path + "/password"):  password = public.readFile(path + "/password")            
            get.certPath = path + "/fullchain.pfx"
            get.password = password            
            result = self.set_cert(get)
            if not result['status']: return result;

        else:
            pass

        sql = public.M('firewall');
        import firewalls
        get.port = '443'
        get.ps = 'HTTPS'
        firewalls.firewalls().AddAcceptPort(get)
        public.serviceReload();

        public.WriteLog('TYPE_SITE', 'SITE_SSL_OPEN_SUCCESS',(siteName,));
        return public.returnMsg(True,'SITE_SSL_OPEN_SUCCESS');

    #保存第三方证书
    def SetSSL(self,get): 
        siteName = get.siteName;
        path = self.setupPath + '/panel/vhost/cert/'+ siteName;
        if not os.path.exists(path): os.makedirs(path)

        serverType = public.get_webserver(); 
        if serverType == 'iis':                       
            get.certPath = self.setupPath + '/temp/ssl/' + get.cerName
            result = self.set_cert(get)
            if not result['status']: return result;
            if get.password:  public.writeFile(get.certPath[:-4],get.password)

        public.serviceReload();        
        if os.path.exists(path + '/partnerOrderId'): os.remove(path + '/partnerOrderId')
        public.WriteLog('TYPE_SITE','SITE_SSL_SAVE_SUCCESS');
        return public.returnMsg(True,'SITE_SSL_SUCCESS');

    #设置证书
    def set_cert(self,get):
        siteName = get.siteName;
        serverType = public.get_webserver(); 
        if serverType == 'iis':                       
            import panelSSL,uuid 
            appid = str(uuid.uuid1())
            ss = panelSSL.panelSSL();
            hashData = ss.GetCertName(get)
            if not hashData: return public.returnMsg(False,'password error');
            p = ''
            if get.password: p = ' -p ' + get.password
            public.ExecShell('certutil ' + p + ' -importPFX ' + get.certPath)

            sys_versions = public.get_sys_version()
            bind_exec = 'netsh http delete sslcert hostnameport='+ siteName +':443 && netsh http add sslcert hostnameport=' + siteName + ':443 certhash='+ hashData['hash'] +' certstorename=MY appid={' + appid + '}'
            if int(sys_versions[0]) == 6 and int(sys_versions[1]) == 1:
                bind_exec = 'netsh http delete sslcert ipport=0.0.0.0:443 && netsh http add sslcert ipport=0.0.0.0:443 certhash='+ hashData['hash'] +' appid={' + appid + '}'
            public.ExecShell(bind_exec)     

            public.ExecShell(self._appcmd + " set site " + siteName + " /-bindings.[protocol='https',bindingInformation='*:443:" + siteName + "']")
            public.ExecShell(self._appcmd + " set site " + siteName + " /+bindings.[protocol='https',bindingInformation='*:443:" + siteName + "']")

            ss.SaveCert(get);
        return public.returnMsg(True,'SITE_SSL_SUCCESS'); 


    #清理SSL配置
    def CloseSSLConf(self,get):
        siteName = get.siteName         
        partnerOrderId =  self.setupPath + '/panel/vhost/cert/'+ siteName + '/partnerOrderId';
        if os.path.exists(partnerOrderId): os.remove(partnerOrderId)
        public.ExecShell(self._appcmd + " set site " + siteName + " /-bindings.[protocol='https',bindingInformation='*:443:" + siteName + "']")
        public.WriteLog('TYPE_SITE', 'SITE_SSL_CLOSE_SUCCESS',(siteName,));
        public.serviceReload();
        return public.returnMsg(True,'SITE_SSL_CLOSE_SUCCESS');

    #设置到期时间
    def SetEdate(self,get):
        result = public.M('sites').where('id=?',(get.id,)).setField('edate',get.edate);
        siteName = public.M('sites').where('id=?',(get.id,)).getField('name');
        public.WriteLog('TYPE_SITE','SITE_EXPIRE_SUCCESS',(siteName,get.edate));
        return public.returnMsg(True,'SITE_EXPIRE_SUCCESS');

    #取网站分类
    def get_site_types(self,get):
        data = public.M("site_types").field("id,name").order("id asc").select()
        data.insert(0,{"id":0,"name":"默认分类"})
        return data

    #添加网站分类
    def add_site_type(self,get):
        get.name = get.name.strip()
        if not get.name: return public.returnMsg(False,"分类名称不能为空")
        if len(get.name) > 18: return public.returnMsg(False,"分类名称长度不能超过6个汉字或18位字母")
        type_sql = public.M('site_types')
        if type_sql.count() >= 10: return public.returnMsg(False,'最多添加10个分类!')
        if type_sql.where('name=?',(get.name,)).count()>0: return public.returnMsg(False,"指定分类名称已存在!")
        type_sql.add("name",(get.name,))
        return public.returnMsg(True,'添加成功!')

    #删除网站分类
    def remove_site_type(self,get):
        type_sql = public.M('site_types')
        if type_sql.where('id=?',(get.id,)).count()==0: return public.returnMsg(False,"指定分类不存在!")
        type_sql.where('id=?',(get.id,)).delete()
        public.M("sites").where("type_id=?",(get.id,)).save("type_id",(0,))
        return public.returnMsg(True,"分类已删除!")

    #修改网站分类名称
    def modify_site_type_name(self,get):
        get.name = get.name.strip()
        if not get.name: return public.returnMsg(False,"分类名称不能为空")
        if len(get.name) > 18: return public.returnMsg(False,"分类名称长度不能超过6个汉字或18位字母")
        type_sql = public.M('site_types')
        if type_sql.where('id=?',(get.id,)).count()==0: return public.returnMsg(False,"指定分类不存在!")
        type_sql.where('id=?',(get.id,)).setField('name',get.name)
        return public.returnMsg(True,"修改成功!")

    #设置指定站点的分类
    def set_site_type(self,get):
        site_ids = json.loads(get.site_ids)
        site_sql = public.M("sites")
        for s_id in site_ids:
            site_sql.where("id=?",(s_id,)).setField("type_id",get.id)
        return public.returnMsg(True,"设置成功!") 


    #获取防盗链状态
    def GetSecurity(self,get):
        return public.returnMsg(False,"暂不支持!") 


    #取301配置状态
    def Get301Status(self,get):
        siteName = get.siteName
        result = {}
        domains = ''
        id = public.M('sites').where("name=?",(siteName,)).getField('id')
        tmp = public.M('domain').where("pid=?",(id,)).field('name').select()
        for key in tmp:
            domains += key['name'] + ','
        try:
            if(public.get_webserver() == 'nginx'):
                conf = public.readFile(self.setupPath + '/panel/vhost/nginx/' + siteName + '.conf');
                if conf.find('301-START') == -1:
                    result['domain'] = domains[:-1]
                    result['src'] = "";
                    result['status'] = False
                    result['url'] = "http://";
                    return result;
                rep = "return\s+301\s+((http|https)\://.+);";
                arr = re.search(rep, conf).groups()[0];
                rep = "'\^((\w+\.)+\w+)'";
                tmp = re.search(rep, conf);
                src = ''
                if tmp : src = tmp.groups()[0]
            else:
                conf = public.readFile(self.setupPath + '/panel/vhost/apache/' + siteName + '.conf');
                if conf.find('301-START') == -1:
                    result['domain'] = domains[:-1]
                    result['src'] = "";
                    result['status'] = False
                    result['url'] = "http://";
                    return result;
                rep = "RewriteRule\s+.+\s+((http|https)\://.+)\s+\[";
                arr = re.search(rep, conf).groups()[0];
                rep = "\^((\w+\.)+\w+)\s+\[NC";
                tmp = re.search(rep, conf);
                src = ''
                if tmp : src = tmp.groups()[0]
        except:
            src = ''
            arr = 'http://'
            
        result['domain'] = domains[:-1]
        result['src'] = src.replace("'", '');
        result['status'] = True
        if(len(arr) < 3): result['status'] = False
        result['url'] = arr;
        
        return result
   

    #获取https配置json
    def get_site_https(self,sitePath):       
        rewConf = public.readFile(sitePath + '/web_config/rewrite.config')
        old_data = xmltodict.parse(rewConf)           
        data = {}    
        rules = []
        if old_data['rules']:
            if 'rule' in old_data['rules']:  
                list = old_data['rules']['rule']
                if type(list) == type([1,]):                        
                    for rule in old_data['rules']['rule']:
                        if rule['@name'].find('_toHttps') < 0:
                            rules.append(rule)
                else:
                    rules.append(list)
       
        old_data['rules']['rule'] = rules   
        return old_data

    #HttpToHttps
    def HttpToHttps(self,get):
        siteName = get.siteName;
        if self.serverType == 'iis':  
            sitePath = self.get_site_path(siteName)
            data = self.get_site_https(sitePath)
            https = {"@name": "http_toHttps", "@stopProcessing": "true", "match": {"@url": "(.*)"}, "conditions": {"add": {"@input": "{HTTPS}", "@pattern": "off", "@ignoreCase": "true"}}, "action": {"@type": "Redirect", "@redirectType": "Found", "@url": "https://{HTTP_HOST}/{R:1}"}}
            data['rules']['rule'].insert(0,https)                   
            public.writeFile(sitePath + '/web_config/rewrite.config', self.format_xml(self.dumps_json(data)))
        else:
            #Nginx配置
            file = self.setupPath + '/panel/vhost/nginx/'+siteName+'.conf';
            conf = public.readFile(file);
            if conf:
                if conf.find('ssl_certificate') == -1: return public.returnMsg(False,'当前未开启SSL');
                to = """#error_page 404/404.html;
        #HTTP_TO_HTTPS_START
        if ($server_port !~ 443){
            rewrite ^(/.*)$ https://$host$1 permanent;
        }
        #HTTP_TO_HTTPS_END"""
                conf = conf.replace('#error_page 404/404.html;',to);
                public.writeFile(file,conf);
        
            file = self.setupPath + '/panel/vhost/apache/'+siteName+'.conf';
            conf = public.readFile(file);
            if conf:
                httpTohttos = '''combined
        #HTTP_TO_HTTPS_START
        <IfModule mod_rewrite.c>
            RewriteEngine on
            RewriteCond %{SERVER_PORT} !^443$
            RewriteRule (.*) https://%{SERVER_NAME}$1 [L,R=301]
        </IfModule>
        #HTTP_TO_HTTPS_END'''
                conf = re.sub('combined',httpTohttos,conf,1);
                public.writeFile(file,conf);
        public.serviceReload();
        return public.returnMsg(True,'SET_SUCCESS');
    
    #CloseToHttps
    def CloseToHttps(self,get):
        siteName = get.siteName;
        if self.serverType == 'iis':   
            sitePath = self.get_site_path(siteName)
            data = self.get_site_https(sitePath)             
            public.writeFile(sitePath + '/web_config/rewrite.config', self.format_xml(self.dumps_json(data)))
        else:
            file = self.setupPath + '/panel/vhost/nginx/'+siteName+'.conf';
            conf = public.readFile(file);
            if conf:
                rep = "\n\s*#HTTP_TO_HTTPS_START(.|\n){1,300}#HTTP_TO_HTTPS_END";
                conf = re.sub(rep,'',conf);
                rep = "\s+if.+server_port.+\n.+\n\s+\s*}";
                conf = re.sub(rep,'',conf);
                public.writeFile(file,conf);
        
            file = self.setupPath + '/panel/vhost/apache/'+siteName+'.conf';
            conf = public.readFile(file);
            if conf:
                rep = "\n\s*#HTTP_TO_HTTPS_START(.|\n){1,300}#HTTP_TO_HTTPS_END";
                conf = re.sub(rep,'',conf);
                public.writeFile(file,conf);
        public.serviceReload();
        return public.returnMsg(True,'SET_SUCCESS');

    #是否跳转到https
    def IsToHttps(self,siteName):
        if self.serverType == 'iis':     
            sitePath = self.get_site_path(siteName)
            rewConf = public.readFile(sitePath + '/web_config/rewrite.config')
            old_data = xmltodict.parse(rewConf)

            if old_data['rules']:
                if 'rule' in old_data['rules']:  
                    list = old_data['rules']['rule']
                    if type(list) == type([1,]):                        
                        for rule in old_data['rules']['rule']:
                            if rule['@name'].find('_toHttps') >= 0: return True
        else:
            file = self.setupPath + '/panel/vhost/nginx/'+siteName+'.conf';
            conf = public.readFile(file);
            if conf:
                if conf.find('HTTP_TO_HTTPS_START') != -1: return True;
                if conf.find('$server_port !~ 443') != -1: return True;
        return False;


      #打包
    def ToBackup(self,get):
        id = get.id;
        find = public.M('sites').where("id=?",(id,)).field('name,path,id').find();
        import time,files
        fileName = find['name']+'_'+time.strftime('%Y%m%d_%H%M%S',time.localtime())+'.zip';
        backupPath = session['config']['backup_path'] + '/site'
        zipName = backupPath + '/'+fileName;
        if not (os.path.exists(backupPath)): os.makedirs(backupPath)


        print(find['path'])
        zipget  = dict_obj();
        zipget.path = find['path']
        zipget.sfile = ''
        zipget.dfile = zipName
        rRet = files.files().Zip(zipget)
        if not rRet['status']:  return rRet

        sql = public.M('backup').add('type,name,pid,filename,size,addtime',(0,fileName,find['id'],zipName,0,public.getDate()));
        public.WriteLog('TYPE_SITE', 'SITE_BACKUP_SUCCESS',(find['name'],));
        return public.returnMsg(True, 'BACKUP_SUCCESS');
    
    
    #删除备份文件
    def DelBackup(self,get):
        id = get.id
        where = "id=?";
        filename = public.M('backup').where(where,(id,)).getField('filename');
        if os.path.exists(filename): os.remove(filename)
        name = '';
        if filename == 'qiniu':
            name = public.M('backup').where(where,(id,)).getField('name');
            public.ExecShell("python "+self.setupPath + '/panel/script/backup_qiniu.py delete_file ' + name)
        
        public.WriteLog('TYPE_SITE', 'SITE_BACKUP_DEL_SUCCESS',(name,filename));
        public.M('backup').where(where,(id,)).delete();
        return public.returnMsg(True, 'DEL_SUCCESS');

    #取默认站点
    def GetDefaultSite(self,get):
        data = {}
        data['sites'] = public.M('sites').field('name').order('id desc').select();
        data['defaultSite'] = ''
        if self.serverType == 'iis':
            siteName = 'Default Web Site'
            info = self.get_site_info(siteName)
            if not info:
                self.CreatePool('DefaultAppPool')             
                public.ExecShell(self._appcmd + ' add site /name:"' + siteName + '" /bindings:"http/*:80:" /physicalPath:"%SystemDrive%\\inetpub\\wwwroot"' )  
                public.ExecShell(self._appcmd + ' set app "' + siteName + '/" /applicationPool:"DefaultAppPool"') 

                data['defaultSite'] = siteName
            else:
                data['defaultSite'] = public.readFile('data/defaultSite.pl');

        return data;


     #设置默认站点
    def SetDefaultSite(self,get):
        import time;
        #清理旧的
        defaultSite = public.readFile('data/defaultSite.pl');
        if defaultSite:
            if self.serverType == 'iis':
                find = public.M('sites').where('name=?',(get.name,)).field('name,path').find();
                default_path = '%SystemDrive%\\inetpub\\wwwroot'
                if find: default_path = find['path']
                public.ExecShell(self._appcmd + ' set app "Default Web Site/" -[path=\'/\'].physicalPath:' + default_path.replace('/','\\'))
            else:
                path = self.setupPath + '/panel/vhost/nginx/' + defaultSite + '.conf';
                if os.path.exists(path):
                    conf = public.readFile(path);
                    rep = "listen\s+80.+;"
                    conf = re.sub(rep,'listen 80;',conf,1);
                    rep = "listen\s+443.+;"
                    conf = re.sub(rep,'listen 443 ssl;',conf,1);
                    public.writeFile(path,conf);

            #处理新的
            path = self.setupPath + '/apache/htdocs';
            if os.path.exists(path):
                conf = '''<IfModule mod_rewrite.c>
      RewriteEngine on
      RewriteRule (.*) http://%s/$1 [L]
    </IfModule>''' % (get.name,)
                if get.name == 'off': conf = '';
                public.writeFile(path + '/.htaccess',conf);
            
        
            path = self.setupPath + '/panel/vhost/nginx/' + get.name + '.conf';
            if os.path.exists(path):
                conf = public.readFile(path);
                rep = "listen\s+80\s*;"
                conf = re.sub(rep,'listen 80 default_server;',conf,1);
                rep = "listen\s+443\s*ssl\s*\w*\s*;"
                conf = re.sub(rep,'listen 443 ssl default_server;',conf,1);
                public.writeFile(path,conf);
        
        path = self.setupPath + '/panel/vhost/nginx/default.conf';
        if os.path.exists(path): os.remove(path)
        public.writeFile('data/defaultSite.pl',get.name);
        public.serviceReload();
        return public.returnMsg(True,'SET_SUCCESS');