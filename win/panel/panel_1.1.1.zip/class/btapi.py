#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2017 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 黄文良 <287962566@qq.com>
# +-------------------------------------------------------------------
#
#             ┏┓      ┏┓
#            ┏┛┻━━━━━━┛┻┓
#            ┃               ☃              ┃
#            ┃  ┳┛   ┗┳ ┃
#            ┃     ┻    ┃
#            ┗━┓      ┏━┛
#              ┃      ┗━━━━━┓
#              ┃  神兽保佑              ┣┓
#              ┃ 永无BUG！            ┏┛
#              ┗┓┓┏━┳┓┏━━━━━┛
#               ┃┫┫ ┃┫┫
#               ┗┻┛ ┗┻┛

#------------------------------
# API管理模块
#------------------------------

import sys,os
setup_path = os.getenv("BT_PANEL")
sys.path.append(setup_path + '/class');
reload(sys);
import public,web

class site:
    __vhost = setup_path + '/vhost';
    __site = None;
    __data = None;
        
    def __init__(self):
        import panelSite;
        if not self.__site: self.__site = panelSite.panelSite();
        if not self.__data: self.__data = web.ctx;
        
    #获取站点信息
    def get_list(self):
        return public.M('sites').field('id,name,path,status,ps,addtime,edate').select();
    
    #获取指定站点信息
    def get_find(self,siteName):
        return public.M('sites').where('name=?',(siteName,)).field('id,name,path,status,ps,addtime,edate').find();
    
    #创建网站
    def create(self,siteInfo):
        try:
            import json
            isFtp = 'false';
            if siteInfo['ftp']: isFtp = 'true';
            isData = 'false';
            if siteInfo['database']: isData = 'true';
            self.__data.webname = json.dumps({'domain':siteInfo['name'],'domainlist':siteInfo['domain'],'count':len(siteInfo['domain']) + 1});
            self.__data.ps = siteInfo['ps'];
            self.__data.path = siteInfo['path'];
            self.__data.port = siteInfo['port'];
            self.__data.ftp = isFtp;
            self.__data.sql = isData;
            self.__data.ftp_username = siteInfo['ftp_username'];
            self.__data.ftp_password = siteInfo['ftp_password'];
            self.__data.datauser = siteInfo['db_username'];
            self.__data.datapassword = siteInfo['db_password'];
            self.__data.codeing = siteInfo['db_codeing'];
            self.__data.version = siteInfo['php_version'];
            return self.__site.AddSite(self.__data);
        except Exception,ex:
            return public.returnMsg(False,'参数错误!' + str(ex));
            
    #删除网站
    def remove(self,siteName,rmdir = False, rmdb = False, rmftp = False):
        try:
            self.__data.id = self.get_site_id(siteName);
            if not self.__data.id: return public.returnMsg(False,'指定站点不存在!');
            self.__data.webname = siteName;
            self.__data.ftp = '0';
            self.__data.database = '0';
            self.__data.path = '0';
            if rmdir: self.__data.path = '1';
            if rmdb: self.__data.database = '1';
            if rmftp: self.__data.ftp = '1';
            return self.__site.DeleteSite(self.__data);
        except Exception,ex:
            return public.returnMsg(False,'参数错误!' + str(ex));
        
    #停止网站
    def stop(self,siteName):
        self.__data.id = self.get_site_id(siteName);
        if not self.__data.id: return public.returnMsg(False,'指定站点不存在!');
        self.__data.webname = siteName;
        return self.__site.SiteStop(self.__data);
        
    #启动网站
    def start(self,siteName):
        self.__data.id = self.get_site_id(siteName);
        if not self.__data.id: return public.returnMsg(False,'指定站点不存在!');
        self.__data.webname = siteName;
        return self.__site.SiteStart(self.__data);
        
    #添加域名
    def add_domain(self,siteName,domains):
        self.__data.id = self.get_site_id(siteName);
        if not self.__data.id: return public.returnMsg(False,'指定站点不存在!');
        self.__data.webname = siteName;
        if type(domains) != list: return public.returnMsg(False,'域名参数数据类型必需为list');
        self.__data.domain = ','.join(domains);
        return self.__site.AddDomain(self.__data);
        
    #删除域名
    def remove_domain(self,siteName,domain,port = '80'):
        self.__data.id = self.get_site_id(siteName);
        if not self.__data.id: return public.returnMsg(False,'指定站点不存在!');
        self.__data.webname = siteName;
        self.__data.domain = domain;
        self.__data.port = port;
        return self.__site.DelDomain(self.__data);
        
    #获取SSL状态
    def ssl_status(self,siteName):
        self.__data.siteName = siteName;
        return self.__site.GetSSL(self.__data);
    
    #申请G5证书
    def ssl_auto_g5(self,domain,path):
        self.__data.domain = domain;
        self.__data.path = path;
        import panelSSL;
        s = panelSSL.panelSSL();
        return s.GetDVSSL(self.__data);
    
    #开启SSL通过G5
    def ssl_on_g5(self,partnerOrderId,siteName):
        self.__data.partnerOrderId = partnerOrderId;
        self.__data.siteName = siteName;
        import panelSSL;
        s = panelSSL.panelSSL();
        return s.GetSSLInfo(self.__data);
    
    #开启SSL，通过自有证书
    def ssl_on_private(self,siteName,privateKey,cert):
        self.__data.type = '1';
        self.__data.siteName = siteName;
        self.__data.key = privateKey;
        self.__data.csr = cert;
        return self.__site.SetSSL(self.__data);
    
    #开启SSL，通过Let's
    def ssl_on_lets(self,siteName,domains):
        if type(domains) != list: return public.returnMsg(False,'域名参数数据类型必需为list');
        self.__data.siteName = siteName;
        self.__data.updateOf = '1';
        self.__data.domains = json.dumps(domains);
        return self.__site.CreateLet(self.__data);
        
    #关闭SSL
    def ssl_off(self,siteName):
        self.__data.siteName = siteName;
        self.__data.updateOf = '1';
        return self.__site.CloseSSLConf(self.__data);
    
    #取反向代理状态
    def proxy_status(self,siteName):
        self.name = siteName;
        return self.__site.GetProxy(self.__data);
        
    #开启反向代理
    def proxy_on(self,siteName,proxyUrl,host,replace_src,replace_dst,type = '1'):
        self.__data.name = siteName;
        self.__data.proxyUrl = proxyUrl;
        self.__data.toDomain = host;
        self.__data.sub1 = replace_src;
        self.__data.sub2 = replace_dst;
        self.__data.type = type;
        return self.__site.SetProxy(self.__data);
    
    #设置反向代理缓存状态
    def proxy_cache(self,siteName):
        self.__data.siteName = siteName;
        return self.__site.ProxyCache(self.__data);
    
    #关闭反向代理
    def proxy_off(self,siteName,proxyUrl,host,replace_src,replace_dst):
        return self.proxy_on(siteName, proxyUrl, host, replace_src, replace_dst, '0');
    
    #获取站点目录相关信息
    def path_info(self,siteName,path):
        self.__data.id = self.get_site_id(siteName);
        self.__data.path = path;
        return self.__site.GetDirUserINI(self.__data);
    
    #设置运行目录
    def run_path(self,siteName,runPath):
        self.__data.id = self.get_site_id(siteName);
        self.__data.runPath = runPath;
        return self.__site.SetSiteRunPath(self.__data);
    
    #设置根目录
    def set_path(self,siteName,path):
        self.__data.id = self.get_site_id(siteName);
        self.__data.path = path;
        return self.__site.SetPath(self.__data);
    
    #设置.user.ini,再次调用时将关闭
    def set_user_ini(self,siteName):
        self.__data.path = public.M('sites').where('name=?',(siteName,)).getField('path');
        return self.__site.SetDirUserINI(self.__data);
    
    #设置是否写访问日志,再次调用时将关闭
    def set_write_log(self,siteName):
        self.__data.id = self.get_site_id(siteName);
        return self.__site.logsOpen(self.__data);
    
    #设置访问认证
    def set_has_pass(self,siteName,authUser,authPass):
        self.__data.id = self.get_site_id(siteName);
        self.__data.username = authUser;
        self.__data.password = authPass;
        return self.__site.SetHasPwd(self.__data);
    
    #关闭访问认证
    def has_pass_off(self,siteName):
        self.__data.id = self.get_site_id(siteName);
        return self.__site.CloseHasPwd(self.__data);
    
    #获取配置文件
    def get_conf(self,siteName):
        if not self.site_exists(siteName): return public.returnMsg(False,'指定站点不存在!');
        data = {};
        webserver = self.get_webserver();
        data['file'] = self.__vhost + '/'+webserver+'/' + siteName + '.conf';
        data['body'] = public.readFile(data['file']);
        return data;
    
    #保存配置文件
    def save_conf(self,siteName,conf):
        if not self.site_exists(siteName): return public.returnMsg(False,'指定站点不存在!');
        webserver = self.get_webserver();
        filename = self.__vhost + '/'+webserver+'/' + siteName + '.conf';
        public.writeFile(filename,conf);
        return public.returnMsg(True,'配置文件已保存!');
        
    #获取伪静态
    def get_rewrite(self,siteName):
        if not self.site_exists(siteName): return public.returnMsg(False,'指定站点不存在!');
        self.__data['siteName'] = siteName;
        return self.__site.GetRewriteList(self.__data);
    
    #保存伪静态
    def save_rewrite(self,siteName,rewrite):
        if not self.site_exists(siteName): return public.returnMsg(False,'指定站点不存在!');
        webserver = self.get_webserver();
        filename = self.__vhost + '/rewrite/' + siteName + '.conf';
        if webserver != 'nginx':
            self.__data.siteName = siteName;
            runPath = self.__site.GetRunPath(self.__data);
            find = self.get_find(siteName);
            filename = find['path'] + runPath + '/.htaccess';
        public.writeFile(filename,rewrite);
        public.serviceReload();
        return public.returnMsg(True,'规则已保存!');
            
    #获取301配置
    def get_301(self,siteName):
        self.__data.siteName = siteName;
        return self.__site.Get301Status(self.__data);
    
    #设置301重定向，若想关闭301，请在type参数中传入'0'
    def set_301(self,siteName,domain,to,type='1'):
        self.__data.siteName = siteName;
        self.__data.srcDomain = domain;
        self.__data.toDomain = to;
        self.__data.type = type;
        return self.__site.Set301Status(self.__data);
        
    #取防盗链配置
    def get_security(self,siteName):
        self.__data.name = siteName;
        return self.__site.GetSecurity(self.__data);
    
    #设置防盗链,当开启时调用,将关闭防盗链
    def set_security(self,siteName,fix,domains):
        self.__data.name = siteName;
        if type(fix) != list or type(domains) != list: return public.returnMsg(False,'domains和fix参数数据类型必需为list');
        self.__data.fix = ','.join(fix);
        self.__data.domains = ','.join(domains);
        return self.__site.SetSecurity(self.__data);
    
    #获取子目录绑定信息
    def get_binding(self,siteName):
        self.__data.id = self.get_site_id(siteName);
        return self.__site.GetDirBinding(self.__data);
    
    #添加子目录绑定
    def create_binding(self,siteName,domain,dirName):
        self.__data.id = self.get_site_id(siteName);
        self.__data.domain = domain;
        self.__data.dirName = dirName;
        return self.__site.AddDirBinding(self.__data);
    
    #删除子目录 绑定
    def remove_binding(self,bindingId):
        self.__data.id = bindingId;
        return self.__site.DelDirBinding(self.__data);
    
    #获取当前站点正在使用的PHP版本
    def get_php_version(self,siteName):
        self.__data.siteName = siteName;
        return self.__site.GetSitePHPVersion(self.__data);
    
    #设置当前站点PHP版本,tomcat相关配置状态
    def set_php_version(self,siteName,phpVersion):
        self.__data.siteName = siteName;
        self.__data.version = phpVersion;
        return self.__site.SetPHPVersion(self.__data);
    
    #取可用的PHP版本列表,
    def get_php_list(self):
        return self.__site.GetPHPVersion();
    
    #获取当前站点的默认文档
    def get_default_doc(self,siteName):
        self.__data.id = self.get_site_id(siteName);
        return self.__site.GetIndex(self.__data);
        
    #设置默认文档
    def set_default_doc(self,siteName,docList):
        if type(docList) != list: return public.returnMsg(False,'docList参数数据类型必需为list');
        self.__data.id = self.get_site_id(siteName);
        self.__data.Index = ','.join(docList);
        return self.__site.SetIndex(self.__data);
    
    #取流量限制配置
    def get_net_limit(self,siteName):
        self.__data.id = self.get_site_id(siteName);
        return self.__site.GetLimitNet(self.__data);
    
    #设置流量限制
    def set_net_limit(self,siteName,perServer,preIp,limitRate):
        self.__data.id = self.get_site_id(siteName);
        self.__data.perserver = perServer;
        self.__data.preip = preIp;
        self.__limit_rate = limitRate;
        return self.__site.SetLimitNet(self.__data);
    
    #关闭流量限制
    def net_limit_off(self,siteName):
        self.__data.id = self.get_site_id(siteName);
        return self.__site.CloseLimitNet(self.__data);
    
    #设置为Java应用,再次调用将关闭此设置
    def tomcat_on(self,siteName):
        self.__data.siteName = siteName;
        return self.__site.SetTomcat(self.__data);
        
    #修改备注
    def ps(self,siteName,ps):
        public.M('sites').where('name=?',(siteName,)).setField('ps',ps);
        return public.returnMsg(True,'修改成功!');
    
    #获取网站标识
    def get_site_id(self,siteName):
        return public.M('sites').where('name=?',(siteName,)).getField('id');
    
    #获取Web服务器
    def get_webserver(self):
        webserver = 'iis';
        if get_server_status('nginx') >= 0:
            webserver = 'nginx'
        elif get_server_status('apache') >= 0:
            webserver = 'apache';
        return webserver;
    
    #网站是否存在
    def site_exists(self,siteName):
        c = public.M('sites').where('name=?',(siteName,)).count();
        if c: return True;
        return False;
    
class database:
    __obj = None;
    __data = None;
    
    def __init__(self):
        import database;
        if not self.__obj: self.__obj = database.database();
        if not self.__data: self.__data = web.ctx;
    
    #获取列表
    def get_list(self):
        return public.M('databases').field('id,pid,name,password,ps,addtime').select();
    
    #获取指定数据库信息
    def get_find(self,dbName):
        return public.M('databases').where('name=?',(dbName,)).field('id,pid,name,password,ps,addtime').find();
    
    #创建数据库
    def create(self,dbName,dbPassword,dbCodeing,dbAddress,ps):
        self.__data.name = dbName;
        self.__data.password = dbPassword;
        self.__data.codeing = dbCodeing;
        self.__data.address = dbAddress;
        self.__data.ps = ps;
        return self.__obj.AddDatabase(self.__data);
    
    #删除数据库
    def remove(self,dbName):
        self.__data.name = dbName;
        self.__data.id = self.get_db_id(dbName);
        return self.__obj.DeleteDatabase(self.__data);
    
    #修改密码
    def password(self,dbName,dbPassword):
        self.__data.username = dbName;
        self.__data.password = dbPassword;
        self.__data.id = self.get_db_id(dbName);
        return self.__obj.ResDatabasePassword(self.__data);
    
    #修改权限
    def access(self,dbName,dbAccess):
        self.__data.name = dbName;
        self.__data.access = dbAccess;
        return self.__obj.SetDatabaseAccess(self.__data);
    
    #修改root密码
    def root_password(self,password):
        self.__data.password = password;
        return self.__obj.SetupPassword(self.__data);
    
    #修改备注
    def ps(self,dbName,ps):
        public.M('databases').where('name=?',(dbName,)).setField('ps',ps);
        return public.returnMsg(True,'SET_SUCCESS');
    
    #名取ID
    def get_db_id(self,dbName):
        return public.M('databases').where('name=?',(dbName,)).getField('id');
    

class ftp:
    __obj = None;
    __data = None;
    
    def __init__(self):
        import ftp;
        if not self.__obj: self.__obj = ftp.ftp();
        if not self.__data: self.__data = web.ctx;
        
    #获取列表
    def get_list(self):
        return public.M('ftps').field('id,pid,name,password,status,ps,addtime,path').select();
    
    #获取指定数据库信息
    def get_find(self,ftpName):
        return public.M('ftps').where('name=?',(ftpName,)).field('id,pid,name,password,status,ps,addtime,path').find();
    
    #创建FTP
    def create(self,ftpUser,ftpPass,ftpPath,ps):
        self.__data.ftp_username = ftpUser;
        self.__data.ftp_password = ftpPass;
        self.__data.path = ftpPath;
        self.__data.ps = ps;
        return self.__obj.AddUser(self.__data);
    
    #删除FTP
    def remove(self,ftpName):
        self.__data.username = ftpName;
        self.__data.id = self.get_ftp_id(ftpName);
        return self.__obj.DeleteUser(self.__data);
    
    #修改密码
    def password(self,ftpName,password):
        self.__data.id = self.get_ftp_id(ftpName);
        self.__data.ftp_username = ftpName;
        self.__data.new_password = password;
        return self.__obj.SetUserPassword(self.__data);
    
    #设置FTP状态, status  0.停用   1.启用
    def status(self,ftpName,status):
        self.__data.id = self.get_ftp_id(ftpName);
        self.__data.username = ftpName;
        self.__data.status = status;
        return self.__obj.SetStatus(self.__data);
    
    #修改备注
    def ps(self,ftpName,ps):
        public.M('ftps').where('name=?',(ftpName,)).setField('ps',ps);
        return public.returnMsg(True,'SET_SUCCESS');
    
    #名取ID
    def get_ftp_id(self,ftpName):
        return public.M('ftps').where('name=?',(ftpName,)).getField('id');
    

class config:
    __obj = None;
    __data = None;
    
    def __init__(self):
        import config;
        if not self.__obj: self.__obj = config.config();
        if not self.__data: self.__data = web.ctx;
    
    
    #修改面板密码
    def panel_password(self,password1,password2):
        self.__data.password1 = password1;
        self.__data.password2 = password2;
        return self.__obj.setPassword(self.__data);
    
    #修改面板用户 
    def panel_username(self,username1,username2):
        self.__data.username1 = username1;
        self.__data.username2 = username2;
        return self.__obj.setUsername(self.__data);
    
    #修改面板设置
    def panel_config(self,title,port,domain,limitip,sitePath,backupPath,address):
        self.__data.webname = title;
        self.__data.port = port;
        self.__data.domain = domain;
        self.__data.limitip = limitip;
        self.__data.site_path = sitePath;
        self.__data.backup_path = backupPath;
        self.__data.address = address;
        return self.__obj.setPanel(self.__data);
    
    #同步网络时间
    def sync_date(self):
        return self.__obj.syncDate(self.__data);
    
    #关闭面板
    def close_panel(self):
        return self.__obj.ClosePanel(self.__data);
    
    #设置自动更新
    def auto_update(self):
        return self.__obj.AutoUpdatePanel(self.__data);
    
    #设置模板
    def panel_template(self,templateName):
        self.__data.templates = templateName;
        return self.__obj.SetTemplates(self.__data);
    
    #设置面板SSL
    def panel_ssl(self):
        return self.__obj.SetPanelSSL(self.__data);
    
    #获取关联面板列表
    def panel_list(self):
        return self.__obj.GetPanelList(self.__data);
    

class php:
    __obj = None;
    __data = None;
    
    def __init__(self):
        import config;
        if not self.__obj: self.__obj = config.config();
        if not self.__data: self.__data = web.ctx;
    
    #获取PHP配置参数
    def get_php_config(self,version):
        self.__data.version = version;
        return self.__obj.GetPHPConf(self.__data);
    
    #设置PHP配置
    def set_php_config(self,version,configInfo):
        gets = ['display_errors','cgi.fix_pathinfo','date.timezone','short_open_tag','asp_tags','safe_mode','max_execution_time','max_input_time','memory_limit','post_max_size','file_uploads','upload_max_filesize','max_file_uploads','default_socket_timeout','error_reporting']
        self.__data.version = version;
        for g in gets:
            self.__data[g] = gets[g];
        return self.__obj.SetPHPConf(self.__data);
    
    #取FPM配置
    def get_fpm_config(self,version):
        self.__data.version = version;
        return self.__obj.getFpmConfig(self.__data);
    
    #提交FPM配置
    def set_fpm_config(self,version,max_children,start_servers,min_spare_servers,max_spare_servers,pm):
        self.__data.version = version;
        self.__data.max_children = max_children;
        self.__data.start_servers = start_servers;
        self.__data.min_spare_servers = min_spare_servers;
        self.__data.max_spare_servers = max_spare_servers;
        self.__data.pm = pm;
        return self.__obj.setFpmConfig(self.__data);
    
    #设置脚本超时时间
    def set_script_timeout(self,version,timeout):
        self.__data.version = version;
        self.__data.time = timeout;
        return self.__obj.setPHPMaxTime(self.__data);
    
    #添加禁用函数
    def set_disable_function(self,version,disable_functions):
        self.__data.version = version;
        self.__data.disable_functions = disable_functions;
        return self.__data.setPHPDisable(self.__data);
    
    #设置文件上传大小限制
    def set_max_upload(self,version,size):
        self.__data.version = version;
        self.__data.max = size;
        return self.__obj.setPHPMaxSize(self.__data);
    
    #设置PATH_INFO
    def set_path_info(self,version,status):
        self.__data.version = version;
        self.__data.type = 'off';
        if status: self.__data.type = 'on';
        return self.__obj.setPathInfo(self.__data);
    
    