import public ,time ,json ,os #line:14
from BTPanel import session #line:15
class panelAuth :#line:17
    __OOO000O0OO0OOO000 ='data/product_list.pl'#line:18
    __OO0O0OOO00000000O ='data/product_bay.pl';#line:19
    __O00OOOO0OOO0OOO00 ='100000011';#line:20
    def create_serverid (OO0O000OO0OO000OO ,OO0O0OOOOO0OOOO0O ):#line:22
        O00O00O0O0OO0O0O0 ='data/userInfo.json';#line:23
        if not os .path .exists (O00O00O0O0OO0O0O0 ):return public .returnMsg (False ,'请先登陆宝塔官网用户');#line:24
        OOO0000O0O000O0OO =public .readFile (O00O00O0O0OO0O0O0 );#line:25
        OO0O0OO0OO0OO00OO =json .loads (OOO0000O0O000O0OO );#line:26
        if not OO0O0OO0OO0OO00OO :return public .returnMsg (False ,'请先登陆宝塔官网用户');#line:27
        if not hasattr (OO0O0OO0OO0OO00OO ,'serverid'):#line:28
            O0O0OOOOO0O000000 =OO0O000OO0OO000OO .get_mac_address ()+OO0O000OO0OO000OO .get_hostname ()#line:29
            O00OO00O00O00000O =OO0O000OO0OO000OO .get_cpuname ();#line:30
            OOOO0000O00OO0O0O =public .md5 (O0O0OOOOO0O000000 )+public .md5 (O00OO00O00O00000O );#line:31
            OO0O0OO0OO0OO00OO ['serverid']=OOOO0000O00OO0O0O ;#line:32
            public .writeFile (O00O00O0O0OO0O0O0 ,json .dumps (OO0O0OO0OO0OO00OO ));#line:33
        return OO0O0OO0OO0OO00OO ;#line:34
    def check_serverid (OOO00OO00O0O0OOO0 ,O0OOO00OO0O000000 ):#line:36
        if O0OOO00OO0O000000 .serverid !=OOO00OO00O0O0OOO0 .create_serverid (O0OOO00OO0O000000 ):return False ;#line:37
        return True ;#line:38
    def get_plugin_price (O0OO0000O0O0OOOO0 ,O000OOO00OOO0O0OO ):#line:40
        O000OOO0OOO0O00O0 ='data/userInfo.json';#line:41
        if not 'pluginName'in O000OOO00OOO0O0OO :return public .returnMsg (False ,'参数错误!');#line:42
        if not os .path .exists (O000OOO0OOO0O00O0 ):return public .returnMsg (False ,'请先登陆宝塔官网帐号!');#line:43
        O00O0OO0O00OO0O0O ={}#line:44
        O00O0OO0O00OO0O0O ['pid']=O0OO0000O0O0OOOO0 .get_plugin_info (O000OOO00OOO0O0OO .pluginName )['id'];#line:45
        OOO0O000OOOO00000 =O0OO0000O0O0OOOO0 .send_cloud ('get_product_discount',O00O0OO0O00OO0O0O )#line:47
        return OOO0O000OOOO00000 ;#line:48
    def get_plugin_info (O00000OO00O000O00 ,O000000O00O000000 ):#line:50
        O0OOOO000O000OO00 =O00000OO00O000O00 .get_business_plugin (None );#line:51
        if not O0OOOO000O000OO00 :return None #line:52
        for O0O00OOO0OO000OO0 in O0OOOO000O000OO00 :#line:53
            if O0O00OOO0OO000OO0 ['name']==O000000O00O000000 :return O0O00OOO0OO000OO0 ;#line:54
        return None ;#line:55
    def get_plugin_list (O000OOO0OO0OOOOOO ,OO00O0OOOO0OO0000 ):#line:57
        try :#line:58
            if not session .get ('get_product_bay')or not os .path .exists (O000OOO0OO0OOOOOO .__OO0O0OOO00000000O ):#line:59
                O00000OO0O0OO00OO =O000OOO0OO0OOOOOO .send_cloud ('get_order_list_byuser',{});#line:60
                if O00000OO0O0OO00OO :public .writeFile (O000OOO0OO0OOOOOO .__OO0O0OOO00000000O ,json .dumps (O00000OO0O0OO00OO ));#line:61
                session ['get_product_bay']=True ;#line:62
            O00000OO0O0OO00OO =json .loads (public .readFile (O000OOO0OO0OOOOOO .__OO0O0OOO00000000O ))#line:63
            return O00000OO0O0OO00OO #line:64
        except :return None #line:65
    def get_buy_code (O0OOOOOOOOO00OO0O ,OO0O00000OO0000OO ):#line:67
        OOO0OO00OO0O00OO0 ={}#line:68
        OOO0OO00OO0O00OO0 ['pid']=OO0O00000OO0000OO .pid ;#line:69
        OOO0OO00OO0O00OO0 ['cycle']=OO0O00000OO0000OO .cycle ;#line:70
        OO0O00OO00OOO00OO =O0OOOOOOOOO00OO0O .send_cloud ('create_order',OOO0OO00OO0O00OO0 );#line:71
        if not OO0O00OO00OOO00OO :return public .returnMsg (False ,'连接服务器失败!')#line:72
        return OO0O00OO00OOO00OO ;#line:73
    def check_pay_status (O0O00OO0000000OOO ,OOOO000OOOO000OOO ):#line:75
        OOO000O0000OOOOO0 ={}#line:76
        OOO000O0000OOOOO0 ['id']=OOOO000OOOO000OOO .id ;#line:77
        O0OOO00OOOO00OOO0 =O0O00OO0000000OOO .send_cloud ('check_product_pays',OOO000O0000OOOOO0 );#line:78
        if not O0OOO00OOOO00OOO0 :return public .returnMsg (False ,'连接服务器失败!')#line:79
        if O0OOO00OOOO00OOO0 ['status']==True :#line:80
            O0O00OO0000000OOO .flush_pay_status (OOOO000OOOO000OOO );#line:81
            if 'get_product_bay'in session :del (session ['get_product_bay']);#line:82
        return O0OOO00OOOO00OOO0 ;#line:83
    def flush_pay_status (OOO00O0OOOOO000O0 ,OOO000OOOO0OO0OOO ):#line:85
        if 'get_product_bay'in session :del (session ['get_product_bay'])#line:86
        O0OOOOOO0OOOO0O0O =OOO00O0OOOOO000O0 .get_plugin_list (OOO000OOOO0OO0OOO )#line:87
        if not O0OOOOOO0OOOO0O0O :return public .returnMsg (False ,'连接服务器失败!')#line:88
        return public .returnMsg (True ,'状态刷新成功!')#line:89
    def get_renew_code (OOO0000000O0O0OO0 ):#line:91
        pass #line:92
    def check_renew_code (O000O000000O0O0OO ):#line:94
        pass #line:95
    def get_business_plugin (O000O000O00O0O0OO ,O00OO0OOO00OO0OO0 ):#line:97
        try :#line:98
            if not session .get ('get_product_list')or not os .path .exists (O000O000O00O0O0OO .__OOO000O0OO0OOO000 ):#line:99
                OOO0OO0O00O0O0O0O =O000O000O00O0O0OO .send_cloud ('get_product_list',{});#line:100
                if OOO0OO0O00O0O0O0O :public .writeFile (O000O000O00O0O0OO .__OOO000O0OO0OOO000 ,json .dumps (OOO0OO0O00O0O0O0O ));#line:101
                session ['get_product_list']=True #line:102
            OOO0OO0O00O0O0O0O =json .loads (public .readFile (O000O000O00O0O0OO .__OOO000O0OO0OOO000 ))#line:103
            return OOO0OO0O00O0O0O0O #line:104
        except :return None #line:105
    def get_ad_list (O00O0000OOO0OO00O ):#line:107
        pass #line:108
    def check_plugin_end (OO0OOO00OO0000O0O ):#line:110
        pass #line:111
    def get_re_order_status_plugin (O00O000OOO00OOOO0 ,OOO0OO00O0OO00O0O ):#line:113
        O0OOO00O000OOOOOO ={}#line:114
        O0OOO00O000OOOOOO ['pid']=getattr (OOO0OO00O0OO00O0O ,'pid',0 );#line:115
        O00O00OO00OOO0000 =O00O000OOO00OOOO0 .send_cloud ('get_re_order_status',O0OOO00O000OOOOOO );#line:116
        if not O00O00OO00OOO0000 :return public .returnMsg (False ,'连接服务器失败!');#line:117
        if O00O00OO00OOO0000 ['status']==True :#line:118
            O00O000OOO00OOOO0 .flush_pay_status (OOO0OO00O0OO00O0O );#line:119
            if 'get_product_bay'in session :del (session ['get_product_bay']);#line:120
        return O00O00OO00OOO0000 ;#line:121
    def get_voucher_plugin (O00O00OO00O0O0O0O ,O00O0000OOO0O0000 ):#line:123
        O00O00O000O0OO0OO ={}#line:124
        O00O00O000O0OO0OO ['pid']=getattr (O00O0000OOO0O0000 ,'pid',0 );#line:125
        O00O00O000O0OO0OO ['status']='0';#line:126
        OOOO0OO00OO00OO00 =O00O00OO00O0O0O0O .send_cloud ('get_voucher',O00O00O000O0OO0OO );#line:127
        if not OOOO0OO00OO00OO00 :return [];#line:128
        return OOOO0OO00OO00OO00 ;#line:129
    def create_order_voucher_plugin (O00O0O00OOOO00O00 ,OO0000OOOO0000OOO ):#line:131
        OO00000O0O0000000 ={}#line:132
        OO00000O0O0000000 ['pid']=getattr (OO0000OOOO0000OOO ,'pid',0 );#line:133
        OO00000O0O0000000 ['code']=getattr (OO0000OOOO0000OOO ,'code',0 );#line:134
        O0O00OO0OO00O00OO =O00O0O00OOOO00O00 .send_cloud ('create_order_voucher',OO00000O0O0000000 );#line:135
        if not O0O00OO0OO00O00OO :return public .returnMsg (False ,'连接服务器失败!');#line:136
        if O0O00OO0OO00O00OO ['status']==True :#line:137
            O00O0O00OOOO00O00 .flush_pay_status (OO0000OOOO0000OOO );#line:138
            if 'get_product_bay'in session :del (session ['get_product_bay']);#line:139
        return O0O00OO0OO00O00OO ;#line:140
    def send_cloud (O0OO0OO0O000OO0OO ,O0OOOOO00O00OOOO0 ,OOOO00O000OOO0OOO ):#line:143
        try :#line:144
            O00O00OOOO0O00000 ='http://www.bt.cn/api/Plugin/';#line:145
            O0OOOOOOOO0O00OO0 =O0OO0OO0O000OO0OO .create_serverid (None );#line:146
            if 'status'in O0OOOOOOOO0O00OO0 :#line:147
                OOOO00O000OOO0OOO ['uid']=0 ;#line:148
                OOOO00O000OOO0OOO ['serverid']='';#line:149
            else :#line:150
                OOOO00O000OOO0OOO ['uid']=O0OOOOOOOO0O00OO0 ['uid'];#line:151
                OOOO00O000OOO0OOO ['serverid']=O0OOOOOOOO0O00OO0 ['serverid'];#line:152
            O0000OOOOO0O0000O =public .httpPost (O00O00OOOO0O00000 +O0OOOOO00O00OOOO0 ,OOOO00O000OOO0OOO );#line:153
            O0000OOOOO0O0000O =json .loads (O0000OOOOO0O0000O .strip ());#line:154
            if not O0000OOOOO0O0000O :return None ;#line:155
            return O0000OOOOO0O0000O ;#line:156
        except :return None #line:157
    def send_cloud_pro (OO000O0OOO0OO0OOO ,OOOO00O000OO0OO0O ,O000O0OO0O00OO0O0 ):#line:159
        try :#line:160
            O00O00OOOO00OOOOO ='http://www.bt.cn/api/invite/';#line:161
            O0OO00OO000O0O0O0 =OO000O0OOO0OO0OOO .create_serverid (None );#line:162
            if 'status'in O0OO00OO000O0O0O0 :#line:163
                O000O0OO0O00OO0O0 ['uid']=0 ;#line:164
                O000O0OO0O00OO0O0 ['serverid']='';#line:165
            else :#line:166
                O000O0OO0O00OO0O0 ['uid']=O0OO00OO000O0O0O0 ['uid'];#line:167
                O000O0OO0O00OO0O0 ['serverid']=O0OO00OO000O0O0O0 ['serverid'];#line:168
            O0O0O00O000000OO0 =public .httpPost (O00O00OOOO00OOOOO +OOOO00O000OO0OO0O ,O000O0OO0O00OO0O0 );#line:169
            O0O0O00O000000OO0 =json .loads (O0O0O00O000000OO0 );#line:171
            if not O0O0O00O000000OO0 :return None ;#line:172
            return O0O0O00O000000OO0 ;#line:173
        except :return None #line:174
    def get_voucher (OO000O000OO0OOO00 ,O000O0000OO00O000 ):#line:176
        O00OOOO0OO0OOOOO0 ={}#line:177
        O00OOOO0OO0OOOOO0 ['product_id']=OO000O000OO0OOO00 .__O00OOOO0OOO0OOO00 ;#line:178
        O00OOOO0OO0OOOOO0 ['status']='0';#line:179
        O0OO0OOO0OO000OOO =OO000O000OO0OOO00 .send_cloud_pro ('get_voucher',O00OOOO0OO0OOOOO0 );#line:180
        return O0OO0OOO0OO000OOO ;#line:181
    def get_order_status (O00OOO0OO0OO00OOO ,OOO0O0O00OOO0OOO0 ):#line:183
        OO00OOOO0000O0000 ={}#line:184
        OOO000O00OO0OO000 =O00OOO0OO0OO00OOO .send_cloud_pro ('get_order_status',OO00OOOO0000O0000 );#line:185
        return OOO000O00OO0OO000 ;#line:186
    def get_product_discount_by (O000O00OOO000O00O ,OOO0000OO00000000 ):#line:189
        OOOOO0OO0000O0OOO ={}#line:190
        O000OO0OOOOO0OOO0 =O000O00OOO000O00O .send_cloud_pro ('get_product_discount_by',OOOOO0OO0000O0OOO );#line:191
        return O000OO0OOOOO0OOO0 ;#line:192
    def get_re_order_status (OOOOO00OO0OO00O0O ,O0O00O0O00O0000O0 ):#line:194
        OOOO00OO0000OOO00 ={}#line:195
        O0OOOOOOO00OO0O00 =OOOOO00OO0OO00O0O .send_cloud_pro ('get_re_order_status',OOOO00OO0000OOO00 );#line:196
        return O0OOOOOOO00OO0O00 ;#line:197
    def create_order_voucher (O0O00000O00O000OO ,O00OOOOO00OO0O000 ):#line:199
        OOOO00O00OOOO0OO0 =getattr (O00OOOOO00OO0O000 ,'code','1')#line:200
        OOO000OO0O0OOO0OO ={}#line:201
        OOO000OO0O0OOO0OO ['code']=OOOO00O00OOOO0OO0 ;#line:202
        O000OO0OO0OO0OOOO =O0O00000O00O000OO .send_cloud_pro ('create_order_voucher',OOO000OO0O0OOO0OO );#line:203
        return O000OO0OO0OO0OOOO ;#line:204
    def create_order (OO0OO0OO0000OO0OO ,O0OO0000O0O0O0000 ):#line:206
        OO0OO0OOO0O000OOO =getattr (O0OO0000O0O0O0000 ,'cycle','1');#line:207
        O0OOOO0OO0O0000OO ={}#line:208
        O0OOOO0OO0O0000OO ['cycle']=OO0OO0OOO0O000OOO ;#line:209
        O0OO000OOO0O0O00O =OO0OO0OO0000OO0OO .send_cloud_pro ('create_order',O0OOOO0OO0O0000OO );#line:210
        return O0OO000OOO0O0O00O ;#line:211
    def get_mac_address (O00OO000OO00000O0 ):#line:213
        import uuid #line:214
        OOOO000OOOOO00OOO =uuid .UUID (int =uuid .getnode ()).hex [-12 :]#line:215
        return ":".join ([OOOO000OOOOO00OOO [O000OO0000O00OOOO :O000OO0000O00OOOO +2 ]for O000OO0000O00OOOO in range (0 ,11 ,2 )])#line:216
    def get_hostname (O0OO0OOOOO000OO00 ):#line:218
        import socket #line:219
        return socket .getfqdn (socket .gethostname ())#line:220
    def get_cpuname (OO000000O0OO00O0O ):#line:222
        return public .ExecShell ("cat /proc/cpuinfo|grep 'model name'|cut -d : -f2")[0 ].strip ();#line:223
