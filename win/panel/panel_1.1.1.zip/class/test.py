#coding: utf-8
#  + -------------------------------------------------------------------
# | 宝塔Linux面板
#  + -------------------------------------------------------------------
# | Copyright (c) 2015-2016 宝塔软件(http:#bt.cn) All rights reserved.
#  + -------------------------------------------------------------------
# | Author: 黄文良 <287962566@qq.com>
#  + -------------------------------------------------------------------
import public,db,re,os,firewalls,sys
import gzip
import os
import tarfile , zipfile,rarfile,threading

from BTPanel import session,cache
class win:
    __runPath = None
    __version = [];
    def __init__(self):
        self.__version = public.get_sys_version()        
        if not cache.get('firewall_init'):
            self.firewall_init();       
    
    def get_test(self,get):    
        val = self.ReadReg("SOFTWARE\\Wow6432Node\\BaotaSetups","SetupPath")+'/Recycle_bin/';
        #status,type = winreg.QueryValueEx(newKey,'fDenyTSConnections')
        return val
    
    def AddDropAddress(self,get):
        import time
        import re
        rep = "^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(\/\d{1,2})?$"
        if not re.search(rep,get.port): return public.returnMsg(False,'FIREWALL_IP_FORMAT');
        address = get.port
        if public.M('firewall').where("port=?",(address,)).count() > 0: return public.returnMsg(False,'FIREWALL_IP_EXISTS')
        v = public.get_sys_version()
        if v[0] == 6:
            vs = 1
        else:
            vs = 2
        return ''
    
    #添加放行端口
    def AddAcceptPort(self,get):
        import re
        rep = "^\d{1,5}(:\d{1,5})?$"
        if not re.search(rep,get.port): return public.returnMsg(False,'PORT_CHECK_RANGE');
        import time
        port = get.port
        ps = get.ps
        if public.M('firewall').where("port=?",(port,)).count() > 0: return public.returnMsg(False,'FIREWALL_PORT_EXISTS')
        notudps = ['80','443','8888','888','39000:40000','21','22']
        v = public.get_sys_version()
        shell = 'netsh firewall set portopening tcp '+ port+' '+ps
        if v[0] == 6:
            shell = 'netsh advfirewall firewall add rule name='+ps+' dir=in action=allow protocol=tcp localport='+port
        result = public.ExecShell(shell);
        public.WriteLog("TYPE_FIREWALL", 'FIREWALL_ACCEPT_PORT',(port,))
        addtime = time.strftime('%Y-%m-%d %X',time.localtime())
        public.M('firewall').add('port,ps,addtime',(port,ps,addtime))
        
        return public.returnMsg(True,'ADD_SUCCESS')
 
    #删除放行端口
    def DelAcceptPort(self,get):
        port = get.port
        id = get.id
        try:
            if(port == public.GetHost(True)): return public.returnMsg(False,'FIREWALL_PORT_PANEL')         
            public.WriteLog("TYPE_FIREWALL", 'FIREWALL_DROP_PORT',(port,))
            public.M('firewall').where("id=?",(id,)).delete()           
            shell = "netsh firewall delete portopening protocol=tcp port=" + port
            if self.__version == 6:
                shell = "netsh advfirewall firewall delete rule name=all protocol=tcp localport=" + port          
            return public.returnMsg(True,'DEL_SUCCESS')
        except:
            return public.returnMsg(False,'DEL_ERROR')

    #禁用PING
    def NoPing(self,get):
         result = public.ExecShell('Netsh ipsec static show filterlist name=PortList')
         if result[0].find('ERR')!=-1:
            public.ExecShell("Netsh ipsec static add filteraction name = 阻止 action =block")
            public.ExecShell('Netsh ipsec static add filter filterlist=PortList srcaddr=122.226.158.132 srcport=0 dstaddr=me dstport=0 protocol=ANY mirrored=no description="初始化"')
         public.ExecShell("netsh ipsec static add rule name =禁止PING Policy = 宝塔IP安全策略 filterlist =PortList filteraction = 阻止")
         public.ExecShell("netsh ipsec static add filter filterlist=PortList srcaddr=any dstaddr=me protocol=icmp  description=禁止PING mirrored=yes")
         return public.returnMsg(True,'禁PING成功！')

    #解除禁PING
    def OffPing(self,get):
        if self.__version == 6:
            public.ExecShell('netsh advfirewall firewall delete rule name="禁PING"')
        public.ExecShell("netsh firewall set service fileandprint enable")
        public.ExecShell('netsh ipsec static delete rule name =禁止PING Policy = "宝塔IP安全策略"')
        public.ExecShell('netsh ipsec static delete filterlist name =PortList');
        return public.returnMsg(True,'解除禁PING成功！')
    
    #添加禁止IP
    def AddDropAddress(self,get):
        import time
        import re
        rep = "^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(\/\d{1,2})?$"
        if not re.search(rep,get.port): return public.returnMsg(False,'FIREWALL_IP_FORMAT');
        address = get.port
        ps = get.ps
        if public.M('firewall').where("port=?",(address,)).count() > 0: return public.returnMsg(False,'FIREWALL_IP_EXISTS')
        
        public.ExecShell('netsh ipsec static add filter filterlist=IpList srcaddr=' + address + ' srcport=0 dstaddr=me dstport=0 protocol=ANY mirrored=no description="' + ps + '"');

        public.WriteLog("TYPE_FIREWALL", 'FIREWALL_DROP_IP',(address,))
        addtime = time.strftime('%Y-%m-%d %X',time.localtime())
        public.M('firewall').add('port,ps,addtime',(address,ps,addtime))
        return public.returnMsg(True,'ADD_SUCCESS')

    #删除IP屏蔽
    def DelDropAddress(self,get):
        address = get.port
        id = get.id

        public.ExecShell('netsh ipsec static delete filter filterlist=IpList srcaddr=' + address + ' srcport=0 dstaddr=me dstport=0 protocol=any mirrored=no')        
        public.WriteLog("TYPE_FIREWALL",'FIREWALL_ACCEPT_IP',(address,))
        public.M('firewall').where("id=?",(id,)).delete()
        
        return public.returnMsg(True,'DEL_SUCCESS')

    #设置远程桌面状态
    def SetSshStatus(self,get):
        if int(get['status'])==1:
           msg = public.getMsg('FIREWALL_SSH_STOP')
           status = 0
        else:
           msg = public.getMsg('FIREWALL_SSH_START')
           status = 1
        for x in [0,1,2,3,4,5,6,7,8,9,10]:
           public.ExecShell("ECHO Y|logoff " + str(i))
        
        self.WriteReg('SYSTEM\CurrentControlSet\Control\Terminal Server','fDenyTSConnections',status)
        public.WriteLog("TYPE_FIREWALL", msg)
        return public.returnMsg(True,'SUCCESS')
    
    #设置远程桌面端口
    def SetMstscPort(self,get):
        port = get.port
        if int(port) < 22 or int(port) > 65535: return public.returnMsg(False,'FIREWALL_SSH_PORT_ERR');
        ports = ['21','25','80','443','8080','888','8888'];
        if port in ports: return public.returnMsg(False,'');

        for x in [0,1,2,3,4,5,6,7,8,9,10]:
            public.ExecShell("ECHO Y|logoff " + str(x))
        regPath = 'SYSTEM\CurrentControlSet\Control\Terminal Server';
        self.WriteReg(regPath,'fDenyTSConnections',1)
        self.WriteReg('SYSTEM\CurrentControlSet\Control\Terminal Server\Wds\rdpwd\Tds\tcp','PortNumber',port)
        self.WriteReg('SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp','PortNumber',port)
        time.sleep(0.2)
        self.WriteReg(regPath,'fDenyTSConnections',0)
        
        public.M('firewall').where("ps=?",('SSH远程管理服务',)).setField('port',port)
        public.WriteLog("TYPE_FIREWALL", "FIREWALL_SSH_PORT",(port,))
        return public.returnMsg(True,'EDIT_SUCCESS') 

    #初始化IP安全策略
    def firewall_init(self):
        public.ExecShell('Netsh ipsec static add policy name =宝塔IP安全策略 description="用于过滤IP,禁PING,请不要删除"')       
        result = public.ExecShell("Netsh ipsec static show filterlist name=IpList")
        if result[0].find('ERR')!=-1:
            public.ExecShell("Netsh ipsec static add filteraction name = 阻止IP访问 action =block")
            public.ExecShell('Netsh ipsec static add filterlist name=IpList description="禁止列表内的IP访问这台服务器"')
            public.ExecShell('Netsh ipsec static add filter filterlist=IpList srcaddr=122.226.158.132 srcport=0 dstaddr=me dstport=0 protocol=ANY mirrored=no description="初始化"')
        public.ExecShell("netsh ipsec static add rule name =屏蔽IP Policy = 宝塔IP安全策略 filterlist =IpList filteraction =  阻止IP访问")
        public.ExecShell("Netsh ipsec static set policy name = 宝塔IP安全策略 assign = y")
        cache.set('firewall_init',1)
        return True

     #获取文件内容
    def GetFileBody(self,get) :
        #if sys.version_info[0] == 2: get.path = get.path.encode('utf-8');
        if not os.path.exists(get.path):
            if get.path.find('rewrite') == -1:
                return public.returnMsg(False,'FILE_NOT_EXISTS',(get.path,))
            public.writeFile(get.path,'');
        
        if os.path.getsize(get.path) > 2097152: return public.returnMsg(False,u'不能在线编辑大于2MB的文件!');
        fp = open(get.path,'rb')
        data = {}
        data['status'] = True
        
        #try:
        if fp:
            from chardet.universaldetector import UniversalDetector
            detector = UniversalDetector()
            srcBody = b""
            for line in fp.readlines():
                detector.feed(line)
                srcBody += line
            detector.close()
            char = detector.result
            data['encoding'] = char['encoding']
            if char['encoding'] == 'GB2312' or not char['encoding'] or char['encoding'] == 'TIS-620' or char['encoding'] == 'ISO-8859-9': data['encoding'] = 'GBK';
            if char['encoding'] == 'ascii' or char['encoding'] == 'ISO-8859-1': data['encoding'] = 'utf-8';
            if char['encoding'] == 'Big5': data['encoding'] = 'BIG5';
            if not char['encoding'] in ['GBK','utf-8','BIG5']: data['encoding'] = 'utf-8';
            try:
                if sys.version_info[0] == 2: 
                    data['data'] = srcBody.decode(data['encoding']).encode('utf-8',errors='ignore');
                else:
                    data['data'] = srcBody.decode(data['encoding'])
            except:
                data['encoding'] = char['encoding'];
                if sys.version_info[0] == 2: 
                    data['data'] = srcBody.decode(data['encoding']).encode('utf-8',errors='ignore');
                else:
                    data['data'] = srcBody.decode(data['encoding'])
        else:
            if sys.version_info[0] == 2: 
                data['data'] = srcBody.decode('utf-8').encode('utf-8');
            else:
                data['data'] = srcBody.decode('utf-8')
            data['encoding'] = u'utf-8';

        return data;
        #except Exception as ex:
        #    return public.returnMsg(False,u'文件编码不被兼容，无法正确读取文件!' + str(ex));
    
    #检测文件名
    def CheckFileName(self,filename):
        nots = ['\\','&','*','#','@','|']
        if filename.find('/') != -1: filename = filename.split('/')[-1]
        for n in nots:
            if n in filename: return False
        return True

    #计算文件数量
    def GetFilesCount(self,path,search):
        i=0;
        for name in os.listdir(path):
            if search:
                if name.lower().find(search) == -1: continue;
            i += 1;
        return i;
    
     #创建目录
    def CreateDir(self,get):
        if sys.version_info[0] == 2: get.path = get.path.encode('utf-8').strip();
        try:
            if not self.CheckFileName(get.path): return public.returnMsg(False,'目录名中不能包含特殊字符!');
            if os.path.exists(get.path):
                return public.returnMsg(False,'DIR_EXISTS')
            os.makedirs(get.path)
           
            public.WriteLog('TYPE_FILE','DIR_CREATE_SUCCESS',(get.path,))
            return public.returnMsg(True,'DIR_CREATE_SUCCESS')
        except:
            return public.returnMsg(False,'DIR_CREATE_ERR')

    #创建文件
    def CreateFile(self,get):        
        if sys.version_info[0] == 2: get.path = get.path.encode('utf-8').strip();
        try:
            if not self.CheckFileName(get.path): return public.returnMsg(False,'文件名中不能包含特殊字符!');
            if os.path.exists(get.path):
                return public.returnMsg(False,'FILE_EXISTS')
            path = os.path.dirname(get.path)
            if not os.path.exists(path):
                os.makedirs(path)
            open(get.path,'w+').close()           
            public.WriteLog('TYPE_FILE','FILE_CREATE_SUCCESS',(get.path,))
            return public.returnMsg(True,'FILE_CREATE_SUCCESS')
        except:
            return public.returnMsg(False,'FILE_CREATE_ERR')
    
    #设置默认权限
    def SetFileAccept(self,filename,deluser = True):
        import win32security
        sd = win32security.GetFileSecurity(filename, win32security.DACL_SECURITY_INFORMATION)
        dacl = sd.GetSecurityDescriptorDacl()
        ace_count = dacl.GetAceCount()
        for i in range(ace_count -1, 0,-1):
            data = {}
            data['rev'], data['access'], usersid = dacl.GetAce(i)
            data['user'],data['group'], data['type'] = win32security.LookupAccountSid('', usersid)           
            if data['user'].lower().find('user')>=0:
                dacl.DeleteAce(i)
        sd.SetSecurityDescriptorDacl(1, dacl, 0)
        win32security.SetFileSecurity(filename, win32security.DACL_SECURITY_INFORMATION, sd)
        return public.returnMsg(True,'删除User权限成功')

    def GetFileList(self,path, list):        
        files = os.listdir(path)
        list.append(path)
        for file in files:
            if os.path.isdir(path + '/' + file):
                self.GetFileList(path + '/' + file, list)
            else:
                list.append(path + '/' + file)

    #文件压缩
    def Zip(self,get) :
        if sys.version_info[0] == 2:
            get.sfile = get.sfile.encode('utf-8');
            get.dfile = get.dfile.encode('utf-8');
        if sys.version_info[0] == 2: get.path = get.path.encode('utf-8');
        if get.sfile.find(',') == -1:
            if not os.path.exists(get.sfile): return public.returnMsg(False,'FILE_NOT_EXISTS');
        #try:                        
        import zipfile    
       
        filelists = []
        self.GetFileList(get.sfile, filelists)
        f = zipfile.ZipFile(get.dfile,'w',zipfile.ZIP_DEFLATED)
        for item in filelists:
             f.write(item)       
        f.close()
        self.SetFileAccept(get.dfile);
        public.WriteLog("TYPE_FILE", 'ZIP_SUCCESS',(get.sfile,get.dfile));
        return public.returnMsg(True,'ZIP_SUCCESS')
        #except:
            #return public.returnMsg(False,'ZIP_ERR')

    def get_access(self,get):
        import win32security
        path = get.path
        sd = win32security.GetFileSecurity(path, win32security.DACL_SECURITY_INFORMATION)
        dacl = sd.GetSecurityDescriptorDacl()
        ace_count = dacl.GetAceCount()
        arrs = []
        for i in range(0, ace_count):
            data = {}
            data['rev'], data['access'], usersid = dacl.GetAce(i)
            data['user'],data['group'], data['type'] = win32security.LookupAccountSid('', usersid)
            arrs.append(data)
        return arrs;

    def del_access(self,get):
        self.SetFileAccept(get.path)

    #设置文件权限和所有者
    def SetFileAccess(self,get):
        filename = get.filename
        access = int(get.access)
        try:
            #if not self.CheckDir(get.filename): return public.returnMsg(False,'FILE_DANGER');
            if not os.path.exists(get.filename):
                return public.returnMsg(False,'FILE_NOT_EXISTS')
            
            import win32security
            sd = win32security.GetFileSecurity(filename, win32security.DACL_SECURITY_INFORMATION)
            dacl = sd.GetSecurityDescriptorDacl()
            ace_count = dacl.GetAceCount()
            for i in range(ace_count -1, 0,-1):
                data = {}
                data['rev'], data['access'], usersid = dacl.GetAce(i)
                data['user'],data['group'], data['type'] = win32security.LookupAccountSid('', usersid)           
                if data['user'].lower().find(get.user)>=0:
                    dacl.DeleteAce(i) #删除旧的dacl
            userx, domain, type = win32security.LookupAccountName("", get.user)
            dacl.AddAccessAllowedAceEx(win32security.ACL_REVISION, 3, access, userx)

            sd.SetSecurityDescriptorDacl(1, dacl, 0)
            win32security.SetFileSecurity(filename, win32security.DACL_SECURITY_INFORMATION, sd)

            public.WriteLog('TYPE_FILE','FILE_ACCESS_SUCCESS',(get.filename,get.access,get.user))
            return public.returnMsg(True,'SET_SUCCESS')
        except:
            return public.returnMsg(False,'SET_ERROR')
    

    #写入/创建注册表
    def WriteReg(self,path,key,value):
        import winreg
        try:
            newKey = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE ,path)
        except :
            newKey = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE ,path)
        try:
            if isinstance(value,int):
                winreg.SetValue(newKey,key,winreg.REG_SZ,value)
            else:
                winreg.SetValue(newKey,key,winreg.REG_DWORD,value)
            return True
        except :
            return False
    
    #读取注册表
    def ReadReg(self,path,key):
        import winreg
        try:
            newKey = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE ,path)
            value,type = winreg.QueryValueEx(newKey, key)
            return value
        except :
            return False      

    #删除注册表
    def DelReg(self,path,key):
        import winreg
        try:
            newKey = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE ,path)
            winreg.DeleteKey(newKey,key)
            return True
        except :
            return False

    #文件解压
    def UnZip(self,get):
        if sys.version_info[0] == 2:
            get.sfile = get.sfile.encode('utf-8');
            get.dfile = get.dfile.encode('utf-8');
        if not os.path.exists(get.sfile):
            return public.returnMsg(False,'FILE_NOT_EXISTS');
        if not hasattr(get,'password'): get.password = '';
               
        if not os.path.exists(get.dfile) :
            os.makedirs(get.dfile)

        ext = os.path.splitext(get.sfile)[-1]

        if ext == '.zip':            
            zip_file = zipfile.ZipFile(get.sfile)  
            for names in zip_file.namelist():  
                zip_file.extract(names, get.dfile)  
            zip_file.close()
        elif ext == '.rar':
             rar = rarfile.RarFile(get.sfile)  
             rar.extractall(get.dfile)  
             rar.close()
        return public.returnMsg(True,'UNZIP_SUCCESS');
        #except:
        #    return public.returnMsg(False,'文件解压失败!')
    

    def run_crontab(self,get):
        import threading
        
        p = threading.Thread(target=self.process_thread)
        p.setDaemon(True)
        p.start()

    #处理线程
    def process_thread(self):
        import time
        #time.strftime('%Y-%m-%d %H:%m',time.localtime(time.time()))
        interval = 1
        total = 0

        slist = {}
        while(True):
            if total % 600000 == 0:
               data = self.get_list(slist)
            
            dtime = time.time()
            ctime = time.localtime()            
            stime = time.strftime('%Y-%m-%d %H:%M',ctime)

            for item in data:
               
                if item['status']==1:
                    if item['lasttime'] == stime:       
                        #self.logs("本分钟已经更新过了，开始跳过..",stime)
                        continue;
                    stype = item['type']                   
                    sdata = None
                    if stype =='day':
                        if item['where_hour'] == ctime.tm_hour and item['where_minute']  == ctime.tm_min:
                            item['lasttime'] = stime
                            sdata = item;
                    elif stype=='day-n':
                        v = (dtime - item['atime']) % (int(item['where1']) *  86400);
                        if int(v) == 0:
                            if item['where_hour'] == ctime.tm_hour and item['where_minute']  == ctime.tm_min:
                                item['lasttime'] = stime
                                sdata = item;
                    elif stype == 'hour':
                         if item['where_minute']  == minute:
                             item['lasttime'] = stime
                             sdata = item;
                    elif stype == 'hour-n':
                          v = (dtime - item['atime']) % (int(item['where1']) *  3600);
                          if int(v) == 0:
                                if item['where_minute']  == minute:
                                    item['lasttime'] = stime
                                    sdata = item;
                    elif stype == 'minute-n':
                        v = (dtime - item['atime']) % (int(item['where1']) *  60);
                        if int(v) == 0:
                            item['lasttime'] = stime
                            sdata = item;
                    elif stype == 'week':
                        week = time.strftime('%w',ctime)
                        if week == int(item['where1']):
                            if item['where_hour'] == ctime.tm_hour and item['where_minute']  == ctime.tm_min:
                                item['lasttime'] = stime
                                sdata = item;
                    elif stype == 'month':
                        if ctime.tm_mday == int(item['where1']):
                            if item['where_hour'] == ctime.tm_hour and item['where_minute']  == ctime.tm_min:
                                item['lasttime'] = stime
                                sdata = item;

                    slist[item['id']] = item['lasttime']
                    if not sdata is None:
                        t = threading.Thread(target=self.process_data,args=(sdata,stime))
                        t.setDaemon(True)
                        t.start()

            time.sleep(interval)
            total += interval
        return data


    def get_local_time(self,now_time):
        import time
        time_array = time.strptime(now_time, "%Y-%m-%d %H:%M:%S")
        timestamp = time.mktime(time_array)
        return timestamp

    def process_data(self,sdata,stime):
        self.logs(sdata,stime);

    def logs(self,data,stime):
         public.writeFile('c:\\thread.log',str(stime)+ " : "+ str(data)+'\n','a+')

    def get_list(self,slist):
        import json
        data = public.M('crontab').where("id>?",(0,)).field('id,name,type,where1,where_hour,where_minute,echo,addtime,status,save,backupTo,sName,sBody,sType,urladdress').select()
        #data = '[{"status": 1, "sName": "www.tp5.cn", "name": "\u5907\u4efd\u7f51\u7ad9[www.tp5.cn]", "sBody": "undefined", "where_minute": "", "where1": "3", "addtime": "2018-10-26 11:49:48", "echo": "bd661f1adbf2d1a65d0ceb74888b305d", "cycle": "\u6bcf\u96943\u5206\u949f\u6267\u884c", "backupTo": "localhost", "type": "minute-n", "save": 3, "where_hour": "", "id": 157, "sType": "site", "urladdress": "undefined"}, {"status": 1, "sName": "3.hao.com", "name": "\u5907\u4efd\u7f51\u7ad9[3.hao.com]", "sBody": "undefined", "where_minute": 30, "where1": "3", "addtime": "2018-10-26 11:07:18", "echo": "eb8f6874ed3011bbccd736c1812d2c90", "cycle": "\u6bcf3\u5c0f\u65f6, \u7b2c30\u5206\u949f \u6267\u884c", "backupTo": "localhost", "type": "\u6bcf3\u5c0f\u65f6", "save": 3, "where_hour": "", "id": 156, "sType": "site", "urladdress": "undefined"}, {"status": 1, "sName": "3.hao.com", "name": "\u5907\u4efd\u7f51\u7ad9[3.hao.com]", "sBody": "undefined", "where_minute": 30, "where1": "", "addtime": "2018-10-26 11:07:14", "echo": "2cd89a7074820cd214a0a2abbefdcb8e", "cycle": "\u6bcf\u5c0f\u65f6, \u7b2c30\u5206\u949f \u6267\u884c", "backupTo": "localhost", "type": "\u6bcf\u5c0f\u65f6", "save": 3, "where_hour": "", "id": 155, "sType": "site", "urladdress": "undefined"}, {"status": 1, "sName": "w1.hao.com", "name": "\u5907\u4efd\u7f51\u7ad9[w1.hao.com]", "sBody": "undefined", "where_minute": 30, "where1": "", "addtime": "2018-10-26 10:53:59", "echo": "7016590411f071b9895a9436f1c0f2a2", "cycle": "\u6bcf\u5929, 1\u70b930\u5206 \u6267\u884c", "backupTo": "localhost", "type": "\u6bcf\u5929", "save": 3, "where_hour": 1, "id": 154, "sType": "site", "urladdress": "undefined"}, {"status": 1, "sName": "w1.hao.com", "name": "\u5907\u4efd\u7f51\u7ad9[w1.hao.com]", "sBody": "undefined", "where_minute": 30, "where1": "1", "addtime": "2018-10-24 10:33:06", "echo": "067eaca8d6cfffa78b6d2eb7d9b52e3e", "cycle": "\u6bcf\u5468\u4e00, 1\u70b930\u5206\u6267\u884c", "backupTo": "txcos", "type": "\u6bcf\u5468", "save": 3, "where_hour": 1, "id": 152, "sType": "site", "urladdress": "undefined"}, {"status": 1, "sName": "wrewwww", "name": "\u5907\u4efd\u6570\u636e\u5e93[wrewwww]", "sBody": "undefined", "where_minute": 30, "where1": "1", "addtime": "2018-10-24 10:32:21", "echo": "a02b909e8ba739c6f6eba69ed3351a00", "cycle": "\u6bcf\u5468\u4e00, 1\u70b930\u5206\u6267\u884c", "backupTo": "txcos", "type": "\u6bcf\u5468", "save": 3, "where_hour": 1, "id": 151, "sType": "database", "urladdress": "undefined"}, {"status": 1, "sName": "wrewwww", "name": "\u5907\u4efd\u6570\u636e\u5e93[wrewwww]", "sBody": "undefined", "where_minute": 30, "where1": "1", "addtime": "2018-10-24 10:27:30", "echo": "63fe39e859606ceca5234f896766f305", "cycle": "\u6bcf\u5468\u4e00, 1\u70b930\u5206\u6267\u884c", "backupTo": "alioss", "type": "\u6bcf\u5468", "save": 3, "where_hour": 1, "id": 150, "sType": "database", "urladdress": "undefined"}, {"status": 1, "sName": "wrewwww", "name": "\u5907\u4efd\u6570\u636e\u5e93[wrewwww]", "sBody": "undefined", "where_minute": 30, "where1": "1", "addtime": "2018-10-24 10:27:18", "echo": "7c8a9f7dadbc1b6a6db9c0bdb07dc32b", "cycle": "\u6bcf\u5468\u4e00, 1\u70b930\u5206\u6267\u884c", "backupTo": "localhost", "type": "\u6bcf\u5468", "save": 3, "where_hour": 1, "id": 149, "sType": "database", "urladdress": "undefined"}, {"status": 1, "sName": "w1.hao.com", "name": "\u5907\u4efd\u7f51\u7ad9[w1.hao.com]", "sBody": "undefined", "where_minute": 30, "where1": "1", "addtime": "2018-10-24 10:21:57", "echo": "f38fd42cf549ba08c41a0c83507f2b35", "cycle": "\u6bcf\u5468\u4e00, 1\u70b930\u5206\u6267\u884c", "backupTo": "alioss", "type": "\u6bcf\u5468", "save": 3, "where_hour": 1, "id": 148, "sType": "site", "urladdress": "undefined"}, {"status": 1, "sName": "", "name": "df", "sBody": "df", "where_minute": 30, "where1": "1", "addtime": "2018-10-17 14:24:49", "echo": "b515c0b10d4cad4f4a559e81116b2fe2", "cycle": "\u6bcf\u5468\u4e00, 1\u70b930\u5206\u6267\u884c", "backupTo": "localhost", "type": "\u6bcf\u5468", "save": "", "where_hour": 1, "id": 147, "sType": "toShell", "urladdress": "undefined"}, {"status": 1, "sName": "ALL", "name": "\u5907\u4efd\u7f51\u7ad9[ALL]", "sBody": "undefined", "where_minute": 30, "where1": "3", "addtime": "2018-08-16 09:50:16", "echo": "a4ba8da20b2a05e3a2caf7e759df14cc", "cycle": "\u6bcf\u96943\u5929, 1\u70b930\u5206 \u6267\u884c", "backupTo": "alioss", "type": "\u6bcf3\u5929", "save": 5, "where_hour": 1, "id": 137, "sType": "site", "urladdress": "undefined"}, {"status": 1, "sName": "ALL", "name": "\u5907\u4efd\u6570\u636e\u5e93[ALL]", "sBody": "undefined", "where_minute": 30, "where1": "1", "addtime": "2018-08-16 09:45:17", "echo": "1fdd103abd483e9b695f8c3176e7011e", "cycle": "\u6bcf\u5468\u4e00, 1\u70b930\u5206\u6267\u884c", "backupTo": "localhost", "type": "\u6bcf\u5468", "save": 3, "where_hour": 1, "id": 136, "sType": "database", "urladdress": "undefined"}]'
        #data = json.loads(data)
        for item in data:
            item['lasttime'] = 0
            item['atime'] = self.get_local_time(item['addtime'])
            for sitem in slist:
                if sitem[item['id']]:
                    item['lasttime'] = sitem[item['id']]
        return data