import public,db,re,os,time
import zipfile    

class panelBackup:
    def __init__(self):
        pass

    #备份网站
    def backupSite(self,name):
       
        sql = db.Sql();
        path = sql.table('sites').where('name=?',(name,)).getField('path');
        if not path:
            endDate = time.strftime('%Y/%m/%d %X',time.localtime())
            log = "网站["+name+"]不存在!"
            print("★["+endDate+"] "+log)
            print("----------------------------------------------------------------------------")
            return;
        
        backup_path = sql.table('config').where("id=?",(1,)).getField('backup_path') + '/site';
        if not os.path.exists(backup_path): os.makedirs(backup_path)        
        filename = backup_path + "/Web_" + name + "_" + time.strftime('%Y%m%d_%H%M%S',time.localtime()) + '.zip'

        #ZIP压缩
        self.Zip(path,filename);
        
        if not os.path.exists(filename):
            log = "网站["+name+"]备份失败!"
            print("★["+endDate+"] "+log)
            print("----------------------------------------------------------------------------")
            return False;       

        return filename

    #备份数据库
    def backupDatabase(self,name):

        sql = db.Sql();
        id = sql.table('databases').where('name=?',(name,)).getField('id');

        if not id:
            endDate = time.strftime('%Y/%m/%d %X',time.localtime())
            log = u"数据库["+name+u"]不存在!"
            print(u"★["+endDate+"] "+log)
            print(u"----------------------------------------------------------------------------")
            return False;
        
        backup_path = sql.table('config').where("id=?",(1,)).getField('backup_path') + '/database';
        if not os.path.exists(backup_path): os.makedirs(backup_path);
        
        sqlfile = backup_path + "/Db_" + name + "_" + time.strftime('%Y%m%d_%H%M%S',time.localtime())+".sql"      
        mysql_root = sql.table('config').where("id=?",(1,)).getField('mysql_root')        

        if public.get_server_status('mysql') < 0:
            log = u"未安装MySQL服务!"
            print(u"★["+endDate+"] "+log)
            print(u"----------------------------------------------------------------------------")
            return False;
        
        #去mysql安装目录
        _version = re.search('([MySQL|MariaDB-]+\d+\.\d+)',public.get_server_path('mysql')).groups()[0] 
        _setup_path  = public.GetConfigValue('setup_path') + '/mysql/' + _version

        public.ExecShell(_setup_path + "/bin/mysqldump.exe -uroot -p" + mysql_root + " -R " + name + " > " + sqlfile)
        if not os.path.exists(sqlfile):
            endDate = time.strftime('%Y/%m/%d %X',time.localtime())
            log = u"数据库["+name+u"]备份失败!"
            print(u"★[" + endDate + "] "+log)
            print(u"----------------------------------------------------------------------------")
            return False; 
        
        filename = sqlfile.replace(".sql",".zip")
        self.Zip(sqlfile,filename);
        os.remove(sqlfile)

        return filename
    
    #备份指定目录
    def backupPath(self,path):
        sql = db.Sql();

        if path[-1:] == '/': path = path[:-1]
        name = os.path.basename(path)
        backup_path = sql.table('config').where("id=?",(1,)).getField('backup_path') + '/path';
        if not os.path.exists(backup_path): os.makedirs(backup_path);

        self.Zip(os.path.basename(path),filename)    
        endDate = time.strftime('%Y/%m/%d %X',time.localtime())
        if not os.path.exists(filename):
            log = u"目录["+path+"]备份失败"
            print(u"★["+endDate+"] "+log)
            print(u"----------------------------------------------------------------------------")
            return False;

        return filename


    #文件压缩
    def Zip(self,sfile,dfile) :           
        try:
            import zipfile
            filelists = []
            path = sfile;
            if os.path.isdir(sfile): 
                self.GetFileList(sfile, filelists)
            else:
                path = os.path.dirname(sfile)
                filelists.append(sfile)
       
            f = zipfile.ZipFile(dfile,'w',zipfile.ZIP_DEFLATED)
            for item in filelists:
                f.write(item,item.replace(path,''))       
            f.close()   
            return True
        except :
            return False      
    
    #获取所有文件列表
    def GetFileList(self,path, list):        
        files = os.listdir(path)
        list.append(path)
        for file in files:
            if os.path.isdir(path + '/' + file):
                self.GetFileList(path + '/' + file, list)
            else:
                list.append(path + '/' + file)