#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 曹觉心 <314866873@qq.com>
# +-------------------------------------------------------------------

import re,os,sys,public

class panelMssql:
    __DB_PASS = None
    __DB_USER = 'sa'
    __DB_PORT = 1433
    __DB_HOST = '.'
    __DB_CONN = None
    __DB_CUR  = None
    __DB_ERR  = None
    #连接MSSQL数据库
    def __Conn(self):
        import pymssql
        sa_path = 'data/sa.pl'
        if os.path.exists(sa_path):
            self.__DB_PASS = public.readFile(sa_path)
            self.__DB_CONN = pymssql.connect(server = self.__DB_HOST, port= str(self.__DB_PORT), user = self.__DB_USER, password = self.__DB_PASS,login_timeout = 60,timeout = 0,autocommit = True)
            self.__DB_CUR = self.__DB_CONN.cursor()  #将数据库连接信息，赋值给cur。
            if self.__DB_CUR:
                return True
            else:
                self.__DB_ERR = '连接数据库失败'
                return False

          
    def execute(self,sql):
        #执行SQL语句返回受影响行
        if not self.__Conn(): return self.__DB_ERR
        try:
            result = self.__DB_CUR.execute(sql)
            self.__Close()
            return result
        except Exception as ex:
            return ex
    
    
    def query(self,sql):
        #执行SQL语句返回数据集
        if not self.__Conn(): return self.__DB_ERR
        try:
            self.__DB_CUR.execute(sql)
            result = self.__DB_CUR.fetchall()
            #print(result)
            #将元组转换成列表
            #data = map(list,result)
            data = result
            self.__Close()
            return data
        except Exception as ex:
            return ex
        
     
    #关闭连接        
    def __Close(self):
        self.__DB_CUR.close()
        self.__DB_CONN.close()