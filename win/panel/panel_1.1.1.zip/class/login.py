from flask import render_template ,send_file ,request ,redirect #line:1
from BTPanel import app ,session #line:2
import public #line:3
def POST ():#line:5
    session ['lan']=public .GetLanguage ();#line:6
    if not 'webname'in session :session ['webname']=public .GetMsg ('NAME');#line:7
    OOO0000OO00000000 =public .ReadFile ('data/domain.conf')#line:8
    if OOO0000OO00000000 :#line:9
        if (request .headers .get ('host').split (':')[0 ].strip ()!=OOO0000OO00000000 .strip ()):return '访问域名错误'#line:10
    if os .path .exists ('data/limitip.conf'):#line:11
        O0OOOO0OO0O0OOOOO =public .readFile ('data/limitip.conf')#line:12
        if O0OOOO0OO0O0OOOOO :#line:13
            O0OOOO0OO0O0OOOOO =O0OOOO0OO0O0OOOOO .strip ();#line:14
            if not web .ctx .ip in O0OOOO0OO0O0OOOOO .split (','):#line:15
                O000O0O0OOO0OOOOO ='''
<meta charset="utf-8">
<title>%s</title>
</head><body>
<h1>%s</h1>
    <p>%s</p>
    <p>%s</p>
    <p>%s</p>
<hr>
<address>%s 5.x <a href="http://www.bt.cn/bbs" target="_blank">%s</a></address>
</body></html>
'''%(public .getMsg ('PAGE_ERR_TITLE'),public .getMsg ('PAGE_ERR_IP_H1'),public .getMsg ('PAGE_ERR_IP_P1',(web .ctx .ip ,)),public .getMsg ('PAGE_ERR_IP_P2'),public .getMsg ('PAGE_ERR_IP_P3'),public .getMsg ('NAME'),public .getMsg ('PAGE_ERR_HELP'))#line:27
                web .header ('Content-Type','text/html; charset=utf-8',unique =True )#line:28
                return O000O0O0OOO0OOOOO ;#line:29
    O0000O0O00OOO0O0O =web .input ()#line:31
    OO0000OO00O0OO00O =db .Sql ()#line:32
    if hasattr (O0000O0O00OOO0O0O ,'dologin'):#line:33
        if session .login !=False :#line:34
            session .login =False ;#line:35
            session .kill ();#line:36
        import time #line:37
        time .sleep (0.2 );#line:38
        raise web .seeother ('/login')#line:39
    if hasattr (session ,'login'):#line:41
        if session .login ==True :#line:42
            raise web .seeother ('/')#line:43
    if not hasattr (session ,'code'):#line:45
        session .code =False #line:46
    OOO000O000OO000O0 ={}#line:47
    OOO000O000OO000O0 ['lan']=public .getLan ('login')#line:48
    self .errorNum (False )#line:49
    O000O0OOOO000O0O0 =web .template .render ('templates/'+templateName +'/',globals ={'session':session ,'web':web })#line:50
    return O000O0OOOO000O0O0 .login (OOO000O000OO000O0 )#line:51
