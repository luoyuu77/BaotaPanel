import public ,os ,sys ,json ,time ,psutil ,re #line:10
from BTPanel import session ,cache ,get_input #line:11
class mget :pass ;#line:12
class panelPlugin :#line:13
    __OOOO0000000OO0O0O =None ;#line:14
    __O00000O0O0OO0OO0O =None ;#line:15
    __OOO000000OO0OOO00 =None ;#line:16
    __O0O000O0OO00000OO ='data/list.json'#line:17
    __O0OO0O00OO00OO00O ='data/type.json'#line:18
    __O00O000000O0000OO ='config/index.json'#line:19
    __OO0OO0O00O0O000O0 ='config/link.json'#line:20
    __O0OO00O0OOO0O0000 =None #line:21
    __OOO000O00OOO00O0O =None #line:22
    __O00000OOO0OO000OO =None #line:23
    pids =None #line:24
    ROWS =15 ;#line:25
    def __init__ (OO00O0OOO00OO000O ):#line:27
        OO00O0OOO00OO000O .__O00000O0O0OO0OO0O ='plugin'#line:28
        OO00O0OOO00OO000O .__O00000OOO0OO000OO =public .GetConfigValue ('setup_path')#line:29
        OO00O000OO0O0O00O =OO00O0OOO00OO000O .__O00000OOO0OO000OO +'/temp/session'#line:31
        if not os .path .exists (OO00O000OO0O0O00O ):os .makedirs (OO00O000OO0O0O00O )#line:32
    def check_deps (OO0O0O0OOOO0O0OOO ,OOOO0OOOO00OO0O0O ):#line:36
        OO0O000O00O000O00 ='plugin_lib_list'#line:37
        if not 'force'in OOOO0OOOO00OO0O0O :#line:38
            O0OOOOO0OOO0OO0OO =cache .get (OO0O000O00O000O00 )#line:39
            if O0OOOOO0OOO0OO0OO :return O0OOOOO0OOO0OO0OO #line:40
        O0OOOOO0OOO0OO0OO =json .loads (public .readFile ('config/lib.json'))#line:41
        O0O00000OO0O00O0O =os .path .exists ('/bin/yum')#line:42
        for OOOO000O0OO00O0O0 in O0OOOOO0OOO0OO0OO .keys ():#line:43
            for OO0OO0OO0OO00O0OO in range (len (O0OOOOO0OOO0OO0OO [OOOO000O0OO00O0O0 ])):#line:44
                OO0OOO0O0O0OO0O0O =O0OOOOO0OOO0OO0OO [OOOO000O0OO00O0O0 ][OO0OO0OO0OO00O0OO ]['check'].split (',')#line:45
                O0OOOOO0OOO0OO0OO [OOOO000O0OO00O0O0 ][OO0OO0OO0OO00O0OO ]['status']=False #line:46
                for OO0O0OOO00OOO00O0 in OO0OOO0O0O0OO0O0O :#line:47
                    if os .path .exists (OO0O0OOO00OOO00O0 ):#line:48
                        O0OOOOO0OOO0OO0OO [OOOO000O0OO00O0O0 ][OO0OO0OO0OO00O0OO ]['status']=True #line:49
                        break ;#line:50
                O0OOOOO0OOO0OO0OO [OOOO000O0OO00O0O0 ][OO0OO0OO0OO00O0OO ]['version']="-"#line:51
                if O0OOOOO0OOO0OO0OO [OOOO000O0OO00O0O0 ][OO0OO0OO0OO00O0OO ]['status']:#line:52
                    OO00OO0O000O0OOO0 =O0OOOOO0OOO0OO0OO [OOOO000O0OO00O0O0 ][OO0OO0OO0OO00O0OO ]['getv'].split (':D')#line:53
                    OOOOOOO0O0O0O000O =OO00OO0O000O0OOO0 [0 ]#line:54
                    if len (OO00OO0O000O0OOO0 )>1 and not O0O00000OO0O00O0O :OOOOOOO0O0O0O000O =OO00OO0O000O0OOO0 [1 ]#line:55
                    O0OOOOO0OOO0OO0OO [OOOO000O0OO00O0O0 ][OO0OO0OO0OO00O0OO ]['version']=public .ExecShell (OOOOOOO0O0O0O000O )[0 ].strip ()#line:56
        cache .set (OO0O000O00O000O00 ,O0OOOOO0OOO0OO0OO ,86400 );#line:57
        return O0OOOOO0OOO0OO0OO #line:58
    def check_mutex (OOO000O000O00OO00 ,O0O0O0OO0O0OO0O00 ):#line:61
        O00OO00OOOO0O0O0O =O0O0O0OO0O0OO0O00 .split (',')#line:62
        for O00OOO0O0O0000000 in O00OO00OOOO0O0O0O :#line:63
            OOO000OO0OOO000OO =OOO000O000O00OO00 .get_soft_find (O00OOO0O0O0000000 )#line:64
            if not OOO000OO0OOO000OO :continue #line:65
            if OOO000OO0OOO000OO ['setup']==True :return False #line:66
        return True #line:67
    def check_dependnet (OO0000OOO00OOOOOO ,OO0OOOO0OO00OOO0O ):#line:70
        if not OO0OOOO0OO00OOO0O :return True #line:71
        OO0O00000O0O000OO =OO0OOOO0OO00OOO0O .split (',')#line:72
        O00OO00O0000000OO =True ;#line:73
        for O00O00OOO000O0000 in OO0O00000O0O000OO :#line:74
            if not O00O00OOO000O0000 :continue #line:75
            if O00O00OOO000O0000 .find ('|')!=-1 :#line:76
                OO00O0O000OO00OOO =O00O00OOO000O0000 .split ('|')#line:77
                for OOOO0O000OO0O00O0 in OO00O0O000OO00OOO :#line:78
                    OOO0OOOO00000000O =OO0000OOO00OOOOOO .get_soft_find (OOOO0O000OO0O00O0 )#line:79
                    if OOO0OOOO00000000O :#line:80
                        if OOO0OOOO00000000O ['setup']==True :#line:81
                            O00OO00O0000000OO =True #line:82
                            break #line:83
                        else :#line:84
                            O00OO00O0000000OO =False #line:85
            else :#line:86
                OOO0OOOO00000000O =OO0000OOO00OOOOOO .get_soft_find (O00O00OOO000O0000 )#line:87
                if OOO0OOOO00000000O :#line:88
                    if OOO0OOOO00000000O ['setup']!=True :#line:89
                        O00OO00O0000000OO =False #line:90
                        break #line:91
        return O00OO00O0000000OO #line:92
    def check_cpu_limit (OOO0O0OO00O00OOOO ,O0O000OOO0O00OOO0 ):#line:95
        if psutil .cpu_count ()<O0O000OOO0O00OOO0 :return False #line:96
        return True #line:97
    def check_mem_limit (O0000O00O0OOO0OOO ,OO0O000O000O0O0OO ):#line:100
        print (psutil .virtual_memory ().total /1024 /1024 ,OO0O000O000O0O0OO )#line:101
        if psutil .virtual_memory ().total /1024 /1024 <OO0O000O000O0O0OO :return False #line:102
        return True #line:103
    def check_os_limit (O0O0000O0OOO00O0O ,OO00OOO0O000OO0O0 ):#line:106
        return True #line:108
    def install_plugin (O00000000000O0O0O ,O00O00O0OOO000000 ):#line:112
        O00O0O00OO0O0OOO0 =O00000000000O0O0O .get_soft_find (O00O00O0OOO000000 .sName );#line:113
        if not O00O0O00OO0O0OOO0 :return public .returnMsg (False ,'指定插件不存在!')#line:115
        if not O00000000000O0O0O .check_mutex (O00O0O00OO0O0OOO0 ['mutex']):return public .returnMsg (False ,'请先卸载[%s]'%O00O0O00OO0O0OOO0 ['mutex'])#line:116
        if not hasattr (O00O00O0OOO000000 ,'id'):#line:117
            if not O00000000000O0O0O .check_dependnet (O00O0O00OO0O0OOO0 ['dependnet']):return public .returnMsg (False ,'依赖以下软件,请先安装[%s]'%O00O0O00OO0O0OOO0 ['dependnet'])#line:118
        if 'version'in O00O00O0OOO000000 :#line:119
            for O000000O0O00OO00O in O00O0O00OO0O0OOO0 ['versions']:#line:120
                if O000000O0O00OO00O ['m_version']!=O00O00O0OOO000000 .version :continue #line:121
                if not O00000000000O0O0O .check_cpu_limit (O000000O0O00OO00O ['cpu_limit']):return public .returnMsg (False ,'至少需要[%d]个CPU核心才能安装'%O000000O0O00OO00O ['cpu_limit'])#line:122
                if not O00000000000O0O0O .check_mem_limit (O000000O0O00OO00O ['mem_limit']):return public .returnMsg (False ,'至少需要[%dMB]内存才能安装'%O000000O0O00OO00O ['mem_limit'])#line:123
                if not O00000000000O0O0O .check_os_limit (O000000O0O00OO00O ['os_limit']):return public .returnMsg (False ,'仅支持[%s]系统'%O000000O0O00OO00O ['os_limit'])#line:124
                if not hasattr (O00O00O0OOO000000 ,'id'):#line:125
                    if not O00000000000O0O0O .check_dependnet (O000000O0O00OO00O ['dependnet']):return public .returnMsg (False ,'依赖以下软件,请先安装[%s]'%O000000O0O00OO00O ['dependnet'])#line:126
        if O00O0O00OO0O0OOO0 ['type']!=5 :#line:128
            OOO0O00000OOO0OOO =O00000000000O0O0O .install_sync (O00O0O00OO0O0OOO0 ,O00O00O0OOO000000 )#line:129
        else :#line:130
            OOO0O00000OOO0OOO =O00000000000O0O0O .install_async (O00O0O00OO0O0OOO0 ,O00O00O0OOO000000 )#line:131
        return OOO0O00000OOO0OOO #line:132
    def install_sync (O000O0O0OO00O000O ,OOOO0OO0O0OO0O0O0 ,OOO0OO0OOO000O000 ):#line:135
        OO00OOO0O0000OO0O =os .getenv ('BT_PANEL')#line:136
        OO000OOOOOO00O000 =OO00OOO0O0000OO0O +'/tmp';#line:137
        if not os .path .exists (OO000OOOOOO00O000 ):os .makedirs (OO000OOOOOO00O000 )#line:138
        if not 'download_url'in session :session ['download_url']='http://download.bt.cn';#line:140
        O0000000O00O0O000 =session ['download_url']+'/win/install/plugin/'+OOOO0OO0O0OO0O0O0 ['name']+'/install.py';#line:141
        OOOO0O00O00OOO000 =OO000OOOOOO00O000 +'/'+OOOO0OO0O0OO0O0O0 ['name']+'.py'#line:142
        public .downloadFile (O0000000O00O0O000 ,OOOO0O00O00OOO000 );#line:144
        if not os .path .exists (OOOO0O00O00OOO000 ):return public .returnMsg (False ,'安装失败!');#line:145
        os .system ('python -u '+OOOO0O00O00OOO000 +' install > '+OO00OOO0O0000OO0O +'/data/panelShell.pl');#line:147
        if os .path .exists (OOOO0OO0O0OO0O0O0 ['install_checks']):#line:148
            public .WriteLog ('TYPE_SETUP','PLUGIN_INSTALL_LIB',(OOOO0OO0O0OO0O0O0 ['title'],));#line:149
            if os .path .exists (OOOO0O00O00OOO000 ):os .remove (OOOO0O00O00OOO000 )#line:150
            return public .returnMsg (True ,'PLUGIN_INSTALL_SUCCESS');#line:151
        return public .returnMsg (False ,'安装失败!');#line:152
    def install_async (OO000OO000O0O0OO0 ,OO0O0OOOOO00OO00O ,OOO0OOO0O0OOO0OOO ):#line:155
        OOOO0000O0O0O000O ='install';#line:156
        O0O0O00000OOO0OO0 ='安装';#line:157
        if hasattr (OOO0OOO0O0OOO0OOO ,'upgrade'):#line:158
            OOOO0000O0O0O000O ='update'#line:159
            O0O0O00000OOO0OO0 ='upgrade'#line:160
        OOO0OOO0O0OOO0OOO .type ='0'#line:161
        if OOO0OOO0O0OOO0OOO .sName .strip ()=='FileZilla Server':OOO0OOO0O0OOO0OOO .sName ='ftpserver'#line:162
        if OOO0OOO0O0OOO0OOO .sName .find ('php-')!=-1 :OOO0OOO0O0OOO0OOO .sName =OOO0OOO0O0OOO0OOO .sName .split ('-')[0 ]#line:163
        O000O0O0O0O00O0OO =public .GetConfigValue ('setup_path');#line:165
        O00O0O00O00O0OO00 ="cd "+O000O0O0O0O00O0OO +"/panel/install && python -u install_soft.py  "+OOOO0000O0O0O000O +" "+OOO0OOO0O0OOO0OOO .sName +" "+OOO0OOO0O0OOO0OOO .version ;#line:166
        public .M ('tasks').add ('id,name,type,status,addtime,execstr',(None ,O0O0O00000OOO0OO0 +'['+OOO0OOO0O0OOO0OOO .sName +'-'+OOO0OOO0O0OOO0OOO .version +']','execshell','0',time .strftime ('%Y-%m-%d %H:%M:%S'),O00O0O00O00O0OO00 ))#line:167
        cache .delete ('install_task')#line:168
        public .writeFile (O000O0O0O0O00O0OO +'/panel/data/panelTask.pl','True')#line:169
        public .WriteLog ('TYPE_SETUP','PLUGIN_ADD',(OOO0OOO0O0OOO0OOO .sName ,OOO0OOO0O0OOO0OOO .version ));#line:170
        return public .returnMsg (True ,'已将安装任务添加到队列!');#line:171
    def uninstall_plugin (O0OO0O0O000O00OOO ,O0O000000OO0O000O ):#line:174
        O0O000OO00O00OOOO =O0OO0O0O000O00OOO .get_soft_find (O0O000000OO0O000O .sName );#line:175
        if not O0O000OO00O00OOOO :return public .returnMsg (False ,'指定插件不存在!')#line:176
        if O0O000OO00O00OOOO ['type']!=5 :#line:177
            O00000O0O0O0OO0O0 =os .getenv ('BT_PANEL')#line:178
            O0000OO0OOOOO00O0 =O00000O0O0O0OO0O0 +'/tmp';#line:179
            O0000OO0000OO000O =O0OO0O0O000O00OOO .__O00000O0O0OO0OO0O +'/'+O0O000OO00O00OOOO ['name']#line:181
            O0O000O000OO0O0O0 =session ['download_url']+'/win/install/plugin/'+O0O000OO00O00OOOO ['name']+'/install.py'#line:182
            OOO00O0OOOO000O0O =O0000OO0OOOOO00O0 +'/'+O0O000OO00O00OOOO ['name']+'.py'#line:183
            public .downloadFile (O0O000O000OO0O0O0 ,OOO00O0OOOO000O0O )#line:184
            if not os .path .exists (OOO00O0OOOO000O0O ):return public .returnMsg (False ,'卸载失败!');#line:185
            os .system ('python -u '+OOO00O0OOOO000O0O +' uninstall > '+O00000O0O0O0OO0O0 +'/data/panelShell.pl');#line:187
            public .WriteLog ('TYPE_SETUP','PLUGIN_UNINSTALL_SOFT',(O0O000OO00O00OOOO ['title'],));#line:189
            return public .returnMsg (True ,'PLUGIN_UNINSTALL');#line:190
        else :#line:191
            O0O000000OO0O000O .type ='0'#line:192
            if O0O000000OO0O000O .sName .strip ()=='FileZilla Server':O0O000000OO0O000O .sName ='ftpserver'#line:193
            O0O000000OO0O000O .sName =O0O000000OO0O000O .sName .lower ()#line:194
            if O0O000000OO0O000O .sName .find ('php-')!=-1 :O0O000000OO0O000O .sName =O0O000000OO0O000O .sName .split ('-')[0 ]#line:195
            OO0O0O0O0O00O00O0 =public .GetConfigValue ('setup_path');#line:197
            OOO00O0O00OOOOO0O ="cd "+OO0O0O0O0O00O00O0 +"/panel/install && python -u install_soft.py  uninstall "+" "+O0O000000OO0O000O .sName .lower ()+" "+O0O000000OO0O000O .version .replace ('.','');#line:198
            os .system (OOO00O0O00OOOOO0O );#line:200
            public .WriteLog ('TYPE_SETUP','PLUGIN_UNINSTALL',(O0O000000OO0O000O .sName ,O0O000000OO0O000O .version ));#line:201
            return public .returnMsg (True ,"PLUGIN_UNINSTALL");#line:202
    def get_cloud_list (O0O000O00O00OO0O0 ,get =None ):#line:205
        OO00O0OOO0O0O0O0O ='plugin_soft_list'#line:206
        O0O0O0O00OOO0000O =None #line:207
        OO00O0O000OOOO000 =0 #line:208
        if hasattr (get ,'force'):OO00O0O000OOOO000 =int (get .force )#line:209
        if not O0O0O0O00OOO0000O or OO00O0O000OOOO000 >0 :#line:210
            OOO00OO00O000O0OO ='data/plugin.json'#line:211
            O00OO000OOOO00O0O =public .GetConfigValue ('home')+'/api/wpanel/get_soft_list_test'#line:212
            import panelAuth #line:214
            O000OO0OOO0O000OO =panelAuth .panelAuth ().create_serverid (None )#line:215
            O000OO0OOO0O000OO ['os']='Windows'#line:216
            OO00000000O0OO0O0 =public .httpPost (O00OO000OOOO00O0O ,O000OO0OOO0O000OO ,3 )#line:217
            O0O0O0O00OOO0000O =json .loads (OO00000000O0OO0O0 )#line:220
            if O0O0O0O00OOO0000O :public .writeFile (OOO00OO00O000O0OO ,json .dumps (O0O0O0O00OOO0000O ))#line:221
            cache .set (OO00O0OOO0O0O0O0O ,O0O0O0O00OOO0000O ,1800 )#line:222
        O0O0O0O00OOO0000O ['list']=O0O000O00O00OO0O0 .check_iis_version (O0O0O0O00OOO0000O ['list'])#line:224
        OOOOOOO00OO0000OO =0 #line:225
        if hasattr (get ,'type'):OOOOOOO00OO0000OO =int (get ['type'])#line:226
        O0O0O0O00OOO0000O ['list']=O0O000O00O00OO0O0 .get_types (O0O0O0O00OOO0000O ['list'],OOOOOOO00OO0000OO )#line:228
        if hasattr (get ,'query'):#line:229
            if get .query :#line:230
                O0OOO0O00O00OOO0O =[]#line:231
                for O0OOOOOOOO000O0O0 in O0O0O0O00OOO0000O ['list']:#line:232
                    if O0OOOOOOOO000O0O0 ['name'].find (get .query )!=-1 or O0OOOOOOOO000O0O0 ['title'].find (get .query )!=-1 :#line:233
                        O0OOO0O00O00OOO0O .append (O0OOOOOOOO000O0O0 )#line:234
                O0O0O0O00OOO0000O ['list']=O0OOO0O00O00OOO0O #line:235
        return O0O0O0O00OOO0000O #line:236
    def check_iis_version (OO0OOO0OOO0OO0O0O ,OOOOOOO0O00O0OOOO ):#line:239
        OO0O0OO000000O0O0 =[]#line:240
        for OOOOO0O00O00OO000 in OOOOOOO0O00O0OOOO :#line:241
            if OOOOO0O00O00OO000 ['name']=='iis':#line:242
                O00OO0O00OO00OO00 =public .get_sys_version ()#line:243
                if int (O00OO0O00OO00OO00 [0 ])==6 :#line:244
                    OOOOO0O00O00OO000 ['version']='7.5'#line:245
                    if int (O00OO0O00OO00OO00 [1 ])==2 :OOOOO0O00O00OO000 ['version']='8.5'#line:246
                elif int (O00OO0O00OO00OO00 [0 ])==10 :#line:247
                    OOOOO0O00O00OO000 ['version']='10.0'#line:248
                O000O0OOOOOOO0O0O =[]#line:249
                for OOOOO0O0OOOO0000O in OOOOO0O00O00OO000 ['versions']:#line:250
                    OOOOO0O0OOOO0000O ['m_version']=OOOOO0O00O00OO000 ['version']#line:251
                    O000O0OOOOOOO0O0O .append (OOOOO0O0OOOO0000O )#line:252
                OOOOO0O00O00OO000 ['versions']=O000O0OOOOOOO0O0O #line:253
            OO0O0OO000000O0O0 .append (OOOOO0O00O00OO000 )#line:254
        return OO0O0OO000000O0O0 #line:255
    def get_local_plugin (O0O00O0OOOO00000O ,OOO00O000O000OO00 ):#line:258
        O0O0OOOOOO0O0O0O0 =[]#line:259
        for OO00OOOOO0OOO00O0 in os .listdir ('plugin/'):#line:260
            O00OOO0O0OOOOOO0O =False #line:261
            for OOO00000O0OO00O00 in OOO00O000O000OO00 :#line:262
                if OO00OOOOO0OOO00O0 ==OOO00000O0OO00O00 ['name']:#line:263
                    O00OOO0O0OOOOOO0O =True #line:264
                    break ;#line:265
            if O00OOO0O0OOOOOO0O :continue #line:266
            OO0O0OOO000O0O0OO ='plugin/'+OO00OOOOO0OOO00O0 +'/info.json'#line:267
            if not os .path .exists (OO0O0OOO000O0O0OO ):continue #line:268
            OO0OO00OOOOO0O0O0 =json .loads (public .ReadFile (OO0O0OOO000O0O0OO ))#line:269
            O0O0O0O00O0OOOO00 =O0O00O0OOOO00000O .get_local_plugin_info (OO0OO00OOOOO0O0O0 )#line:270
            OOO00O000O000OO00 .append (O0O0O0O00O0OOOO00 )#line:271
        return OOO00O000O000OO00 #line:272
    def check_setup_task (O00O000000OO00O0O ,O0OOO000O000O0O0O ):#line:275
        if not O00O000000OO00O0O .__OOO000000OO0OOO00 :#line:276
            O00O000000OO00O0O .__OOO000000OO0OOO00 =public .M ('tasks').where ("status!=?",('1',)).field ('status,name').select ()#line:277
        if O0OOO000O000O0O0O .find ('php-')!=-1 :#line:278
            OO0000OO0O00OOOOO =O0OOO000O000O0O0O .split ('-')#line:279
            O0OOO000O000O0O0O =OO0000OO0O00OOOOO [0 ]#line:280
            O0OO0O0OO0O00O0O0 =OO0000OO0O00OOOOO [1 ]#line:281
        OO0O0O0OO00000O00 ='1';#line:282
        for OO00O0000O00O0O0O in O00O000000OO00O0O .__OOO000000OO0OOO00 :#line:283
            OOOO0OOOOO0OO0000 =public .getStrBetween ('[',']',OO00O0000O00O0O0O ['name'])#line:284
            if not OOOO0OOOOO0OO0000 :continue ;#line:285
            OOOO0OOOO0O00OOO0 =OOOO0OOOOO0OO0000 .split ('-');#line:286
            OO00OOOO00O0OOOO0 =OOOO0OOOO0O00OOO0 [0 ].lower ();#line:287
            if O0OOO000O000O0O0O =='php':#line:288
                if OO00OOOO00O0OOOO0 ==O0OOO000O000O0O0O and OOOO0OOOO0O00OOO0 [1 ]==O0OO0O0OO0O00O0O0 :OO0O0O0OO00000O00 =OO00O0000O00O0O0O ['status'];#line:289
            else :#line:290
                if OO00OOOO00O0OOOO0 =='pure':OO00OOOO00O0OOOO0 ='pure-ftpd';#line:291
                if OO00OOOO00O0OOOO0 ==O0OOO000O000O0O0O :OO0O0O0OO00000O00 =OO00O0000O00O0O0O ['status'];#line:292
        return OO0O0O0OO00000O00 #line:293
    def get_local_plugin_info (OOOO000O00O00OOOO ,O0O000O0000O0O0OO ):#line:297
        OO00000O00O0O0OOO ={"id":10000 ,"pid":0 ,"type":1000 ,"price":0 ,"name":O0O000O0000O0O0OO ['name'],"title":O0O000O0000O0O0OO ['title'],"panel_pro":1 ,"panel_free":1 ,"panel_test":1 ,"ps":O0O000O0000O0O0OO ['ps'],"version":O0O000O0000O0O0OO ['versions'],"s_version":"0","manager_version":"1","c_manager_version":"1","dependnet":"","mutex":"","install_checks":"plugin/"+O0O000O0000O0O0OO ['name'],"uninsatll_checks":"plugin/"+O0O000O0000O0O0OO ['name'],"compile_args":0 ,"version_coexist":0 ,"versions":[{"m_version":O0O000O0000O0O0OO ['versions'],"version":"0","dependnet":"","mem_limit":32 ,"cpu_limit":1 ,"os_limit":0 ,"setup":True }],"setup":True ,"status":True }#line:332
        return OO00000O00O0O0OOO #line:333
    def get_types (OOOO0OO00O0000O0O ,O0OOO00O0OOO0OOOO ,O0000O00O0OO0OO00 ):#line:336
        if O0000O00O0OO0OO00 ==0 :return O0OOO00O0OOO0OOOO #line:337
        O0O0OOO0OOO0O0O00 =[]#line:338
        for O0OO00O00O0OO00O0 in O0OOO00O0OOO0OOOO :#line:339
            if O0OO00O00O0OO00O0 ['type']==O0000O00O0OO0OO00 :O0O0OOO0OOO0O0O00 .append (O0OO00O00O0OO00O0 )#line:340
        return O0O0OOO0OOO0O0O00 #line:341
    def get_soft_list (OO0OO0O0O0O0000OO ,get =None ):#line:344
        get .force =1 #line:345
        OO0OO00O000OOO000 =OO0OO0O0O0O0000OO .get_cloud_list (get )#line:346
        if not OO0OO00O000OOO000 :#line:347
            get .force =1 #line:348
            OO0OO00O000OOO000 =OO0OO0O0O0O0000OO .get_cloud_list (get )#line:349
            if not OO0OO00O000OOO000 :return public .returnMsg (False ,'软件列表获取失败(401)!')#line:350
        OO0OO00O000OOO000 ['list']=OO0OO0O0O0O0000OO .set_soft_path (OO0OO00O000OOO000 ['list'])#line:352
        OO0OO00O000OOO000 ['list']=OO0OO0O0O0O0000OO .set_coexist (OO0OO00O000OOO000 ['list'])#line:353
        OO0OO00O000OOO000 ['list']=OO0OO0O0O0O0000OO .get_page (OO0OO00O000OOO000 ['list'],get )#line:354
        OO0OO00O000OOO000 ['list']['data']=OO0OO0O0O0O0000OO .check_isinstall (OO0OO00O000OOO000 ['list']['data'])#line:355
        return OO0OO00O000OOO000 #line:357
    def get_index_list (O0O0OO00OO0OOOO00 ,get =None ):#line:360
        O0OOO0OOOO000O000 =O0O0OO00OO0OOOO00 .get_cloud_list (get )['list']#line:361
        if not O0OOO0OOOO000O000 :#line:362
            get .force =1 #line:363
            O0OOO0OOOO000O000 =O0O0OO00OO0OOOO00 .get_cloud_list (get )#line:364
            if not O0OOO0OOOO000O000 :return public .returnMsg (False ,'软件列表获取失败(401)!')#line:365
        O0OOO0OOOO000O000 =O0O0OO00OO0OOOO00 .set_soft_path (O0OOO0OOOO000O000 )#line:366
        O0OOO0OOOO000O000 =O0O0OO00OO0OOOO00 .set_coexist (O0OOO0OOOO000O000 )#line:367
        O0O0OOOO0O00O0O0O =json .loads (public .ReadFile (O0O0OO00OO0OOOO00 .__O00O000000O0000OO ))#line:368
        O0OOO0OOO0OOO00O0 =[]#line:369
        for O0OO00O00OO0O0OO0 in O0O0OOOO0O00O0O0O :#line:370
            for OOO0OO000O0OO0O0O in O0OOO0OOOO000O000 :#line:371
                if OOO0OO000O0OO0O0O ['name']==O0OO00O00OO0O0OO0 :O0OOO0OOO0OOO00O0 .append (OOO0OO000O0OO0O0O )#line:372
        O0OOO0OOO0OOO00O0 =O0O0OO00OO0OOOO00 .check_isinstall (O0OOO0OOO0OOO00O0 )#line:373
        return O0OOO0OOO0OOO00O0 #line:374
    def add_index (O00O0O0O0OO0OO000 ,O0OOOO0OOO000OOO0 ):#line:377
        O00OOOOO0O000000O =O0OOOO0OOO000OOO0 .sName #line:378
        OOO000O0O0OOOO000 =json .loads (public .ReadFile (O00O0O0O0OO0OO000 .__O00O000000O0000OO ))#line:379
        if O00OOOOO0O000000O in OOO000O0O0OOOO000 :return public .returnMsg (False ,'请不要重复添加!')#line:380
        if len (OOO000O0O0OOOO000 )>=12 :return public .returnMsg (False ,'首页最多只能显示12个软件!')#line:381
        OOO000O0O0OOOO000 .append (O00OOOOO0O000000O )#line:382
        public .writeFile (O00O0O0O0OO0OO000 .__O00O000000O0000OO ,json .dumps (OOO000O0O0OOOO000 ))#line:383
        return public .returnMsg (True ,'添加成功!')#line:384
    def remove_index (O00O0000OO0OO00OO ,O0000O0O0O0OO00O0 ):#line:387
        O0OO00O0O0OOOOO0O =O0000O0O0O0OO00O0 .sName #line:388
        O00OOOO0O000OO0OO =[]#line:389
        O00OOOO0O000OO0OO =json .loads (public .ReadFile (O00O0000OO0OO00OO .__O00O000000O0000OO ))#line:390
        if not O0OO00O0O0OOOOO0O in O00OOOO0O000OO0OO :return public .returnMsg (True ,'删除成功!')#line:391
        O00OOOO0O000OO0OO .remove (O0OO00O0O0OOOOO0O )#line:392
        public .writeFile (O00O0000OO0OO00OO .__O00O000000O0000OO ,json .dumps (O00OOOO0O000OO0OO ))#line:393
        return public .returnMsg (True ,'删除成功!')#line:394
    def sort_index (OO00OO000O000O0O0 ,OOO0000OOOO000OOO ):#line:397
        O00OO0O00O0OO0000 =OOO0000OOOO000OOO .ssort .split ('|')#line:398
        public .writeFile (OO00OO000O000O0O0 .__O00O000000O0000OO ,json .dumps (O00OO0O00O0OO0000 ))#line:399
        return public .returnMsg (True ,'设置成功!')#line:400
    def get_link_list (OO00OOOOO0O0OOO00 ,get =None ):#line:403
        OOOO0O0OO0OO00OO0 =OO00OOOOO0O0OOO00 .get_cloud_list (get )['list']#line:404
        OOOO0O0OO0OO00OO0 =OO00OOOOO0O0OOO00 .set_soft_path (OOOO0O0OO0OO00OO0 )#line:405
        OOOO0O0OO0OO00OO0 =OO00OOOOO0O0OOO00 .set_coexist (OOOO0O0OO0OO00OO0 )#line:406
        O0OO00OOO0OOOOOO0 =json .loads (public .ReadFile (OO00OOOOO0O0OOO00 .__OO0OO0O00O0O000O0 ))#line:407
        OO0O0O00OOO00OO0O =[]#line:408
        for OOO0OO000OO000OO0 in O0OO00OOO0OOOOOO0 :#line:409
            for OO00O0000O0O0000O in OOOO0O0OO0OO00OO0 :#line:410
                if OO00O0000O0O0000O ['name']==OOO0OO000OO000OO0 :OO0O0O00OOO00OO0O .append (OO00O0000O0O0000O )#line:411
        OO0O0O00OOO00OO0O =OO00OOOOO0O0OOO00 .check_isinstall (OO0O0O00OOO00OO0O )#line:412
        return OO0O0O00OOO00OO0O #line:413
    def add_link (OOOO0O00OOOO00O00 ,O000O0O0OO0O0OO00 ):#line:416
        OO0OOO0000000O00O =O000O0O0OO0O0OO00 .sName #line:417
        OO0O00O0OO00O0O00 =json .loads (public .ReadFile (OOOO0O00OOOO00O00 .__OO0OO0O00O0O000O0 ))#line:418
        if OO0OOO0000000O00O in OO0O00O0OO00O0O00 :return public .returnMsg (False ,'请不要重复添加!')#line:419
        if len (OO0O00O0OO00O0O00 )>=5 :return public .returnMsg (False ,'快捷栏最多只能显示5个软件!')#line:420
        OO0O00O0OO00O0O00 .append (OO0OOO0000000O00O )#line:421
        public .writeFile (OOOO0O00OOOO00O00 .__OO0OO0O00O0O000O0 ,json .dumps (OO0O00O0OO00O0O00 ))#line:422
        return public .returnMsg (True ,'添加成功!')#line:423
    def remove_link (O0OOOO0OOOOOOOOO0 ,O00O0OO0OO00O0000 ):#line:426
        O0OOO0OO00000O000 =O00O0OO0OO00O0000 .sName #line:427
        OOO0OOO000O000OOO =[]#line:428
        OOO0OOO000O000OOO =json .loads (public .ReadFile (O0OOOO0OOOOOOOOO0 .__OO0OO0O00O0O000O0 ))#line:429
        if O0OOO0OO00000O000 in OOO0OOO000O000OOO :return public .returnMsg (True ,'删除成功!')#line:430
        OOO0OOO000O000OOO .remove (O0OOO0OO00000O000 )#line:431
        public .writeFile (O0OOOO0OOOOOOOOO0 .__OO0OO0O00O0O000O0 ,json .dumps (OOO0OOO000O000OOO ))#line:432
        return public .returnMsg (True ,'删除成功!')#line:433
    def sort_link (OO00OOOO0OO0OO00O ,O0O00OOOO00O0OOOO ):#line:436
        O0O000O00000OO0OO =O0O00OOOO00O0OOOO .ssort .split ('|')#line:437
        public .writeFile (OO00OOOO0OO0OO00O .__OO0OO0O00O0O000O0 ,json .dumps (O0O000O00000OO0OO ))#line:438
        return public .returnMsg (True ,'设置成功!')#line:439
    def set_coexist (O0O0O0OO0O000O0OO ,O00O0O0OO0O00000O ):#line:444
        OOOO000O0O000O0OO =[]#line:445
        for O00OO0O0OO00000O0 in O00O0O0OO0O00000O :#line:446
            if O00OO0O0OO00000O0 ['version_coexist']==1 :#line:447
                for OOOO0O0OOOO0OOOO0 in O00OO0O0OO00000O0 ['versions']:#line:448
                    O000O0OO00OOOOO0O =O00OO0O0OO00000O0 .copy ()#line:449
                    O0O000OO00OOOO0OO =OOOO0O0OOOO0OOOO0 ['m_version'].replace ('.','')#line:450
                    O000O0OO00OOOOO0O ['title']=O000O0OO00OOOOO0O ['title']+'-'+OOOO0O0OOOO0OOOO0 ['m_version']#line:451
                    O000O0OO00OOOOO0O ['name']=O000O0OO00OOOOO0O ['name']+'-'+OOOO0O0OOOO0OOOO0 ['m_version']#line:452
                    O000O0OO00OOOOO0O ['version']=O000O0OO00OOOOO0O ['version'].replace ('{VERSION}',O0O000OO00OOOO0OO )#line:453
                    O000O0OO00OOOOO0O ['manager_version']=O000O0OO00OOOOO0O ['manager_version'].replace ('{VERSION}',O0O000OO00OOOO0OO )#line:454
                    O000O0OO00OOOOO0O ['install_checks']=O000O0OO00OOOOO0O ['install_checks'].replace ('{VERSION}',O0O000OO00OOOO0OO )#line:455
                    O000O0OO00OOOOO0O ['uninsatll_checks']=O000O0OO00OOOOO0O ['uninsatll_checks'].replace ('{VERSION}',O0O000OO00OOOO0OO )#line:456
                    O000O0OO00OOOOO0O ['s_version']=O000O0OO00OOOOO0O ['s_version'].replace ('{VERSION}',O0O000OO00OOOO0OO )#line:457
                    O000O0OO00OOOOO0O ['versions']=[]#line:458
                    O000O0OO00OOOOO0O ['versions'].append (OOOO0O0OOOO0OOOO0 )#line:459
                    OOOO000O0O000O0OO .append (O000O0OO00OOOOO0O )#line:460
            else :#line:461
                OOOO000O0O000O0OO .append (O00OO0O0OO00000O0 )#line:462
        return OOOO000O0O000O0OO #line:463
    def check_isinstall (O00OO0000O0O00OO0 ,OO0OOO0O00OO000OO ):#line:466
        O00O0OOOO00OOO0O0 =json .loads (public .ReadFile (O00OO0000O0O00OO0 .__O00O000000O0000OO ))#line:467
        for OOO0OOO0OOOOO0O0O in range (len (OO0OOO0O00OO000OO )):#line:468
            OO0OOO0O00OO000OO [OOO0OOO0OOOOO0O0O ]['index_display']=OO0OOO0O00OO000OO [OOO0OOO0OOOOO0O0O ]['name']in O00O0OOOO00OOO0O0 #line:469
            OO0OOO0O00OO000OO [OOO0OOO0OOOOO0O0O ]=O00OO0000O0O00OO0 .check_status (OO0OOO0O00OO000OO [OOO0OOO0OOOOO0O0O ])#line:470
        return OO0OOO0O00OO000OO #line:471
    def check_status (OO000000O000O0000 ,O0000000OOOO0O0O0 ):#line:474
        O0000000OOOO0O0O0 ['setup']=False #line:476
        O0000000OOOO0O0O0 ['status']=False #line:477
        if O0000000OOOO0O0O0 ['install_checks']:#line:478
            OOO00000O00OO00OO =O0000000OOOO0O0O0 ['install_checks'].split ('|')#line:479
            if OOO00000O00OO00OO [0 ]=='server'and len (OOO00000O00OO00OO )>1 :#line:480
                O0OO0OOO0000O0OOO =public .get_server_status (OOO00000O00OO00OO [1 ])#line:481
                if O0OO0OOO0000O0OOO >-1 :#line:482
                    O0000000OOOO0O0O0 ['setup']=True #line:483
                    if O0OO0OOO0000O0OOO >0 :#line:484
                        O0000000OOOO0O0O0 ['status']=True #line:485
                if O0000000OOOO0O0O0 ['name']=='iis':#line:486
                    O0000000OOOO0O0O0 ['status']=False #line:487
                    O0000000OOOO0O0O0 ['setup']=False #line:488
                    if os .path .exists ('data/iis.setup'):#line:489
                        O0000000OOOO0O0O0 ['setup']=True #line:490
                        O0000000OOOO0O0O0 ['status']=True #line:491
            else :#line:492
                if os .path .exists (O0000000OOOO0O0O0 ['install_checks']):#line:493
                    O0000000OOOO0O0O0 ['setup']=True #line:494
                    O0000000OOOO0O0O0 ['status']=True #line:495
        O0000000OOOO0O0O0 ['task']=OO000000O000O0000 .check_setup_task (O0000000OOOO0O0O0 ['name'])#line:497
        if O0000000OOOO0O0O0 ['setup']:#line:498
            O0000000OOOO0O0O0 ['shell']=O0000000OOOO0O0O0 ['version']#line:499
            O0000000OOOO0O0O0 ['version']=OO000000O000O0000 .get_version_info (O0000000OOOO0O0O0 )#line:500
            O0000000OOOO0O0O0 ['versions']=OO000000O000O0000 .tips_version (O0000000OOOO0O0O0 ['versions'],O0000000OOOO0O0O0 ['version'])#line:501
            O0000000OOOO0O0O0 ['admin']=os .path .exists (OO000000O000O0000 .__O00000OOO0OO000OO +'/panel/plugin/'+O0000000OOOO0O0O0 ['name'])#line:502
        else :#line:504
            O0000000OOOO0O0O0 ['version']=""#line:505
        if O0000000OOOO0O0O0 ['version_coexist']==1 :#line:506
            OO000000O000O0000 .get_icon (O0000000OOOO0O0O0 ['name'].split ('-')[0 ])#line:507
        else :#line:508
            OO000000O000O0000 .get_icon (O0000000OOOO0O0O0 ['name'])#line:509
        return O0000000OOOO0O0O0 #line:511
    def set_soft_path (O00O00O0O000OO0OO ,O00O0O0O0OO000O00 ):#line:513
        OOO00O000OO000000 =[]#line:514
        OOO0O0O000000OO00 =['version','install_checks','uninsatll_checks','ps']#line:515
        O00OOOOO0000OOO0O =public .GetConfigValue ('setup_path')#line:516
        for OOOO0O00OO00OO0OO in O00O0O0O0OO000O00 :#line:517
            for OO0O00OOOOO0OOO0O in OOO0O0O000000OO00 :#line:518
                OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ]=OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ].replace ('{SETUP_PATH}',O00OOOOO0000OOO0O )#line:519
                if OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ].find ('{SERVER_PATH}')>-1 or OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ].find ('{MYSQL_VERSION}')>-1 :#line:520
                    if public .get_server_status (OOOO0O00OO00OO0OO ['name'])>=0 :#line:521
                        OOO0000OO00OO0O00 =public .get_server_path (OOOO0O00OO00OO0OO ['name'])#line:522
                        OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ]=OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ].replace ('{SERVER_PATH}',OOO0000OO00OO0O00 )#line:523
                        try :#line:524
                            if OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ].find ('{MYSQL_VERSION}')>-1 :#line:525
                                O000O00O0OOO00000 =re .search ('([MySQL|MariaDB-]+\d+\.\d+)',OOO0000OO00OO0O00 ).groups ()[0 ]#line:526
                                OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ]=OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ].replace ('{MYSQL_VERSION}',O000O00O0OOO00000 )#line:527
                        except :#line:528
                            OOOO0O00OO00OO0OO [OO0O00OOOOO0OOO0O ]=u'未知版本,请通过宝塔安装此功能'#line:529
            OOO00O000OO000000 .append (OOOO0O00OO00OO0OO )#line:531
        return OOO00O000OO000000 #line:532
    def get_soft_find (OOO00000000000O00 ,get =None ):#line:535
        OO0OOO0000OO0O00O =OOO00000000000O00 .get_cloud_list (get )['list']#line:536
        OO0OOO0000OO0O00O =OOO00000000000O00 .set_soft_path (OO0OOO0000OO0O00O )#line:537
        OO0OOO0000OO0O00O =OOO00000000000O00 .set_coexist (OO0OOO0000OO0O00O )#line:538
        if type (get )!=str :#line:539
            O0OOO000O00OOO0OO =get ['sName']#line:540
        else :#line:541
            O0OOO000O00OOO0OO =get #line:542
        for O000000O00O0O00O0 in OO0OOO0000OO0O00O :#line:543
            if O000000O00O0O00O0 ['name']==O0OOO000O00OOO0OO :#line:544
                if O0OOO000O00OOO0OO =='phpmyadmin':#line:545
                    O000000O00O0O00O0 ['ext']=OOO00000000000O00 .getPHPMyAdminStatus ()#line:546
                return OOO00000000000O00 .check_status (O000000O00O0O00O0 )#line:547
        return False #line:548
    def get_soft_version (O0OOO00OO00OOOOO0 ,OOOO0OOO00000O0OO ):#line:550
            O0000000OO00O000O =''#line:551
            try :#line:552
                if OOOO0OOO00000O0OO ['version']:#line:553
                    OOOOOO0OO000O000O =OOOO0OOO00000O0OO ['version'].split ('|')#line:554
                if len (OOOOOO0OO000O000O )>1 :#line:555
                    O0000000OO00O000O =re .search (OOOOOO0OO000O000O [1 ],public .ExecShell (OOOOOO0OO000O000O [0 ])[0 ]).groups ()[0 ]#line:556
            except :pass #line:557
            return O0000000OO00O000O #line:558
    def get_version_info (OO00O0OOOO0OO0O0O ,OOO0OO000OO0O00O0 ):#line:561
        OO0O0O00OO000OO00 =''#line:562
        O0OO000000O0OO000 =OOO0OO000OO0O00O0 ['uninsatll_checks']+'/version.pl'#line:563
        O000000O0OOO0000O =OOO0OO000OO0O00O0 ['uninsatll_checks']+'/info.json'#line:564
        if OOO0OO000OO0O00O0 ['name']=='mysql':#line:565
            print (O0OO000000O0OO000 )#line:566
        if os .path .exists (O0OO000000O0OO000 ):#line:567
            OO0O0O00OO000OO00 =public .ReadFile (O0OO000000O0OO000 ).strip ()#line:568
        elif os .path .exists (O000000O0OOO0000O ):#line:569
            OO0O0O00OO000OO00 =json .loads (public .ReadFile (O000000O0OOO0000O ))['versions']#line:570
        else :#line:571
            OO0O0O00OO000OO00 =OO00O0OOOO0OO0O0O .get_soft_version (OOO0OO000OO0O00O0 )#line:572
            public .writeFile (O0OO000000O0OO000 ,OO0O0O00OO000OO00 )#line:573
        if OOO0OO000OO0O00O0 ['name']=='iis':#line:574
            OO0O0O00OO000OO00 =public .ReadReg ('SOFTWARE\\Microsoft\\InetStp','SetupString')#line:575
            if OO0O0O00OO000OO00 :OO0O0O00OO000OO00 =re .search ('(\d+\.\d+)',OO0O0O00OO000OO00 ).groups ()[0 ]#line:576
        return OO0O0O00OO000OO00 #line:577
    def tips_version (O0000O0O0OOO0O000 ,OO0O000O0OO00O000 ,O0000OOOOOO000OOO ):#line:581
        if len (OO0O000O0OO00O000 )==1 :#line:582
            OO0O000O0OO00O000 [0 ]['setup']=True ;#line:583
            return OO0O000O0OO00O000 #line:584
        for OO00OOO00O0OO0O0O in range (len (OO0O000O0OO00O000 )):#line:586
            if O0000OOOOOO000OOO ==(OO0O000O0OO00O000 [OO00OOO00O0OO0O0O ]['m_version']+'.'+OO0O000O0OO00O000 [OO00OOO00O0OO0O0O ]['version']):#line:588
                OO0O000O0OO00O000 [OO00OOO00O0OO0O0O ]['setup']=True #line:589
                continue ;#line:590
            OOOOOO00OO0O0OO0O =OO0O000O0OO00O000 [OO00OOO00O0OO0O0O ]['m_version'].split ('_')#line:591
            if len (OOOOOO00OO0O0OO0O )>1 :#line:592
                OOOOOO00OO0O0OO0O =OOOOOO00OO0O0OO0O [1 ]#line:593
            else :#line:594
                OOOOOO00OO0O0OO0O =OOOOOO00OO0O0OO0O [0 ]#line:595
            OO00O00000O0O0OO0 =len (OOOOOO00OO0O0OO0O )#line:596
            OO0O000O0OO00O000 [OO00OOO00O0OO0O0O ]['setup']=(O0000OOOOOO000OOO [:OO00O00000O0O0OO0 ]==OOOOOO00OO0O0OO0O )#line:597
        return OO0O000O0OO00O000 #line:598
    def process_exists (OOO0OOOO000OO0O00 ,O00O00OOO0OOOOO00 ,exe =None ):#line:603
        try :#line:604
            if not OOO0OOOO000OO0O00 .pids :OOO0OOOO000OO0O00 .pids =psutil .pids ()#line:605
            for OO000OOOO00000000 in OOO0OOOO000OO0O00 .pids :#line:606
                try :#line:607
                    O00000000O0000O00 =psutil .Process (OO000OOOO00000000 )#line:608
                    if O00000000O0000O00 .name ()==O00O00OOO0OOOOO00 :#line:609
                        if not exe :#line:610
                            return True ;#line:611
                        else :#line:612
                            if O00000000O0000O00 .exe ()==exe :return True #line:613
                except :pass #line:614
            return False #line:615
        except :return True #line:616
    def get_page (OOO000O0O0O0000OO ,O0O000O00000O000O ,O0OOOO00OO0O00O00 ):#line:619
        import page #line:621
        page =page .Page ();#line:623
        OO0OOOO00OOO000O0 ={}#line:624
        OO0OOOO00OOO000O0 ['count']=len (O0O000O00000O000O )#line:625
        OO0OOOO00OOO000O0 ['row']=OOO000O0O0O0000OO .ROWS ;#line:626
        OO0OOOO00OOO000O0 ['p']=1 #line:627
        if hasattr (O0OOOO00OO0O00O00 ,'p'):#line:628
            OO0OOOO00OOO000O0 ['p']=int (O0OOOO00OO0O00O00 ['p'])#line:629
        OO0OOOO00OOO000O0 ['uri']={}#line:630
        OO0OOOO00OOO000O0 ['return_js']=''#line:631
        if hasattr (O0OOOO00OO0O00O00 ,'tojs'):#line:632
            OO0OOOO00OOO000O0 ['return_js']=O0OOOO00OO0O00O00 .tojs #line:633
        O00000OO0OOOO0OO0 ={}#line:636
        O00000OO0OOOO0OO0 ['page']=page .GetPage (OO0OOOO00OOO000O0 )#line:637
        O000O0OOOO00O00O0 =0 ;#line:638
        O00000OO0OOOO0OO0 ['data']=[];#line:639
        for O00000O0OOO0OOOOO in range (OO0OOOO00OOO000O0 ['count']):#line:640
            if O000O0OOOO00O00O0 >page .ROW :break ;#line:641
            if O00000O0OOO0OOOOO <page .SHIFT :continue ;#line:642
            O000O0OOOO00O00O0 +=1 ;#line:643
            O00000OO0OOOO0OO0 ['data'].append (O0O000O00000O000O [O00000O0OOO0OOOOO ]);#line:644
        return O00000OO0OOOO0OO0 ;#line:645
    def GetList (O0OO0OO0O0OOO00OO ,get =None ):#line:649
        try :#line:650
            if not os .path .exists (O0OO0OO0O0OOO00OO .__O0O000O0OO00000OO ):return [];#line:651
            OOO0000O00O00O0O0 =json .loads (public .readFile (O0OO0OO0O0OOO00OO .__O0O000O0OO00000OO ));#line:652
            OOO0000O00O00O0O0 =sorted (OOO0000O00O00O0O0 ,key =lambda OOOO0OOO00OO00O0O :OOOO0OOO00OO00O0O ['sort'],reverse =False );#line:655
            OOO0O0OOOOOOO0O0O =0 ;#line:658
            for O00O00OOOO0OO00OO in os .listdir (O0OO0OO0O0OOO00OO .__O00000O0O0OO0OO0O ):#line:659
                OO0O0OO0O0O0O0OO0 =True #line:660
                for O0000O00OO000OOO0 in OOO0000O00O00O0O0 :#line:661
                    if O0000O00OO000OOO0 ['name']==O00O00OOOO0OO00OO :OO0O0OO0O0O0O0OO0 =False #line:662
                if not OO0O0OO0O0O0O0OO0 :continue ;#line:663
                OOOOOOO0OOO0OOO0O =O0OO0OO0O0OOO00OO .__O00000O0O0OO0OO0O +'/'+O00O00OOOO0OO00OO #line:665
                if os .path .isdir (OOOOOOO0OOO0OOO0O ):#line:666
                    O0O0OOO00O0O0O000 =OOOOOOO0OOO0OOO0O +'/info.json'#line:667
                    if os .path .exists (O0O0OOO00O0O0O000 ):#line:668
                        try :#line:669
                            O0O00OO0O0OOO0000 =json .loads (public .readFile (O0O0OOO00O0O0O000 ))#line:670
                            if not hasattr (get ,'type'):#line:671
                                get .type =0 ;#line:672
                            else :#line:673
                                get .type =int (get .type )#line:674
                            if get .type >0 :#line:676
                                try :#line:677
                                    if get .type !=O0O00OO0O0OOO0000 ['id']:continue ;#line:678
                                except :#line:679
                                    continue ;#line:680
                            O0O00OO0O0OOO0000 ['pid']=len (OOO0000O00O00O0O0 )+1000 +OOO0O0OOOOOOO0O0O #line:682
                            O0O00OO0O0OOO0000 ['status']=O0O00OO0O0OOO0000 ['display'];#line:683
                            O0O00OO0O0OOO0000 ['display']=0 ;#line:684
                            OOO0000O00O00O0O0 .append (O0O00OO0O0OOO0000 )#line:685
                        except :#line:686
                            pass #line:687
            if get :#line:689
                O000O00OO00OO0O00 =None #line:690
                if hasattr (get ,'display'):O000O00OO00OO0O00 =True ;#line:691
                if not hasattr (get ,'type'):#line:692
                    get .type =0 ;#line:693
                else :#line:694
                    get .type =int (get .type )#line:695
                if not hasattr (get ,'search'):#line:696
                    O000OOO0O0O0OO0O0 =None #line:697
                    OOOO0000O0OO0OO00 =0 #line:698
                else :#line:699
                    O000OOO0O0O0OO0O0 =get .search .encode ('utf-8').lower ();#line:700
                    OOOO0000O0OO0OO00 =1 #line:701
                O0O00OO0O0OOO0000 =[];#line:703
                for OOOO0O0O0O0OO0000 in OOO0000O00O00O0O0 :#line:704
                    O0OO0OO0O0OOO00OO .get_icon (OOOO0O0O0O0OO0000 ['name']);#line:705
                    if O000O00OO00OO0O00 :#line:706
                        if OOOO0O0O0O0OO0000 ['display']==0 :continue ;#line:707
                    OO00O0OO0OOO00OO0 =0 ;#line:708
                    if get .type >0 :#line:709
                        if get .type ==OOOO0O0O0O0OO0000 ['id']:OO00O0OO0OOO00OO0 +=1 #line:710
                    else :#line:711
                        OO00O0OO0OOO00OO0 +=1 #line:712
                    if O000OOO0O0O0OO0O0 :#line:713
                        if OOOO0O0O0O0OO0000 ['name'].lower ().find (O000OOO0O0O0OO0O0 )!=-1 :OO00O0OO0OOO00OO0 +=1 ;#line:714
                        if OOOO0O0O0O0OO0000 ['name'].find (O000OOO0O0O0OO0O0 )!=-1 :OO00O0OO0OOO00OO0 +=1 ;#line:715
                        if OOOO0O0O0O0OO0000 ['title'].lower ().find (O000OOO0O0O0OO0O0 )!=-1 :OO00O0OO0OOO00OO0 +=1 ;#line:716
                        if OOOO0O0O0O0OO0000 ['title'].find (O000OOO0O0O0OO0O0 )!=-1 :OO00O0OO0OOO00OO0 +=1 ;#line:717
                        if get .type >0 and get .type !=OOOO0O0O0O0OO0000 ['type']:OO00O0OO0OOO00OO0 -=1 ;#line:718
                    if OO00O0OO0OOO00OO0 >OOOO0000O0OO0OO00 :O0O00OO0O0OOO0000 .append (OOOO0O0O0O0OO0000 );#line:719
                OOO0000O00O00O0O0 =O0O00OO0O0OOO0000 ;#line:720
            return OOO0000O00O00O0O0 #line:721
        except Exception as O0O00O0O0OOO0O000 :#line:722
            return str (O0O00O0O0OOO0O000 );#line:723
    def get_icon (OO0O0O000OO0O0O0O ,O000O0OO0O0O00OO0 ):#line:727
        O0O0O0OO0OOOO0OOO ='BTPanel/static/img/soft_ico/ico-'+O000O0OO0O0O00OO0 +'.png'#line:728
        if not os .path .exists (O0O0O0OO0OOOO0OOO ):#line:729
            OO0O0O000OO0O0O0O .download_icon (O000O0OO0O0O00OO0 ,O0O0O0OO0OOOO0OOO )#line:730
        else :#line:731
            O0O00000O000000OO =os .path .getsize (O0O0O0OO0OOOO0OOO )#line:732
            if O0O00000O000000OO ==0 :OO0O0O000OO0O0O0O .download_icon (O000O0OO0O0O00OO0 ,O0O0O0OO0OOOO0OOO )#line:733
    def download_icon (OOO0O0OOOOO000000 ,OOO0OOO0O0OOO0OO0 ,OOO00O0O00OO00OO0 ):#line:736
        try :#line:737
            O00O000O00O000O0O =OOO0O0OOOOO000000 .__O00000O0O0OO0OO0O +'/'+OOO0OOO0O0OOO0OO0 +'/icon.png';#line:738
            if os .path .exists (O00O000O00O000O0O ):#line:739
                shutil .copyfile (O00O000O00O000O0O ,OOO00O0O00OO00OO0 )#line:740
            else :#line:741
                public .downloadFile (public .get_url ()+'/win/install/plugin/'+OOO0OOO0O0OOO0OO0 +'/icon.png',OOO00O0O00OO00OO0 )#line:742
        except :#line:743
            pass #line:744
    def GetPage (OOOO0O00O00O0O0OO ,O000OO0O00000OO00 ,OOOOO0O0OOOOOO000 ):#line:748
        import page #line:750
        page =page .Page ();#line:752
        O0OO00O0O00000O0O ={}#line:753
        O0OO00O0O00000O0O ['count']=len (O000OO0O00000OO00 )#line:754
        O0OO00O0O00000O0O ['row']=OOOO0O00O00O0O0OO .ROWS ;#line:755
        O0OO00O0O00000O0O ['p']=1 #line:756
        if hasattr (OOOOO0O0OOOOOO000 ,'p'):#line:757
            O0OO00O0O00000O0O ['p']=int (OOOOO0O0OOOOOO000 ['p'])#line:758
        O0OO00O0O00000O0O ['uri']={}#line:759
        O0OO00O0O00000O0O ['return_js']=''#line:760
        if hasattr (OOOOO0O0OOOOOO000 ,'tojs'):#line:761
            O0OO00O0O00000O0O ['return_js']=OOOOO0O0OOOOOO000 .tojs #line:762
        OOOO0000OO00OOOOO ={}#line:765
        OOOO0000OO00OOOOO ['page']=page .GetPage (O0OO00O0O00000O0O )#line:766
        OO00O00OOOO00O00O =0 ;#line:767
        OOOO0000OO00OOOOO ['data']=[];#line:768
        for O000OO000O0OO00O0 in range (O0OO00O0O00000O0O ['count']):#line:769
            if OO00O00OOOO00O00O >page .ROW :break ;#line:770
            if O000OO000O0OO00O0 <page .SHIFT :continue ;#line:771
            OO00O00OOOO00O00O +=1 ;#line:772
            OOOO0000OO00OOOOO ['data'].append (O000OO0O00000OO00 [O000OO000O0OO00O0 ]);#line:773
        return OOOO0000OO00OOOOO ;#line:774
    def GetType (OOOOOOOOOOO0OO00O ,get =None ):#line:777
        try :#line:778
            if not os .path .exists (OOOOOOOOOOO0OO00O .__O0OO0O00OO00OO00O ):return False ;#line:779
            O00O0000O0O0OO0OO =json .loads (public .readFile (OOOOOOOOOOO0OO00O .__O0OO0O00OO00OO00O ));#line:780
            return O00O0000O0O0OO0OO #line:781
        except :#line:782
            return False ;#line:783
    def GetFind (O0OO000000OOOOOOO ,OOOO000OOO0OO000O ):#line:786
        try :#line:787
            O00O00OOOOOOO0000 =O0OO000000OOOOOOO .GetList (None );#line:788
            for OO0OOO0OOO0OOOOO0 in O00O00OOOOOOO0000 :#line:789
                if OO0OOO0OOO0OOOOO0 ['name']==OOOO000OOO0OO000O :return OO0OOO0OOO0OOOOO0 ;#line:790
            return None #line:791
        except :#line:792
            return None ;#line:793
    def SetField (O00O0O0OO0000O0O0 ,O00000OOOO00OO00O ,OOOOOO00OO0000OOO ,OOO0000000OOOOOOO ):#line:796
        OO00O0OOO0OO0OO00 =O00O0O0OO0000O0O0 .GetList (None );#line:797
        for O0OOO0O0OOO0OO00O in range (len (OO00O0OOO0OO0OO00 )):#line:798
            if OO00O0OOO0OO0OO00 [O0OOO0O0OOO0OO00O ]['name']!=O00000OOOO00OO00O :continue ;#line:799
            OO00O0OOO0OO0OO00 [O0OOO0O0OOO0OO00O ][OOOOOO00OO0000OOO ]=OOO0000000OOOOOOO ;#line:800
        public .writeFile (O00O0O0OO0000O0O0 .__O0O000O0OO00000OO ,json .dumps (OO00O0OOO0OO0OO00 ));#line:802
        return True ;#line:803
    def install (OO00O000OO00OO000 ,O0O00O00000O000OO ):#line:808
        O000000000O00OO00 =OO00O000OO00OO000 .GetFind (O0O00O00000O000OO .name );#line:809
        if not O000000000O00OO00 :#line:810
            import json #line:811
            O000000000O00OO00 =json .loads (public .readFile (OO00O000OO00OO000 .__O00000O0O0OO0OO0O +'/'+O0O00O00000O000OO .name +'/info.json'));#line:812
        if O000000000O00OO00 ['tip']=='lib':#line:814
            if not os .path .exists (OO00O000OO00OO000 .__O00000O0O0OO0OO0O +'/'+O000000000O00OO00 ['name']):os .system ('mkdir -p '+OO00O000OO00OO000 .__O00000O0O0OO0OO0O +'/'+O000000000O00OO00 ['name']);#line:815
            if not 'download_url'in session :session ['download_url']='http://download.bt.cn';#line:816
            OOO0O00OO0OOOO00O =session ['download_url']+'/install/plugin/'+O000000000O00OO00 ['name']+'/install.sh';#line:817
            OOO00OO0OO0OO0O0O =OO00O000OO00OO000 .__O00000O0O0OO0OO0O +'/'+O000000000O00OO00 ['name']+'/install.sh';#line:818
            public .downloadFile (OOO0O00OO0OOOO00O ,OOO00OO0OO0OO0O0O );#line:819
            os .system ('/bin/bash '+OOO00OO0OO0OO0O0O +' install');#line:820
            if OO00O000OO00OO000 .checksSetup (O000000000O00OO00 ['name'],O000000000O00OO00 ['checks'],O000000000O00OO00 ['versions'])[0 ]['status']or os .path .exists (OO00O000OO00OO000 .__O00000O0O0OO0OO0O +'/'+O0O00O00000O000OO .name ):#line:821
                public .WriteLog ('TYPE_SETUP','PLUGIN_INSTALL_LIB',(O000000000O00OO00 ['title'],));#line:822
                return public .returnMsg (True ,'PLUGIN_INSTALL_SUCCESS');#line:824
            return public .returnMsg (False ,'PLUGIN_INSTALL_ERR');#line:825
        else :#line:826
            import db ,time #line:827
            OO0O0O0OO0OO0000O ='/www/server/php'#line:828
            if not os .path .exists (OO0O0O0OO0OO0000O ):os .system ("mkdir -p "+OO0O0O0OO0OO0000O );#line:829
            OO00O00OOO0OOOOO0 =public .readFile ('/etc/issue')#line:830
            if session ['server_os']['x']!='RHEL':O0O00O00000O000OO .type ='3'#line:831
            OO0OOO0OO0O0OOO0O ='false';#line:833
            if public .get_webserver ()=='apache':#line:834
                OO0OOO0OO0O0OOO0O =public .readFile ('/www/server/apache/version.pl');#line:835
            public .writeFile ('/var/bt_apacheVersion.pl',OO0OOO0OO0O0OOO0O )#line:836
            public .writeFile ('/var/bt_setupPath.conf',public .GetConfigValue ('root_path'))#line:837
            O000O0OO0O000OOO0 ='/tmp/panelTask.pl'#line:838
            OO0000OO0OOO00O0O ='install';#line:840
            OO0O00O0OOO00OO00 ='安装';#line:841
            if hasattr (O0O00O00000O000OO ,'upgrade'):#line:842
                if O0O00O00000O000OO .upgrade :#line:843
                    OO0000OO0OOO00O0O ='update';#line:844
                    OO0O00O0OOO00OO00 ='upgrade';#line:845
            O000OOOOOOO0OO0O0 ="cd /www/server/panel/install && /bin/bash install_soft.sh "+O0O00O00000O000OO .type +" "+OO0000OO0OOO00O0O +" "+O0O00O00000O000OO .name +" "+O0O00O00000O000OO .version ;#line:846
            O00O0000OO0O00OOO =db .Sql ()#line:847
            if hasattr (O0O00O00000O000OO ,'id'):#line:848
                O00OOOOO0000000O0 =O0O00O00000O000OO .id ;#line:849
            else :#line:850
                O00OOOOO0000000O0 =None ;#line:851
            O00O0000OO0O00OOO .table ('tasks').add ('id,name,type,status,addtime,execstr',(None ,OO0O00O0OOO00OO00 +'['+O0O00O00000O000OO .name +'-'+O0O00O00000O000OO .version +']','execshell','0',time .strftime ('%Y-%m-%d %H:%M:%S'),O000OOOOOOO0OO0O0 ))#line:852
            public .writeFile (O000O0OO0O000OOO0 ,'True')#line:853
            public .WriteLog ('TYPE_SETUP','PLUGIN_ADD',(O0O00O00000O000OO .name ,O0O00O00000O000OO .version ));#line:854
            return public .returnMsg (True ,'PLUGIN_INSTALL');#line:855
    def unInstall (OOOO000O0OO00O000 ,O000OOO00OOO00O00 ):#line:859
        OOO00O0O0O0O00O0O =OOOO000O0OO00O000 .GetFind (O000OOO00OOO00O00 .name );#line:860
        if not OOO00O0O0O0O00O0O :#line:861
            import json #line:862
            OOO00O0O0O0O00O0O =json .loads (public .readFile (OOOO000O0OO00O000 .__O00000O0O0OO0OO0O +'/'+O000OOO00OOO00O00 .name +'/info.json'));#line:863
        if OOO00O0O0O0O00O0O ['tip']=='lib':#line:865
            if not os .path .exists (OOOO000O0OO00O000 .__O00000O0O0OO0OO0O +'/'+OOO00O0O0O0O00O0O ['name']):os .system ('mkdir -p '+OOOO000O0OO00O000 .__O00000O0O0OO0OO0O +'/'+OOO00O0O0O0O00O0O ['name']);#line:866
            O0OOO000OO0000OOO =session ['download_url']+'/install/plugin/'+OOO00O0O0O0O00O0O ['name']+'/install.sh';#line:867
            OOO0000OO0O0OO0O0 =OOOO000O0OO00O000 .__O00000O0O0OO0OO0O +'/'+OOO00O0O0O0O00O0O ['name']+'/uninstall.sh';#line:868
            public .downloadFile (O0OOO000OO0000OOO ,OOO0000OO0O0OO0O0 )#line:869
            os .system ('/bin/bash '+OOO0000OO0O0OO0O0 +' uninstall')#line:870
            os .system ('rm -rf '+session ['download_url']+'/install/plugin/'+OOO00O0O0O0O00O0O ['name'])#line:871
            OO0OO00000O0O0O00 =OOOO000O0OO00O000 .__O00000O0O0OO0OO0O +'/'+OOO00O0O0O0O00O0O ['name']#line:872
            if os .path .exists (OO0OO00000O0O0O00 +'/install.sh'):#line:874
                os .system ('/bin/bash '+OO0OO00000O0O0O00 +'/install.sh uninstall');#line:875
            if os .path .exists (OO0OO00000O0O0O00 ):#line:877
                public .ExecShell ('rm -rf '+OO0OO00000O0O0O00 );#line:878
            public .WriteLog ('TYPE_SETUP','PLUGIN_UNINSTALL_SOFT',(OOO00O0O0O0O00O0O ['title'],));#line:880
            return public .returnMsg (True ,'PLUGIN_UNINSTALL');#line:881
        else :#line:882
            O000OOO00OOO00O00 .type ='0'#line:883
            OO0OO0OO0O0000000 =public .readFile ('/etc/issue')#line:884
            if session ['server_os']['x']!='RHEL':O000OOO00OOO00O00 .type ='3'#line:885
            public .writeFile ('/var/bt_setupPath.conf',public .GetConfigValue ('root_path'))#line:886
            OOOOOOO00O0OO00O0 ="cd /www/server/panel/install && /bin/bash install_soft.sh "+O000OOO00OOO00O00 .type +" uninstall "+O000OOO00OOO00O00 .name .lower ()+" "+O000OOO00OOO00O00 .version .replace ('.','');#line:887
            os .system (OOOOOOO00O0OO00O0 );#line:888
            public .WriteLog ('TYPE_SETUP','PLUGIN_UNINSTALL',(O000OOO00OOO00O00 .name ,O000OOO00OOO00O00 .version ));#line:889
            return public .returnMsg (True ,"PLUGIN_UNINSTALL");#line:890
    def getProductInfo (OO00O00O000O0OOO0 ,O0O00OO00OO0O0OOO ):#line:893
        if not OO00O00O000O0OOO0 .__O0OO00O0OOO0O0000 :#line:894
            import panelAuth #line:895
            O0O0O0OOOO0OOOO0O =panelAuth .panelAuth ();#line:896
            OO00O00O000O0OOO0 .__O0OO00O0OOO0O0000 =O0O0O0OOOO0OOOO0O .get_business_plugin (None );#line:897
        for O0000OO000O0OO000 in OO00O00O000O0OOO0 .__O0OO00O0OOO0O0000 :#line:898
            if O0000OO000O0OO000 ['name']==O0O00OO00OO0O0OOO :return O0000OO000O0OO000 ;#line:899
        return None ;#line:900
    def getEndDate (OO0O0OOOOOO0O0OO0 ,O0000OO0000000O00 ):#line:903
        if not OO0O0OOOOOO0O0OO0 .__OOO000O00OOO00O0O :#line:904
            import panelAuth #line:905
            OOOO00O00OO0O000O =panelAuth .panelAuth ();#line:906
            OOOO00OO0OO00O0O0 =OOOO00O00OO0O000O .get_plugin_list (None );#line:907
            if not OOOO00OO0OO00O0O0 :return '未开通';#line:908
            if not 'data'in OOOO00OO0OO00O0O0 :return '未开通';#line:909
            OO0O0OOOOOO0O0OO0 .__OOO000O00OOO00O0O =OOOO00OO0OO00O0O0 ['data']#line:910
        for OO00OO000OOO00O0O in OO0O0OOOOOO0O0OO0 .__OOO000O00OOO00O0O :#line:911
            if OO00OO000OOO00O0O ['product']==O0000OO0000000O00 :#line:912
                if not OO00OO000OOO00O0O ['endtime']or not OO00OO000OOO00O0O ['state']:return '待支付';#line:913
                if OO00OO000OOO00O0O ['endtime']<time .time ():return '已到期';#line:914
                return time .strftime ("%Y-%m-%d",time .localtime (OO00OO000OOO00O0O ['endtime']));#line:915
        return '未开通';#line:916
    def getPluginList (OO0OOO00OO000OO00 ,O0O000000O0OOOO00 ):#line:919
        import json #line:920
        OO0O0O0OOO0O0O0OO =OO0OOO00OO000OO00 .GetList (O0O000000O0OOOO00 );#line:921
        OOOO0OO00O00OO000 ={}#line:922
        if not OO0O0O0OOO0O0O0OO :#line:923
            OOOO0OO00O00OO000 ['data']=OO0O0O0OOO0O0O0OO ;#line:924
            OOOO0OO00O00OO000 ['type']=OO0OOO00OO000OO00 .GetType (None );#line:925
            return OOOO0OO00O00OO000 ;#line:926
        OO00OO0O0O0OO0000 =""#line:927
        try :#line:928
            OOOO0OO0O0O00O00O ='/www/server/apache/version.pl';#line:929
            if os .path .exists (OOOO0OO0O0O00O00O ):#line:930
                OO00OO0O0O0OO0000 =public .readFile (OOOO0OO0O0O00O00O ).strip ();#line:931
        except :#line:932
            pass ;#line:933
        OOOO0OO00O00OO000 =OO0OOO00OO000OO00 .GetPage (OO0O0O0OOO0O0O0OO ,O0O000000O0OOOO00 );#line:935
        OO0O0O0OOO0O0O0OO =OOOO0OO00O00OO000 ['data'];#line:936
        for O000000O00OOOOOO0 in range (len (OO0O0O0OOO0O0O0OO )):#line:937
            OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['end']='--';#line:938
            if OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['name']=='php':#line:946
                if OO00OO0O0O0OO0000 =='2.2':#line:947
                    OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['versions']='5.2,5.3,5.4';#line:948
                    OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['update']=OO0OOO00OO000OO00 .GetPv (OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['versions'],OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['update'])#line:949
                elif OO00OO0O0O0OO0000 =='2.4':#line:950
                    OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['versions']='5.3,5.4,5.5,5.6,7.0,7.1,7.2';#line:951
                    OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['update']=OO0OOO00OO000OO00 .GetPv (OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['versions'],OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['update'])#line:952
                OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['apache']=OO00OO0O0O0OO0000 ;#line:953
            OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['versions']=OO0OOO00OO000OO00 .checksSetup (OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['name'].replace ('_soft',''),OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['checks'],OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['versions'])#line:955
            try :#line:957
                OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['update']=OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['update'].split (',');#line:958
            except :#line:959
                OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['update']=[];#line:960
            if os .path .exists (OO0OOO00OO000OO00 .__O00000O0O0OO0OO0O +'/'+OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['name']):OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['tip']='lib';#line:963
            if OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['tip']=='lib':#line:965
                OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['path']=OO0OOO00OO000OO00 .__O00000O0O0OO0OO0O +'/'+OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['name'].replace ('_soft','');#line:966
                OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['config']=os .path .exists (OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['path']+'/index.html');#line:967
            else :#line:968
                OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['path']='/www/server/'+OO0O0O0OOO0O0O0OO [O000000O00OOOOOO0 ]['name'].replace ('_soft','');#line:969
        OO0O0O0OOO0O0O0OO .append (public .M ('tasks').where ("status!=?",('1',)).count ());#line:970
        OOOO0OO00O00OO000 ['data']=OO0O0O0OOO0O0O0OO ;#line:973
        OOOO0OO00O00OO000 ['type']=OO0OOO00OO000OO00 .GetType (None );#line:974
        return OOOO0OO00O00OO000 ;#line:975
    def GetPv (OOO000OOO0000OOOO ,O0OOO00O0OOO00OOO ,O00OO0OOOOOOOO0OO ):#line:978
        O0OOO00O0OOO00OOO =O0OOO00O0OOO00OOO .split (',');#line:979
        O00OO0OOOOOOOO0OO =O00OO0OOOOOOOO0OO .split (',');#line:980
        O0OO000OOOO00OOOO =[];#line:981
        for OOO000000O0OO0000 in O00OO0OOOOOOOO0OO :#line:982
            if OOO000000O0OO0000 [:3 ]in O0OOO00O0OOO00OOO :O0OO000OOOO00OOOO .append (OOO000000O0OO0000 );#line:983
        return ','.join (O0OO000OOOO00OOOO );#line:984
    def savePluginSort (O00OOOOOOOO00OO00 ,OOOOOO00O00OO0OOO ):#line:987
        OOO0O00O0OOOO0O00 =OOOOOO00O00OO0OOO .ssort .split ('|');#line:988
        O00O0OO000O00OO00 =O00OOOOOOOO00OO00 .GetList (None )#line:989
        O0000OOOO0O00OO00 =len (O00O0OO000O00OO00 );#line:990
        for OO0O0OOO0O0OO00OO in range (len (OOO0O00O0OOOO0O00 )):#line:991
            if int (OOO0O00O0OOOO0O00 [OO0O0OOO0O0OO00OO ])>1000 :continue ;#line:992
            for OOO000O0O0OOOO0OO in range (O0000OOOO0O00OO00 ):#line:993
                if O00O0OO000O00OO00 [OOO000O0O0OOOO0OO ]['pid']==int (OOO0O00O0OOOO0O00 [OO0O0OOO0O0OO00OO ]):O00O0OO000O00OO00 [OOO000O0O0OOOO0OO ]['sort']=OO0O0OOO0O0OO00OO ;#line:994
        public .writeFile (O00OOOOOOOO00OO00 .__O0O000O0OO00000OO ,json .dumps (O00O0OO000O00OO00 ));#line:995
        return public .returnMsg (True ,'PLUGIN_SORT');#line:996
    def checksSetup (O00O0000OOOO0O00O ,O00O0OO0000OO000O ,OOOOO0O0O00O0000O ,vers =''):#line:999
        OOO00OOO0OOO0O00O =OOOOO0O0O00O0000O .split (',');#line:1000
        OOO000000000OOO00 =[];#line:1001
        OO0O0O0OO0000O0OO ='/www/server/'+O00O0OO0000OO000O +'/version.pl';#line:1002
        O00O00O0OOOO000OO ='';#line:1003
        if os .path .exists (OO0O0O0OO0000O0OO ):O00O00O0OOOO000OO =public .readFile (OO0O0O0OO0000O0OO ).strip ()#line:1004
        if O00O0OO0000OO000O =='nginx':O00O00O0OOOO000OO =O00O00O0OOOO000OO .replace ('1.10','1.12');#line:1005
        if not O00O0000OOOO0O00O .__OOO000000OO0OOO00 :#line:1006
            O00O0000OOOO0O00O .__OOO000000OO0OOO00 =public .M ('tasks').where ("status!=?",('1',)).field ('status,name').select ()#line:1007
        OOO00O0O0O00O000O =0 ;#line:1008
        OO0O0O00000OOO00O =vers .split (',');#line:1009
        for O0O0OOO00O0OO00OO in OO0O0O00000OOO00O :#line:1010
            OOOOOO0000O00O0OO ={}#line:1011
            OO0O0O00OOO0O000O =O0O0OOO00O0OO00OO ;#line:1013
            if O00O0OO0000OO000O =='php':OO0O0O00OOO0O000O =OO0O0O00OOO0O000O .replace ('.','');#line:1014
            OOO0OOO000O000O0O =False ;#line:1015
            for O00OO0OO000O0O00O in OOO00OOO0OOO0O00O :#line:1016
                if O00O0OO0000OO000O =='php':#line:1017
                    OO0O0O0OO0000O0OO ='/www/server/php/'+OO0O0O00OOO0O000O #line:1018
                    if os .path .exists (OO0O0O0OO0000O0OO +'/bin/php')and not os .path .exists (OO0O0O0OO0000O0OO +'/version.pl'):#line:1019
                        public .ExecShell ("echo `"+OO0O0O0OO0000O0OO +"/bin/php 2>/dev/null -v|grep cli|awk '{print $2}'` > "+OO0O0O0OO0000O0OO +'/version.pl')#line:1020
                    try :#line:1021
                        O00O00O0OOOO000OO =public .readFile (OO0O0O0OO0000O0OO +'/version.pl').strip ();#line:1022
                        if not O00O00O0OOOO000OO :os .system ('rm -f '+OO0O0O0OO0000O0OO +'/version.pl');#line:1023
                    except :#line:1024
                        O00O00O0OOOO000OO ="";#line:1025
                    if os .path .exists (O00OO0OO000O0O00O .replace ('VERSION',OO0O0O00OOO0O000O )):OOO0OOO000O000O0O =True ;#line:1026
                else :#line:1027
                    if os .path .exists (O00OO0OO000O0O00O )and OOO00O0O0O00O000O ==0 :#line:1028
                        if len (OO0O0O00000OOO00O )>1 :#line:1029
                            O00O0OO0OO00O000O =O00O00O0OOOO000OO .find (O0O0OOO00O0OO00OO )#line:1030
                            if O00O0OO0OO00O000O !=-1 and O00O0OO0OO00O000O <3 :#line:1031
                                OOO0OOO000O000O0O =True #line:1032
                                OOO00O0O0O00O000O +=1 ;#line:1033
                        else :#line:1034
                            OOO0OOO000O000O0O =True #line:1035
                            OOO00O0O0O00O000O +=1 ;#line:1036
            if not O00O0000OOOO0O00O .__OOO000000OO0OOO00 :#line:1038
                O00O0000OOOO0O00O .__OOO000000OO0OOO00 =public .M ('tasks').where ("status!=?",('1',)).field ('status,name').select ()#line:1039
            OOOO0OOOOOOO00O0O ='1';#line:1040
            for OO0O0O0O0OOOOO0O0 in O00O0000OOOO0O00O .__OOO000000OO0OOO00 :#line:1041
                O0O000O0O00O0OO00 =public .getStrBetween ('[',']',OO0O0O0O0OOOOO0O0 ['name'])#line:1042
                if not O0O000O0O00O0OO00 :continue ;#line:1043
                O0O0OO0O0OOOO0O0O =O0O000O0O00O0OO00 .split ('-');#line:1044
                O000O00O0O0O0O0OO =O0O0OO0O0OOOO0O0O [0 ].lower ();#line:1045
                if O00O0OO0000OO000O =='php':#line:1046
                    if O000O00O0O0O0O0OO ==O00O0OO0000OO000O and O0O0OO0O0OOOO0O0O [1 ]==O0O0OOO00O0OO00OO :OOOO0OOOOOOO00O0O =OO0O0O0O0OOOOO0O0 ['status'];#line:1047
                else :#line:1048
                    if O000O00O0O0O0O0OO =='pure':O000O00O0O0O0O0OO ='pure-ftpd';#line:1049
                    if O000O00O0O0O0O0OO ==O00O0OO0000OO000O :OOOO0OOOOOOO00O0O =OO0O0O0O0OOOOO0O0 ['status'];#line:1050
            OO00OO0OOOO00OOOO ='plugin/'+O00O0OO0000OO000O +'/info.json'#line:1052
            if os .path .exists (OO00OO0OOOO00OOOO ):#line:1053
                try :#line:1054
                    OO0OOO0O0000O000O =json .loads (public .readFile (OO00OO0OOOO00OOOO ));#line:1055
                    if OO0OOO0O0000O000O :O00O00O0OOOO000OO =OO0OOO0O0000O000O ['versions'];#line:1056
                except :pass ;#line:1057
            if O00O0OO0000OO000O =='memcached':#line:1059
                if os .path .exists ('/etc/init.d/memcached'):#line:1060
                    O00O00O0OOOO000OO =session .get ('memcachedv')#line:1061
                    if not O00O00O0OOOO000OO :#line:1062
                        O00O00O0OOOO000OO =public .ExecShell ("memcached -V|awk '{print $2}'")[0 ].strip ();#line:1063
                        session ['memcachedv']=O00O00O0OOOO000OO #line:1064
            if O00O0OO0000OO000O =='apache':#line:1065
                if os .path .exists ('/www/server/apache/bin/httpd'):#line:1066
                    O00O00O0OOOO000OO =session .get ('httpdv')#line:1067
                    if not O00O00O0OOOO000OO :#line:1068
                        O00O00O0OOOO000OO =public .ExecShell ("/www/server/apache/bin/httpd -v|grep Apache|awk '{print $3}'|sed 's/Apache\///'")[0 ].strip ();#line:1069
                        session ['httpdv']=O00O00O0OOOO000OO #line:1070
            OOOOOO0000O00O0OO ['status']=OOO0OOO000O000O0O #line:1074
            OOOOOO0000O00O0OO ['version']=O0O0OOO00O0OO00OO ;#line:1075
            OOOOOO0000O00O0OO ['task']=OOOO0OOOOOOO00O0O ;#line:1076
            OOOOOO0000O00O0OO ['no']=O00O00O0OOOO000OO #line:1077
            OOO000000000OOO00 .append (OOOOOO0000O00O0OO );#line:1078
        return O00O0000OOOO0O00O .checkRun (O00O0OO0000OO000O ,OOO000000000OOO00 );#line:1079
    def checkRun (OO00OO0OO0O00O0O0 ,O000OOOOO00O00O0O ,O000O00OOOOOO000O ):#line:1082
        if O000OOOOO00O00O0O =='php':#line:1083
            O0OOOO000OO0000OO ='/www/server/php'#line:1084
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1085
                if O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['status']:#line:1086
                    OOO0O000O000000OO =O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['version'].replace ('.','')#line:1087
                    O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=os .path .exists ('/tmp/php-cgi-'+OOO0O000O000000OO +'.sock');#line:1088
                    O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['fpm']=os .path .exists ('/etc/init.d/php-fpm-'+OOO0O000O000000OO );#line:1089
                    OO0OOO0O00O0OOO00 =OO00OO0OO0O00O0O0 .GetPHPConfig (OOO0O000O000000OO );#line:1090
                    O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['max']=OO0OOO0O00O0OOO00 ['max']#line:1091
                    O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['maxTime']=OO0OOO0O00O0OOO00 ['maxTime']#line:1092
                    O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['pathinfo']=OO0OOO0O00O0OOO00 ['pathinfo']#line:1093
                    O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['display']=os .path .exists (O0OOOO000OO0000OO +'/'+OOO0O000O000000OO +'/display.pl');#line:1094
                    if len (O000O00OOOOOO000O )<5 :O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=True ;#line:1095
        elif O000OOOOO00O00O0O =='nginx':#line:1097
            OOOO00O0OOO0O00OO =False #line:1098
            if os .path .exists ('/etc/init.d/nginx'):#line:1099
                OO0OO0O00000OO00O ='/www/server/nginx/logs/nginx.pid';#line:1100
                if os .path .exists (OO0OO0O00000OO00O ):#line:1101
                    try :#line:1102
                        O000OO00OO0OOO000 =public .readFile (OO0OO0O00000OO00O )#line:1103
                        O000OO0O0OO00O000 =OO00OO0OO0O00O0O0 .checkProcess (O000OO00OO0OOO000 );#line:1104
                        if O000OO0O0OO00O000 :OOOO00O0OOO0O00OO =True ;#line:1105
                    except :#line:1106
                        OOOO00O0OOO0O00OO =False #line:1107
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1108
                O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=False #line:1109
                if O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['status']:O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=OOOO00O0OOO0O00OO #line:1110
        elif O000OOOOO00O00O0O =='apache':#line:1111
            OOOO00O0OOO0O00OO =False #line:1112
            if os .path .exists ('/etc/init.d/httpd'):#line:1113
                OO0OO0O00000OO00O ='/www/server/apache/logs/httpd.pid';#line:1114
                if os .path .exists (OO0OO0O00000OO00O ):#line:1115
                    O000OO00OO0OOO000 =public .readFile (OO0OO0O00000OO00O )#line:1116
                    OOOO00O0OOO0O00OO =OO00OO0OO0O00O0O0 .checkProcess (O000OO00OO0OOO000 );#line:1117
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1118
                O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=False #line:1119
                if O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['status']:O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=OOOO00O0OOO0O00OO #line:1120
        elif O000OOOOO00O00O0O =='mysql':#line:1121
            OOOO00O0OOO0O00OO =os .path .exists ('/tmp/mysql.sock')#line:1122
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1123
                O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=False #line:1124
                if O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['status']:O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=OOOO00O0OOO0O00OO #line:1125
        elif O000OOOOO00O00O0O =='tomcat':#line:1126
            OOOO00O0OOO0O00OO =False #line:1127
            if os .path .exists ('/www/server/tomcat/logs/catalina-daemon.pid'):#line:1128
                if OO00OO0OO0O00O0O0 .getPid ('jsvc'):OOOO00O0OOO0O00OO =True #line:1129
            if not OOOO00O0OOO0O00OO :#line:1130
                if OO00OO0OO0O00O0O0 .getPid ('java'):OOOO00O0OOO0O00OO =True #line:1131
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1132
                O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=False #line:1133
                if O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['status']:O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=OOOO00O0OOO0O00OO #line:1134
        elif O000OOOOO00O00O0O =='pure-ftpd':#line:1135
                for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1136
                    OO0OO0O00000OO00O ='/var/run/pure-ftpd.pid'#line:1137
                    if os .path .exists (OO0OO0O00000OO00O ):#line:1138
                        O000OO00OO0OOO000 =public .readFile (OO0OO0O00000OO00O )#line:1139
                        O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=OO00OO0OO0O00O0O0 .checkProcess (O000OO00OO0OOO000 )#line:1140
                        if not O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']:os .system ('rm -f '+OO0OO0O00000OO00O )#line:1141
        elif O000OOOOO00O00O0O =='phpmyadmin':#line:1142
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1143
                if O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['status']:O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]=OO00OO0OO0O00O0O0 .getPHPMyAdminStatus ();#line:1144
        elif O000OOOOO00O00O0O =='redis':#line:1145
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1146
                OO0OO0O00000OO00O ='/var/run/redis_6379.pid'#line:1147
                if os .path .exists (OO0OO0O00000OO00O ):#line:1148
                    O000OO00OO0OOO000 =public .readFile (OO0OO0O00000OO00O )#line:1149
                    O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=OO00OO0OO0O00O0O0 .checkProcess (O000OO00OO0OOO000 )#line:1150
                    if not O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']:os .system ('rm -f '+OO0OO0O00000OO00O )#line:1151
        elif O000OOOOO00O00O0O =='memcached':#line:1152
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1153
                OO0OO0O00000OO00O ='/var/run/memcached.pid'#line:1154
                if os .path .exists (OO0OO0O00000OO00O ):#line:1155
                    O000OO00OO0OOO000 =public .readFile (OO0OO0O00000OO00O )#line:1156
                    O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=OO00OO0OO0O00O0O0 .checkProcess (O000OO00OO0OOO000 )#line:1157
                    if not O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']:os .system ('rm -f '+OO0OO0O00000OO00O )#line:1158
        else :#line:1159
            for OOOOOOO000O00O0O0 in range (len (O000O00OOOOOO000O )):#line:1160
                if O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['status']:O000O00OOOOOO000O [OOOOOOO000O00O0O0 ]['run']=True ;#line:1161
        return O000O00OOOOOO000O #line:1162
    def getPHPMyAdminStatus (O0O00OO0OO000O0O0 ):#line:1166
        import re #line:1167
        O0OOOOO0OOOOOO00O ={}#line:1168
        OOOOO00OOO00O0O00 =os .getenv ('BT_SETUP')#line:1169
        import panelSite #line:1170
        OOO0OOOO0OO0OOOOO =panelSite .panelSite ()#line:1171
        OOOO00O0OO00OO000 =OOO0OOOO0OO0OOOOO .get_site_info ('phpmyadmin')#line:1172
        if OOOO00O0OO00OO000 :#line:1173
            try :#line:1174
                O0O0000OO00O0OO0O =OOOOO00OOO00O0O00 +'/phpmyadmin/version.pl';#line:1175
                if os .path .exists (O0O0000OO00O0OO0O ):#line:1176
                    O0OOOOO0OOOOOO00O ['version']=public .readFile (O0O0000OO00O0OO0O ).strip ();#line:1177
                    O0OOOOO0OOOOOO00O ['status']=True ;#line:1178
                    O0OOOOO0OOOOOO00O ['no']=O0OOOOO0OOOOOO00O ['version'];#line:1179
                else :#line:1180
                    O0OOOOO0OOOOOO00O ['version']="";#line:1181
                    O0OOOOO0OOOOOO00O ['status']=False ;#line:1182
                    O0OOOOO0OOOOOO00O ['no']="";#line:1183
                OO00OO0OO0O0OOO00 =get_input ();#line:1185
                OO00OO0OO0O0OOO00 .siteName ='phpmyadmin'#line:1186
                O0OOOOO0OOOOOO00O ['run']=OOOO00O0OO00OO000 ['start'];#line:1187
                O0OOOOO0OOOOOO00O ['phpversion']=OOO0OOOO0OO0OOOOO .GetSitePHPVersion (OO00OO0OO0O0OOO00 )['phpversion'];#line:1188
                O0OOOOO0OOOOOO00O ['port']=OOOO00O0OO00OO000 ['domains'][0 ]['port'];#line:1189
                O0OOOOO0OOOOOO00O ['auth']=False ;#line:1190
            except Exception as O0OOOO0O0O0O0000O :#line:1191
                O0OOOOO0OOOOOO00O ['status']=False ;#line:1192
                O0OOOOO0OOOOOO00O ['error']=str (O0OOOO0O0O0O0000O );#line:1193
        return O0OOOOO0OOOOOO00O ;#line:1194
    def GetPHPConfig (OOO000O0OO0OO000O ,O0O00OO000O000O0O ):#line:1197
        import re #line:1198
        OO0O0OOOOOOOO0O00 =OOO000O0OO0OO000O .__O00000OOO0OO000OO +"/php/"+O0O00OO000O000O0O +"/php.ini"#line:1199
        OOO00O00000OOO000 =public .readFile (OO0O0OOOOOOOO0O00 )#line:1200
        OO0OO0OO00OOO00O0 ={}#line:1202
        try :#line:1203
            OO0OOO0OO00O0OOOO ="upload_max_filesize\s*=\s*([0-9]+)M"#line:1204
            O0O00O0O0OO000OOO =re .search (OO0OOO0OO00O0OOOO ,OOO00O00000OOO000 ).groups ()#line:1205
            OO0OO0OO00OOO00O0 ['max']=O0O00O0O0OO000OOO [0 ]#line:1206
        except :#line:1207
            OO0OO0OO00OOO00O0 ['max']='50'#line:1208
        try :#line:1209
            OO0OOO0OO00O0OOOO ="request_terminate_timeout\s*=\s*([0-9]+)\n"#line:1210
            OO0OO0OO00OOO00O0 ['maxTime']=O0O00O0O0OO000OOO [0 ]#line:1211
        except :#line:1212
            OO0OO0OO00OOO00O0 ['maxTime']=0 #line:1213
        try :#line:1215
            OO0OOO0OO00O0OOOO =u"\n;*\s*cgi\.fix_pathinfo\s*=\s*([0-9]+)\s*\n"#line:1216
            O0O00O0O0OO000OOO =re .search (OO0OOO0OO00O0OOOO ,OOO00O00000OOO000 ).groups ()#line:1217
            if O0O00O0O0OO000OOO [0 ]=='1':#line:1219
                OO0OO0OO00OOO00O0 ['pathinfo']=True #line:1220
            else :#line:1221
                OO0OO0OO00OOO00O0 ['pathinfo']=False #line:1222
        except :#line:1223
            OO0OO0OO00OOO00O0 ['pathinfo']=False #line:1224
        return OO0OO0OO00OOO00O0 #line:1226
    def getPid (OO00O00OO0OOO0OOO ,O0OOOOOO0O0OO000O ):#line:1229
        try :#line:1230
            if not OO00O00OO0OOO0OOO .pids :OO00O00OO0OOO0OOO .pids =psutil .pids ()#line:1231
            for O00OO00OOOO0OOO0O in OO00O00OO0OOO0OOO .pids :#line:1232
                if psutil .Process (O00OO00OOOO0OOO0O ).name ()==O0OOOOOO0O0OO000O :return True ;#line:1233
            return False #line:1234
        except :return True #line:1235
    def checkProcess (O0OOO0000O00O0OOO ,OOO000O0000O0OOO0 ):#line:1238
        try :#line:1239
            if not O0OOO0000O00O0OOO .pids :O0OOO0000O00O0OOO .pids =psutil .pids ()#line:1240
            if int (OOO000O0000O0OOO0 )in O0OOO0000O00O0OOO .pids :return True #line:1241
            return False ;#line:1242
        except :return False #line:1243
    def getConfigHtml (OO0OO0OOO0O00000O ,OOO000OOO000OOO00 ):#line:1246
        OOOO00OOO00OO0OOO =OO0OO0OOO0O00000O .__O00000O0O0OO0OO0O +'/'+OOO000OOO000OOO00 .name +'/index.html';#line:1247
        if not os .path .exists (OOOO00OOO00OO0OOO ):return public .returnMsg (False ,'PLUGIN_GET_HTML');#line:1248
        O0000O0O0O0OOOOO0 =public .readFile (OOOO00OOO00OO0OOO ,'r')#line:1249
        return O0000O0O0O0OOOOO0 #line:1250
    def getPluginInfo (O0O0OO000OOO0OO00 ,OO0O0O0O0OOOO0000 ):#line:1253
        try :#line:1254
            OOO0O0O0OO00OO0OO =O0O0OO000OOO0OO00 .GetFind (OO0O0O0O0OOOO0000 .name )#line:1255
            OOOOO0O00O0OO00O0 =""#line:1256
            try :#line:1257
                OOO0OOOOOO0O00OO0 ='/www/server/apache/version.pl';#line:1258
                if os .path .exists (OOO0OOOOOO0O00OO0 ):#line:1259
                    OOOOO0O00O0OO00O0 =public .readFile (OOO0OOOOOO0O00OO0 ).strip ();#line:1260
            except :#line:1261
                pass ;#line:1262
            if OOO0O0O0OO00OO0OO ['name']=='php':#line:1263
                if OOOOO0O00O0OO00O0 =='2.2':#line:1264
                    OOO0O0O0OO00OO0OO ['versions']='5.2,5.3,5.4';#line:1265
                elif OOOOO0O00O0OO00O0 =='2.4':#line:1266
                    OOO0O0O0OO00OO0OO ['versions']='5.3,5.4,5.5,5.6,7.0,7.1,7.2,7.3';#line:1267
            OOO0O0O0OO00OO0OO ['versions']=O0O0OO000OOO0OO00 .checksSetup (OOO0O0O0OO00OO0OO ['name'],OOO0O0O0OO00OO0OO ['checks'],OOO0O0O0OO00OO0OO ['versions'])#line:1269
            if OO0O0O0O0OOOO0000 .name =='php':#line:1270
                OOO0O0O0OO00OO0OO ['phpSort']=public .readFile ('/www/server/php/sort.pl');#line:1271
            return OOO0O0O0OO00OO0OO #line:1272
        except :#line:1273
            return False #line:1274
    def getPluginStatus (OO0O0O000000O0000 ,OOO0O0O00O0OO0000 ):#line:1277
        OOO0OO00O0O000OO0 =OO0O0O000000O0000 .GetFind (OOO0O0O00O0OO0000 .name );#line:1278
        O0O00OO0O0OOOOOO0 =[];#line:1279
        O00OO0O0OO0OO0OO0 ='/www/server/php';#line:1280
        for OO0000OO0OO0O00OO in OOO0OO00O0O000OO0 ['versions'].split (','):#line:1281
            O0O0OOOOO0O00O00O ={}#line:1282
            O0O0OOOOO0O00O00O ['version']=OO0000OO0OO0O00OO #line:1283
            if OOO0O0O00O0OO0000 .name =='php':#line:1284
                O0O0OOOOO0O00O00O ['status']=os .path .exists (O00OO0O0OO0OO0OO0 +'/'+OO0000OO0OO0O00OO .replace (',','')+'/display.pl')#line:1285
            else :#line:1286
                O0O0OOOOO0O00O00O ['status']=OOO0OO00O0O000OO0 ['status'];#line:1287
            O0O00OO0O0OOOOOO0 .append (O0O0OOOOO0O00O00O );#line:1288
        return O0O00OO0O0OOOOOO0 #line:1289
    def setPluginStatus (OOOOOO0O00O0OO0OO ,OO0O0OO00000O00O0 ):#line:1292
        if OO0O0OO00000O00O0 .name =='php':#line:1293
            OOOOO0OO00OOO000O =True #line:1294
            OO00O00O00OO00OO0 ='/www/server/php';#line:1295
            if OO0O0OO00000O00O0 .status =='0':#line:1296
                O0OOO0OOO0O000000 =OOOOOO0O00O0OO0OO .GetFind (OO0O0OO00000O00O0 .name )['versions']#line:1297
                os .system ('rm -f '+OO00O00O00OO00OO0 +'/'+OO0O0OO00000O00O0 .version .replace ('.','')+'/display.pl');#line:1298
                for O0OO00O0OOOO0O000 in O0OOO0OOO0O000000 .split (','):#line:1299
                    if os .path .exists (OO00O00O00OO00OO0 +'/'+O0OO00O0OOOO0O000 .replace ('.','')+'/display.pl'):#line:1300
                        OOOOO0OO00OOO000O =False ;#line:1301
                        break ;#line:1302
            else :#line:1303
                public .writeFile (OO00O00O00OO00OO0 +'/'+OO0O0OO00000O00O0 .version .replace ('.','')+'/display.pl','True');#line:1304
            if OOOOO0OO00OOO000O :#line:1306
                OOOOOO0O00O0OO0OO .SetField (OO0O0OO00000O00O0 .name ,'display',int (OO0O0OO00000O00O0 .status ))#line:1307
        else :#line:1308
            OOOOOO0O00O0OO0OO .SetField (OO0O0OO00000O00O0 .name ,'display',int (OO0O0OO00000O00O0 .status ))#line:1309
        return public .returnMsg (True ,'SET_SUCCESS');#line:1310
    def getCloudPlugin (OO0OOOOO0OOOO0O00 ,O00000O00O00O0000 ):#line:1313
        if session .get ('getCloudPlugin')and O00000O00O00O0000 !=None :return public .returnMsg (True ,'您的插件列表已经是最新版本-1!');#line:1314
        import json #line:1315
        if not session .get ('download_url'):session ['download_url']='http://download.bt.cn';#line:1316
        try :#line:1319
            OOO0O0OOOO00O0OO0 =public .get_url ();#line:1320
            if os .path .exists ('plugin/beta/config.conf'):#line:1321
                OOO0O000000O0O00O =OOO0O0OOOO00O0OO0 +'/install/list.json'#line:1322
            else :#line:1323
                OOO0O000000O0O00O =OOO0O0OOOO00O0OO0 +'/install/list_pro.json'#line:1324
            O0O0OO00OO00O000O =json .loads (public .httpGet (OOO0O000000O0O00O ))#line:1325
            session ['download_url']=OOO0O0OOOO00O0OO0 ;#line:1326
        except :#line:1327
            OOO0O000000O0O00O =session ['download_url']+'/install/list_pro.json'#line:1328
            O0O0OO00OO00O000O =json .loads (public .httpGet (OOO0O000000O0O00O ))#line:1329
        OO0O0O000OOO0O00O =O000O0OO0O0O0OOO0 =OO00OOO0O0OO0OO0O =0 ;#line:1331
        O0O0OOO0OO0OOOO0O =OO0OOOOO0OOOO0O00 .GetList (None );#line:1333
        for O000O0OO0O0O0OOO0 in range (len (O0O0OO00OO00O000O )):#line:1335
            for OOOOOO0OOOO000000 in O0O0OOO0OO0OOOO0O :#line:1336
                if O0O0OO00OO00O000O [O000O0OO0O0O0OOO0 ]['name']!=OOOOOO0OOOO000000 ['name']:continue ;#line:1337
                O0O0OO00OO00O000O [O000O0OO0O0O0OOO0 ]['display']=OOOOOO0OOOO000000 ['display'];#line:1338
            if O0O0OO00OO00O000O [O000O0OO0O0O0OOO0 ]['default']:#line:1339
                O00000O00O00O0000 .name =O0O0OO00OO00O000O [O000O0OO0O0O0OOO0 ]['name'];#line:1340
                OO0OOOOO0OOOO0O00 .install (O00000O00O00O0000 );#line:1341
        public .writeFile (OO0OOOOO0OOOO0O00 .__O0O000O0OO00000OO ,json .dumps (O0O0OO00OO00O000O ));#line:1343
        try :#line:1346
            OOO0O000000O0O00O =session ['download_url']+'/install/type.json'#line:1347
            O0OO00000OO0O00O0 =json .loads (public .httpGet (OOO0O000000O0O00O ))#line:1348
            public .writeFile (OO0OOOOO0OOOO0O00 .__O0OO0O00OO00OO00O ,json .dumps (O0OO00000OO0O00O0 ));#line:1349
        except :#line:1350
            pass ;#line:1351
        OO0OOOOO0OOOO0O00 .getCloudPHPExt (O00000O00O00O0000 );#line:1353
        OO0OOOOO0OOOO0O00 .GetCloudWarning (O00000O00O00O0000 );#line:1354
        session ['getCloudPlugin']=True ;#line:1355
        return public .returnMsg (True ,'PLUGIN_UPDATE');#line:1356
    def flush_cache (O00000OO0O000OOO0 ,OO00OOOOOOOO00OO0 ):#line:1359
        O00000OO0O000OOO0 .getCloudPlugin (None );#line:1360
        return public .returnMsg (True ,'软件列表已更新!');#line:1361
    def getCloudPHPExt (O0O00OOOOOO0O0000 ,O000O0O0O000O00O0 ):#line:1364
        import json #line:1365
        try :#line:1366
            if not session .get ('download_url'):session ['download_url']='http://download.bt.cn';#line:1367
            O000O00OOOOO00OO0 =session ['download_url']+'/install/lib/phplib.json'#line:1368
            O0O0OO0O00OO0OO0O =public .httpGet (O000O00OOOOO00OO0 )#line:1369
            O0OO0OOO000OOO000 =json .loads (O0O0OO0O00OO0OO0O );#line:1370
            if not O0OO0OOO000OOO000 :return False ;#line:1371
            public .writeFile ('data/phplib.conf',json .dumps (O0OO0OOO000OOO000 ));#line:1372
            return True ;#line:1373
        except :#line:1374
            return False ;#line:1375
    def GetCloudWarning (O0O00OO0O0O0000OO ,O00O00000OO00OOO0 ):#line:1378
        import json #line:1379
        if not session .get ('download_url'):session ['download_url']='http://download.bt.cn';#line:1380
        OOOOOOOOO00OO00OO =session ['download_url']+'/install/warning.json'#line:1381
        OOO000000O0OO00OO =public .httpGet (OOOOOOOOO00OO00OO )#line:1382
        OOO0O0OO0O00O0O00 =json .loads (OOO000000O0OO00OO );#line:1383
        if not OOO0O0OO0O00O0O00 :return False ;#line:1384
        O00000O00OO0O0OOO ='data/warning.json';#line:1385
        O0OOOOOO0OOOO0O0O =json .loads (public .readFile (O00000O00OO0O0OOO ));#line:1386
        for OOOO0OO0OOO0000OO in range (len (OOO0O0OO0O00O0O00 ['data'])):#line:1387
            for OOOOOOO0000OO0000 in O0OOOOOO0OOOO0O0O ['data']:#line:1388
                if OOO0O0OO0O00O0O00 ['data'][OOOO0OO0OOO0000OO ]['name']!=OOOOOOO0000OO0000 ['name']:continue ;#line:1389
                OOO0O0OO0O00O0O00 ['data'][OOOO0OO0OOO0000OO ]['ignore_count']=OOOOOOO0000OO0000 ['ignore_count'];#line:1390
                OOO0O0OO0O00O0O00 ['data'][OOOO0OO0OOO0000OO ]['ignore_time']=OOOOOOO0000OO0000 ['ignore_time'];#line:1391
        public .writeFile (O00000O00OO0O0OOO ,json .dumps (OOO0O0OO0O00O0O00 ));#line:1392
        return OOO0O0OO0O00O0O00 ;#line:1393
    def get_title_byname (O0000O0O000OO00O0 ,O0OOO00O00OOO0O0O ):#line:1396
        O0OOO00O00OOO0O0O .sName =O0OOO00O00OOO0O0O .name #line:1397
        OO00OOO00O0O0OO0O =O0000O0O000OO00O0 .get_soft_find (O0OOO00O00OOO0O0O )#line:1398
        return OO00OOO00O0O0OO0O ['title']#line:1399
    def a (OOO00OO0000OO00O0 ,OO0O0OO0O0O000O00 ):#line:1403
        if not hasattr (OO0O0OO0O0O000O00 ,'name'):return public .returnMsg (False ,'PLUGIN_INPUT_A');#line:1404
        try :#line:1405
            OOOO0OO0OO0O0O0O0 =OOO00OO0000OO00O0 .__O00000O0O0OO0OO0O +'/'+OO0O0OO0O0O000O00 .name #line:1406
            if not os .path .exists (OOOO0OO0OO0O0O0O0 +'/'+OO0O0OO0O0O000O00 .name +'_main.py'):return public .returnMsg (False ,'PLUGIN_INPUT_B');#line:1407
            if sys .version_info [0 ]!=2 :#line:1408
                from imp import reload #line:1409
            sys .path .append (OOOO0OO0OO0O0O0O0 );#line:1410
            OOO000O00O000OO00 =__import__ (OO0O0OO0O0O000O00 .name +'_main');#line:1411
            OO000OO0O0OOOOO0O =eval ('plugin_main.'+OO0O0OO0O0O000O00 .name +'_main()');#line:1413
            if not hasattr (OO000OO0O0OOOOO0O ,OO0O0OO0O0O000O00 .s ):return public .returnMsg (False ,'PLUGIN_INPUT_C',(OO0O0OO0O0O000O00 .s ,));#line:1414
            OOOO0OOO0O00000OO ='pluginObject.'+OO0O0OO0O0O000O00 .s +'(get)'#line:1415
            return eval (OOOO0OOO0O00000OO );#line:1416
        except AttributeError as O00OO000OO0O00000 :#line:1417
            return public .returnMsg (False ,'您未购买[%s]或授权已到期!'%OOO00OO0000OO00O0 .get_title_byname (OO0O0OO0O0O000O00 ))#line:1418
