import sys,os,shutil
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath);
sys.path.append("class/")
import public,tarfile

class panel_php:
    _name = 'php'
    _version = None
    _setup_path = None

    def __init__(self,name,version,setup_path):
        self._name = name
        self._version = version
        self._setup_path = setup_path
        self._iis_root = os.getenv("SYSTEMDRIVE") + '\\Windows\\System32\\inetsrv'
        self._app_cmd = self._iis_root + '\\appcmd.exe'

    def install_soft(self,downurl):       
        self._version = self._version.replace('.','')
        if not public.check_setup_vc(self._version):
            vc_version = public.get_vc_version(self._version)
            if not public.setup_vc(vc_version):  return public.returnMsg(False,'VC' + vc_version + '安装失败!'); 

        path = self._setup_path + '\\php'
        temp = self._setup_path + '/temp/' + self._version + '.rar'
        public.downloadFile(downurl + '/win/php/'+ self._version +'.rar',temp)

        if not os.path.exists(temp): return public.returnMsg(False,'文件下载失败,请检查网络!');

        from unrar import rarfile
        rar = rarfile.RarFile(temp)  
        rar.extractall(path)

        iniPath = path + '\\' + self._version + '\\php.ini'
        config = public.readFile(iniPath).replace('[PATH]',self._setup_path.replace('/','\\'))
        public.writeFile(iniPath,config)

        self.update_php_ext()

        print('安装成功.')
        return True;

    def uninstall_soft(self):
        self._version = sys.argv[3].replace('.','');
        if not self._version: return public.returnMsg(False,'卸载失败，版本号传递错误!');
        try:           
            dfile = self._websoft + '\\php\\' + self._version
            os.remove(dfile);
            self.update_php_ext()
            if os.path.exists(dfile): return public.returnMsg(False,'卸载失败,请检查是否被占用!'); 
        except :
            return public.returnMsg(False,'卸载失败,请检查程序是否被占用!');             
        return public.returnMsg(True,'卸载成功!');

    def update_soft(self,downurl):
        path = self._websoft + '\\php'
        self._version = self._version.replace('.','');

        sfile =  path + '\\' + self._version + '\\php.ini'
        dfile =  path + '\\' + self._version + '\\php.ini.backup'
        shutil.copy(sfile,dfile)
        rRet = self.install_soft(downurl)
        if not rRet['status'] : rRet;
        
        shutil.copy(dfile,sfile)
        os.remove(dfile);

        return public.returnMsg(True,'更新成功!');

    def update_php_ext(self):
        pPath = self._setup_path + '/php'
        if os.path.exists(pPath):
            print("正在更新IIS下PHP扩展...")
            try:
                for x in [0,1,2,3,4,5,6,7,8,9]:
                    public.ExecShell(self._app_cmd + " set config /section:system.webServer/fastCGI /-[InstanceMaxRequests='10000']")
                    public.ExecShell(self._app_cmd + " set config /section:system.webServer/handlers /-[path='*.php']")
            except :
                pass           
            for filename in os.listdir(pPath):
                cgiPath = (pPath + '/'+ filename + "/php-cgi.exe").replace('/','\\')
                iniPath = (pPath + '/'+ filename + "/php.ini").replace('/','\\')
                if os.path.exists(cgiPath):
   
                    public.ExecShell(self._app_cmd + " set config /section:system.webServer/fastCGI /+[fullPath='" + cgiPath + "']")
                    public.ExecShell(self._app_cmd + " set config /section:system.webServer/handlers /+[name='PHP_FastCGI',path='*.php',verb='*',modules='FastCgiModule',scriptProcessor='" + cgiPath + "',resourceType='Unspecified']")

                    public.ExecShell(self._app_cmd + " set config -section:system.webServer/defaultDocument /+\"files.[value='index.php']\" /commit:apphost")
                    public.ExecShell(self._app_cmd + " set config -section:system.webServer/fastCGI /[fullPath='" + cgiPath + "'].instanceMaxRequests:10000")
                    public.ExecShell(self._app_cmd + " set config -section:system.webServer/fastCgi /[fullPath='" + cgiPath + "',arguments=''].activityTimeout:\"90\"  /commit:apphost")
                    public.ExecShell(self._app_cmd + " set config -section:system.webServer/fastCgi /[fullPath=''" + cgiPath + "',arguments=''].requestTimeout:\"90\"  /commit:apphost")
                    public.ExecShell(self._app_cmd + " set config -section:system.webServer/fastCgi /[fullPath='" + cgiPath + "'].monitorChangesTo:\"" + iniPath   + "\"")
                    public.ExecShell(self._app_cmd + " set config -section:system.webServer/fastCgi /+\"[fullPath='" + cgiPath + "'].environmentVariables.[name='PHP_FCGI_MAX_REQUESTS',value='10000']\"")