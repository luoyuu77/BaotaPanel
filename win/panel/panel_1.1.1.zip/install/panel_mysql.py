#!/usr/bin/python
#coding: utf-8
#-----------------------------
# 安装脚本
#-----------------------------

import sys,os,shutil,re
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.append("class/")
import public,tarfile

class panel_mysql:
    _name = 'MySQL'
    _version = None
    _setup_path = None

    def __init__(self,name,version,setup_path):
        self._name = name
        self._version = version
        self._setup_path = setup_path

    def install_soft(self,downurl):
        if public.get_server_status(self._name) >= 0:  public.delete_server(self._name)

        path = self._setup_path + '\\mysql'
        temp = self._setup_path + '/temp/MySQL.rar'

        __name = 'MySQL' + self._version
        if self._version.find('mariadb') >= 0:
            __name = 'MariaDB-' + re.search('\d+\.\d+',self._version).group()
     
        public.downloadFile(downurl + '/win/mysql/'+ __name +'_x64.rar',temp)
        if not os.path.exists(temp): return public.returnMsg(False,'文件下载失败,请检查网络!');

        from unrar import rarfile
        rar = rarfile.RarFile(temp)  
        rar.extractall(path)
        
        sPath =  path + '\\' + __name
        iniPath = sPath + '\\my.ini'
        config = public.readFile(iniPath).replace('[PATH]',self._setup_path.replace('\\','/') + '/mysql/' + __name)
        public.writeFile(iniPath,config)
        if os.path.exists(sPath+'/version.pl'): os.remove(sPath+'/version.pl')       
        rRet = public.create_server(self._name,self._name,path + '\\'+__name+'\\bin\\mysqld.exe','--defaults-file='+ iniPath +' MySQL',"MySQL数据库服务")
        if public.get_server_status(self._name) >= 0:
      
            old_pwd = public.M('config').where("id=?",(1,)).getField('mysql_root')
            if old_pwd.strip() == 'admin': 
                password = public.GetRandomString(16)
                public.ExecShell('cd ' + self._setup_path + '/panel && python tools.py root ' + password)

            print('安装成功!')
            return public.returnMsg(True,'安装成功!');
        return rRet;

    def uninstall_soft(self):
        if public.get_server_status(self._name) >= 0:  public.delete_server(self._name)
        return public.returnMsg(True,'卸载成功!');

    def update_soft(self,downurl):
        path = self._setup_path + '\\mysql'
        __name = 'MySQL' + sys.argv[3]       
        if sys.argv[1] == 'MariaDB':
            __name = 'MariaDB-'+ sys.argv[3]

        sfile = path + '\\' + __name + '\\my.ini'
        dfile = path + '\\' + __name + '\\my.ini.backup'
        shutil.copy (sfile,dfile)
        rRet = self.install_soft(downurl)
        if not rRet['status'] : rRet;
        if public.set_server_status(self._name,'stop'):
            shutil.copy (dfile,sfile)
            os.remove(dfile);
            if public.set_server_status(self._name,'start'):
                 return public.returnMsg(True,'更新成功!');
        return public.returnMsg(False,'更新失败!');
